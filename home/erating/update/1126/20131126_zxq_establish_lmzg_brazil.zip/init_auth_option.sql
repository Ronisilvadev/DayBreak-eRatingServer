insert into SYS_AUTH_OPTION(game_id,Option_Code,Option_Value,option_name)
       values(1204,'union_auth_type','LK_AES','联运类型名');

insert into SYS_AUTH_OPTION(game_id,Option_Code,Option_Value,option_name)
       values(1204,'uri','http://daybreak.globalgames.com.br/auth/','认证地址');

insert into SYS_AUTH_OPTION(game_id,Option_Code,Option_Value,option_name)
       values(1204,'aes_key','405940f65e3b7d1ef35bf326a0caaa0c','AES认证密钥');

insert into SYS_AUTH_OPTION(game_id,Option_Code,Option_Value,option_name)
       values(1204,'secret_key','8ac193ea283e63e301283e8f6886209c','LK认证密钥');

insert into SYS_AUTH_OPTION(game_id,Option_Code,Option_Value,option_name)
       values(1204,'timeout','3','超时时间(秒)');