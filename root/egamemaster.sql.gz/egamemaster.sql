-- MySQL dump 10.13  Distrib 5.5.15, for Linux (i686)
--
-- Host: localhost    Database: egamemaster
-- ------------------------------------------------------
-- Server version	5.5.15-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bak_sys_trustee_ip`
--

DROP TABLE IF EXISTS `bak_sys_trustee_ip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bak_sys_trustee_ip` (
  `GAME_ID` int(3) NOT NULL,
  `GATEWAY_TYPE` int(4) NOT NULL,
  `IP_ID` int(6) NOT NULL,
  `IP_NAME` varchar(32) NOT NULL,
  `TRUSTEE_IP` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bak_sys_trustee_ip`
--

LOCK TABLES `bak_sys_trustee_ip` WRITE;
/*!40000 ALTER TABLE `bak_sys_trustee_ip` DISABLE KEYS */;
/*!40000 ALTER TABLE `bak_sys_trustee_ip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hb_sys_roles_parent`
--

DROP TABLE IF EXISTS `hb_sys_roles_parent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hb_sys_roles_parent` (
  `PARENT_ROLE_ID` int(10) NOT NULL,
  `ROLE_ID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hb_sys_roles_parent`
--

LOCK TABLES `hb_sys_roles_parent` WRITE;
/*!40000 ALTER TABLE `hb_sys_roles_parent` DISABLE KEYS */;
/*!40000 ALTER TABLE `hb_sys_roles_parent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_activity`
--

DROP TABLE IF EXISTS `log_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_activity` (
  `ACTIVITY_ID` int(8) NOT NULL,
  `ACTIVITY_NAME` varchar(500) NOT NULL,
  `START_TIME` datetime NOT NULL,
  `END_TIME` datetime NOT NULL,
  `START_CMD` varchar(500) NOT NULL,
  `END_CMD` varchar(500) NOT NULL,
  `CIRCLEDAY` int(8) NOT NULL,
  PRIMARY KEY (`ACTIVITY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_activity`
--

LOCK TABLES `log_activity` WRITE;
/*!40000 ALTER TABLE `log_activity` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_activity_code`
--

DROP TABLE IF EXISTS `log_activity_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_activity_code` (
  `LOG_ID` int(10) NOT NULL COMMENT 'id',
  `GAME_ID` int(3) NOT NULL COMMENT '游戏编号',
  `GATEWAY_TYPE` int(3) NOT NULL COMMENT '网关类型，0-体验区，1-正式区',
  `PLAN_GEN_NO` int(6) NOT NULL COMMENT '计划生成的激活码数量',
  `SUCCESS_GEN_NO` int(6) NOT NULL COMMENT '成功生成的激活码数量',
  `FILE_PATH` varchar(2048) NOT NULL COMMENT '生成的文件的全路径',
  `OPERATOR_NAME` varchar(32) NOT NULL COMMENT '操作人名称',
  `INSERT_TIME` datetime NOT NULL COMMENT '操作时间',
  PRIMARY KEY (`LOG_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='记录激活码生成日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_activity_code`
--

LOCK TABLES `log_activity_code` WRITE;
/*!40000 ALTER TABLE `log_activity_code` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_activity_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_activity_setting`
--

DROP TABLE IF EXISTS `log_activity_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_activity_setting` (
  `ACTIVITY_ID` int(8) NOT NULL COMMENT '活动ID',
  `ACTIVITY_NAME` varchar(500) NOT NULL COMMENT '活动名称',
  `ACTIVITY_KEYWORD` varchar(500) NOT NULL COMMENT '活动关键字',
  `ACTIVITY_CMD` varchar(500) DEFAULT NULL COMMENT '命令行参数',
  `GAME_ID` int(8) DEFAULT NULL COMMENT '游戏ID',
  `ISRESTART` varchar(1) NOT NULL COMMENT '是否是周循环活动',
  `ACTIVIRYNUM` varchar(500) DEFAULT NULL COMMENT '活动编码',
  `CIRCLE` varchar(1) DEFAULT NULL COMMENT '星期',
  `STARTTIME` varchar(100) DEFAULT NULL COMMENT '开始时间',
  `ENDTIME` varchar(100) DEFAULT NULL COMMENT '结束时间',
  `ISRESERVATION` varchar(1) DEFAULT NULL COMMENT '是否预约',
  PRIMARY KEY (`ACTIVITY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_activity_setting`
--

LOCK TABLES `log_activity_setting` WRITE;
/*!40000 ALTER TABLE `log_activity_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_activity_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_additem_comp`
--

DROP TABLE IF EXISTS `log_additem_comp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_additem_comp` (
  `COMPENSATE_ID` int(10) NOT NULL COMMENT '日志id',
  `GAME_ID` int(3) NOT NULL COMMENT '游戏编号',
  `GATEWAY_TYPE` int(3) NOT NULL COMMENT '区服类型,0-体验区,1-正式区',
  `GATEWAY_ID` int(10) NOT NULL COMMENT '网关ID,0-全区全服',
  `SERVER_ID` int(10) NOT NULL COMMENT '所在线',
  `ROLE_ID` int(10) NOT NULL COMMENT '角色ID',
  `ROLE_NAME` varchar(500) NOT NULL COMMENT '角色名称',
  `ITEM_ID` varchar(500) NOT NULL COMMENT '装备ID',
  `ITEM_NUM` int(10) NOT NULL COMMENT '数目',
  `STAR` int(10) NOT NULL COMMENT '装备星级',
  `ITEM_LEVEL` int(10) NOT NULL COMMENT '装备强化级别',
  `BIND` int(10) NOT NULL COMMENT '装备是否绑定,0-不绑定,1-绑定',
  `REASON` varchar(1024) NOT NULL COMMENT '补偿原因',
  `STATE` int(3) unsigned NOT NULL COMMENT '状态,0 - 草稿，1 - 已提交审批,等待审批一；2- 等待审批二；100 - 通过审批；101 - 已执行操作。-1 - 表示删除。',
  `APPROVAL_RESULT` int(3) unsigned NOT NULL COMMENT '审批结果。-1-未进行审批.1- 通过。2 - 驳回；3 - 直接取消。若state=101时，200 - 表示执行成功；201 - 表示执行失败。',
  `OPERATOR_NAME` varchar(32) NOT NULL COMMENT '操作员名称',
  `INSERT_TIME` date NOT NULL COMMENT '记录插入时间',
  PRIMARY KEY (`COMPENSATE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='装备补偿日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_additem_comp`
--

LOCK TABLES `log_additem_comp` WRITE;
/*!40000 ALTER TABLE `log_additem_comp` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_additem_comp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_additem_comp_approval`
--

DROP TABLE IF EXISTS `log_additem_comp_approval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_additem_comp_approval` (
  `LOG_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT '日志编号',
  `COMPENSATE_ID` int(10) NOT NULL COMMENT '技能补偿日志编号',
  `APPROVAL_NUM` int(3) NOT NULL COMMENT '审批步骤,1-1次审批,2-2次审批,100-执行',
  `APPROVAL_TIME` datetime NOT NULL COMMENT '审批时间',
  `APPROVAL_COMMENT` varchar(1024) NOT NULL COMMENT '审批意见',
  `APPROVAL_RESULT` int(3) NOT NULL COMMENT '审批结果。1- 通过。2 - 驳回；3 - 直接取消。若approval_num =100时，200 - 表示执行成功；201- 表示执行失败。',
  `OPERATOR_NAME` varchar(32) NOT NULL COMMENT '审批人姓名',
  PRIMARY KEY (`LOG_ID`),
  KEY `FK_LOG_ADDITEM_COMP_APPROVAL` (`COMPENSATE_ID`),
  CONSTRAINT `FK_LOG_ADDITEM_COMP_APPROVAL` FOREIGN KEY (`COMPENSATE_ID`) REFERENCES `log_additem_comp` (`COMPENSATE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='技能补偿审批日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_additem_comp_approval`
--

LOCK TABLES `log_additem_comp_approval` WRITE;
/*!40000 ALTER TABLE `log_additem_comp_approval` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_additem_comp_approval` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_award_comp`
--

DROP TABLE IF EXISTS `log_award_comp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_award_comp` (
  `COMPENSATE_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT '日志id',
  `GAME_ID` int(3) NOT NULL COMMENT '游戏编号',
  `GATEWAY_TYPE` int(3) NOT NULL COMMENT '区服类型,0-体验区,1-正式区',
  `ACTIVITY_ID` int(10) NOT NULL COMMENT '活动编号，10位数字',
  `GATEWAY_ID` int(6) NOT NULL COMMENT '网关ID,0-全区全服',
  `ITEM_LIST` varchar(4000) NOT NULL COMMENT '物品编号列表，物品编码和数量，以逗号（,）分隔。每行一条信息。\n            例如：\n            i-88001,5\n            i-88002,3',
  `REASON` varchar(1024) NOT NULL COMMENT '补偿原因',
  `BEGIN_TIME` datetime NOT NULL COMMENT '开始时间',
  `END_TIME` datetime NOT NULL COMMENT '结束时间',
  `STATE` int(3) unsigned NOT NULL COMMENT '状态,0 - 草稿，1 - 已提交审批,等待审批一；2- 等待审批二；100 - 通过审批；101 - 已执行操作。-1 - 表示删除。',
  `APPROVAL_RESULT` int(3) NOT NULL COMMENT '审批结果。-1-未进行审批.1- 通过。2 - 驳回；3 - 直接取消。若state=101时，200 - 表示执行成功；201 - 表示执行失败。',
  `OPERATOR_NAME` varchar(32) NOT NULL COMMENT '操作员名称',
  `INSERT_TIME` datetime NOT NULL COMMENT '记录插入时间',
  `PASSPORT_NAME_LIST` text NOT NULL,
  PRIMARY KEY (`COMPENSATE_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COMMENT='活动奖品补偿日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_award_comp`
--

LOCK TABLES `log_award_comp` WRITE;
/*!40000 ALTER TABLE `log_award_comp` DISABLE KEYS */;
INSERT INTO `log_award_comp` VALUES (1,1204,1,1310091601,0,'i-88001,5','teste','2014-03-06 00:00:00','2014-03-07 00:00:00',100,1,'braziltest4','2014-03-06 18:04:41','garrote'),(2,1204,1,1514091291,0,'2-867-0-0,1\r\n2-505-0-0,1\r\n2-507-0-0,1\r\n1-1327-0-0,1\r\n1-1951-0-0,1\r\n1-1606-0-0,1\r\n2-262-0-0,1\r\n2-517-0-0,1','Teste de Vinculo','2014-09-12 00:00:00','2014-09-13 00:00:00',101,1,'SpaceCowboy','2014-09-14 12:16:06','andersongg'),(3,1204,1,1514091292,0,'2-867-0-0,1\r\n2-505-0-0,1\r\n2-507-0-0,1\r\n1-1327-0-0,1\r\n1-1951-0-0,1\r\n1-1606-0-0,1\r\n2-262-0-0,1\r\n2-517-0-0,1','dfgdtomacu','2014-09-14 00:00:00','2014-09-15 00:00:00',101,1,'SpaceCowboy','2014-09-14 12:20:48','andersongg'),(4,1204,1,1514091245,0,'1-388-0-0,1\r\n2-944-0-0,1\r\n1-870-0-0,1\r\n1-550-0-0,1\r\n2-945-0-0,1\r\n1-870-0-0,1\r\n1-358-0-0,1\r\n1-1327-0-0,1\r\n1-1662-0-0,1\r\n1-870-0-0,1\r\n1-390-0-0,1\r\n2-262-0-0,1\r\n1-1662-0-0,1\r\n1-870-0-0,1\r\n1-314-0-0,1\r\n2-517-0-0,1\r\n1-871-0-0,1\r\n2-867-0-0,1\r\n2-505-0-0,1\r\n2-507-0-0,1\r\n1-871-0-0,1\r\n1-1662-0-0,1\r\n1-1951-0-0,1\r\n1-1606-0-0,1\r\n2-515-0-0,1\r\n1-871-0-0,1','teste semanal 3','2014-09-14 00:00:00','2014-09-15 00:00:00',101,1,'SpaceCowboy','2014-09-14 12:50:43','pedraomontaria'),(5,1204,1,1514092401,0,'7-3-0-0,200','Testando diamantes bonus','2014-09-24 00:00:00','2014-09-25 00:00:00',101,1,'SpaceCowboy','2014-09-26 11:16:46','richard501'),(6,1204,1,1515011321,0,'1-1314-0-0,1\r\n1-1562-0-0,1\r\n2-505-0-0,1\r\n2-507-0-0,1\r\n1-1315-0-0,1\r\n1-1454-0-0,1\r\n1-1308-0-0,1\r\n1-2076-0-0,1\r\n1-1309-0-0,1\r\n1-1307-0-0,1\r\n2-251-0-0,1\r\n2-252-0-0,1','teste','2015-01-13 00:00:00','2015-01-14 00:00:00',101,1,'SpaceCowboy','2015-01-13 13:04:57','andersongg'),(7,1204,1,1315012001,0,'1-388-0-0,1\r\n2-142-0-0,7\r\n2-137-0-0,7\r\n1-550-0-0,1\r\n2-143-0-0,5\r\n2-145-0-0,5\r\n1-358-0-0,1\r\n2-144-0-0,3\r\n2-146-0-0,3\r\n1-390-0-0,1\r\n2-485-0-0,7\r\n2-487-0-0,5\r\n2-486-0-0,3\r\n1-872-0-0,1\r\n2-141-0-0,3\r\n1-207-0-0,1\r\n1-2031-0-0,1\r\n1-1886-0-0,1\r\n1-314-0-0,1\r\n2-867-0-0,5\r\n2-505-0-0,5\r\n2-507-0-0,5','the king of kings','2015-01-20 00:00:00','2015-01-20 00:00:00',101,1,'SpaceCowboy','2015-01-20 10:27:20','pedrao6'),(8,1204,1,1315012002,0,'1-388-0-0,1\r\n2-142-0-0,7\r\n2-137-0-0,7\r\n1-550-0-0,1\r\n2-143-0-0,5\r\n2-145-0-0,5\r\n1-358-0-0,1\r\n2-144-0-0,3\r\n2-146-0-0,3\r\n1-390-0-0,1\r\n2-485-0-0,7\r\n2-487-0-0,5\r\n2-486-0-0,3\r\n1-872-0-0,1\r\n2-141-0-0,3\r\n1-207-0-0,1\r\n1-2031-0-0,1\r\n1-1886-0-0,1\r\n1-314-0-0,1\r\n2-867-0-0,5\r\n2-505-0-0,5\r\n2-507-0-0,5','king of kings','2015-01-20 00:00:00','2015-01-21 00:00:00',101,1,'SpaceCowboy','2015-01-20 10:32:25','pedrao6'),(9,1204,1,1515012001,0,'1-388-0-0,1\r\n2-142-0-0,7\r\n2-137-0-0,7\r\n1-550-0-0,1\r\n2-143-0-0,5\r\n2-145-0-0,5\r\n1-358-0-0,1\r\n2-144-0-0,3\r\n2-146-0-0,3\r\n1-390-0-0,1\r\n2-485-0-0,7\r\n2-487-0-0,5\r\n2-486-0-0,3\r\n1-872-0-0,1\r\n2-141-0-0,3\r\n1-207-0-0,1\r\n1-2031-0-0,1\r\n1-1886-0-0,1\r\n1-314-0-0,1\r\n2-867-0-0,5\r\n2-505-0-0,5\r\n2-507-0-0,5','king of kings','2015-01-20 00:00:00','2015-01-30 00:00:00',101,1,'SpaceCowboy','2015-01-20 10:35:56','pedrao6'),(10,1204,1,1515041601,0,'1-453-0-0,10\r\n2-481-0-0,10','teste','2015-04-16 00:00:00','2015-04-17 00:00:00',101,1,'SpaceCowboy','2015-04-16 16:22:39','iv4nxxx');
/*!40000 ALTER TABLE `log_award_comp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_award_comp_approval`
--

DROP TABLE IF EXISTS `log_award_comp_approval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_award_comp_approval` (
  `LOG_ID` int(10) NOT NULL AUTO_INCREMENT COMMENT '日志编号',
  `COMPENSATE_ID` int(10) NOT NULL COMMENT '活动奖品补偿日志编号',
  `APPROVAL_NUM` int(3) NOT NULL COMMENT '审批步骤,1-1次审批,2-2次审批,100-执行',
  `APPROVAL_TIME` datetime NOT NULL COMMENT '审批时间',
  `APPROVAL_COMMENT` varchar(1024) NOT NULL COMMENT '审批意见',
  `APPROVAL_RESULT` int(3) NOT NULL COMMENT '审批结果。1- 通过。2 - 驳回；3 - 直接取消。若approval_num =100时，200 - 表示执行成功；201- 表示执行失败。',
  `OPERATOR_NAME` varchar(32) NOT NULL COMMENT '审批人姓名',
  PRIMARY KEY (`LOG_ID`),
  KEY `FK_LOG_AWAR_APPROVAL` (`COMPENSATE_ID`),
  CONSTRAINT `FK_LOG_AWAR_APPROVAL` FOREIGN KEY (`COMPENSATE_ID`) REFERENCES `log_award_comp` (`COMPENSATE_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 COMMENT='活动奖品补偿审批日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_award_comp_approval`
--

LOCK TABLES `log_award_comp_approval` WRITE;
/*!40000 ALTER TABLE `log_award_comp_approval` DISABLE KEYS */;
INSERT INTO `log_award_comp_approval` VALUES (1,1,1,'2014-03-06 18:05:41','teste de aprovacao',1,'braziltest4'),(2,1,2,'2014-03-06 18:06:19','teste 2',1,'braziltest4'),(3,2,1,'2014-09-14 12:16:15','teste',1,'SpaceCowboy'),(4,2,2,'2014-09-14 12:16:19','teste',1,'SpaceCowboy'),(5,2,100,'2014-09-14 12:16:28','Execute',200,'SpaceCowboy'),(6,3,1,'2014-09-14 12:20:54','sdfsdf',1,'SpaceCowboy'),(7,3,2,'2014-09-14 12:20:59','sdfdsf',1,'SpaceCowboy'),(8,3,100,'2014-09-14 12:21:04','Execute',200,'SpaceCowboy'),(9,4,1,'2014-09-14 12:50:53','teste 3',1,'SpaceCowboy'),(10,4,2,'2014-09-14 12:50:58','teste 3',1,'SpaceCowboy'),(11,4,100,'2014-09-14 12:51:02','Execute',200,'SpaceCowboy'),(12,5,1,'2014-09-26 11:17:00','teste bonus',1,'SpaceCowboy'),(13,5,2,'2014-09-26 11:17:06','teste bonus',1,'SpaceCowboy'),(14,5,100,'2014-09-26 11:17:29','Execute',200,'SpaceCowboy'),(15,6,1,'2015-01-13 13:05:06','teste',1,'SpaceCowboy'),(16,6,2,'2015-01-13 13:05:12','teste',1,'SpaceCowboy'),(17,6,100,'2015-01-13 13:05:35','Execute',200,'SpaceCowboy'),(18,7,1,'2015-01-20 10:27:43','king of kings',1,'SpaceCowboy'),(19,7,2,'2015-01-20 10:27:56','king of kings',1,'SpaceCowboy'),(20,7,100,'2015-01-20 10:28:15','Execute',200,'SpaceCowboy'),(21,8,1,'2015-01-20 10:32:37','king of kings',1,'SpaceCowboy'),(22,8,2,'2015-01-20 10:32:49','king of kings',1,'SpaceCowboy'),(23,8,100,'2015-01-20 10:32:58','Execute',200,'SpaceCowboy'),(24,9,1,'2015-01-20 10:36:08','king of kings',1,'SpaceCowboy'),(25,9,2,'2015-01-20 10:36:15','king of kings',1,'SpaceCowboy'),(26,9,100,'2015-01-20 10:36:20','Execute',200,'SpaceCowboy'),(27,10,1,'2015-04-16 16:22:52','good',1,'SpaceCowboy'),(28,10,2,'2015-04-16 16:23:01','good',1,'SpaceCowboy'),(29,10,100,'2015-04-16 16:27:15','Execute',200,'SpaceCowboy');
/*!40000 ALTER TABLE `log_award_comp_approval` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_bind_email`
--

DROP TABLE IF EXISTS `log_bind_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_bind_email` (
  `CHANGE_ID` int(10) NOT NULL COMMENT '日志id',
  `PASSPORT_NAME` varchar(32) NOT NULL COMMENT '绑定帐号名',
  `NEW_EMAIL` varchar(64) NOT NULL COMMENT '新邮箱地址',
  `STATE` int(3) unsigned NOT NULL COMMENT '状态,0 - 草稿，1 - 已提交审批,等待审批一；2- 等待审批二；100 - 通过审批；101 - 已执行操作。-1 - 表示删除。',
  `APPROVAL_RESULT` int(3) unsigned NOT NULL COMMENT '审批结果。-1-未进行审批.1- 通过。2 - 驳回；3 - 直接取消。若state=101时，200 - 表示执行成功；201 - 表示执行失败。',
  `REASON` varchar(1024) NOT NULL COMMENT '修改原因',
  `OPERATOR_NAME` varchar(32) NOT NULL COMMENT '操作员名称',
  `INSERT_TIME` datetime NOT NULL COMMENT '记录插入时间',
  PRIMARY KEY (`CHANGE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='修改绑定邮箱日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_bind_email`
--

LOCK TABLES `log_bind_email` WRITE;
/*!40000 ALTER TABLE `log_bind_email` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_bind_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_bind_email_approval`
--

DROP TABLE IF EXISTS `log_bind_email_approval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_bind_email_approval` (
  `LOG_ID` int(10) NOT NULL COMMENT '日志编号',
  `CHANGE_ID` int(10) NOT NULL COMMENT '修改绑定邮箱日志编号',
  `APPROVAL_NUM` int(3) NOT NULL COMMENT '审批步骤,1-1次审批,2-2次审批,100-执行',
  `APPROVAL_TIME` datetime NOT NULL COMMENT '审批时间',
  `APPROVAL_COMMENT` varchar(1024) NOT NULL COMMENT '审批意见',
  `APPROVAL_RESULT` int(3) NOT NULL COMMENT '审批结果。1- 通过。2 - 驳回；3 - 直接取消。若approval_num =100时，200 - 表示执行成功；201- 表示执行失败。',
  `OPERATOR_NAME` varchar(32) NOT NULL COMMENT '审批人姓名',
  PRIMARY KEY (`LOG_ID`),
  KEY `FK_LOG_BIND_APPROVAL` (`CHANGE_ID`),
  CONSTRAINT `FK_LOG_BIND_APPROVAL` FOREIGN KEY (`CHANGE_ID`) REFERENCES `log_bind_email` (`CHANGE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='修改绑定邮箱审批日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_bind_email_approval`
--

LOCK TABLES `log_bind_email_approval` WRITE;
/*!40000 ALTER TABLE `log_bind_email_approval` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_bind_email_approval` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_bulletin_approval`
--

DROP TABLE IF EXISTS `log_bulletin_approval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_bulletin_approval` (
  `LOG_ID` int(10) NOT NULL COMMENT '日志编号',
  `COMPENSATE_ID` int(10) NOT NULL COMMENT '技能补偿日志编号',
  `APPROVAL_NUM` int(3) NOT NULL COMMENT '审批步骤,1-1次审批,2-2次审批,100-执行',
  `APPROVAL_TIME` datetime NOT NULL COMMENT '审批时间',
  `APPROVAL_COMMENT` varchar(1024) NOT NULL COMMENT '审批意见',
  `APPROVAL_RESULT` int(3) NOT NULL COMMENT '审批结果。1- 通过。2 - 驳回；3 - 直接取消。若approval_num =100时，200 - 表示执行成功；201- 表示执行失败。',
  `OPERATOR_NAME` varchar(32) NOT NULL,
  PRIMARY KEY (`LOG_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='技能补偿审批日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_bulletin_approval`
--

LOCK TABLES `log_bulletin_approval` WRITE;
/*!40000 ALTER TABLE `log_bulletin_approval` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_bulletin_approval` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_bulletin_detail`
--

DROP TABLE IF EXISTS `log_bulletin_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_bulletin_detail` (
  `BULLETIN_ID` int(10) NOT NULL COMMENT '公告id',
  `GATEWAY_ID` int(6) NOT NULL COMMENT '网关id',
  `SERVER_ID` int(8) NOT NULL COMMENT '线id',
  `EXECUTIVE_TIMES` int(10) NOT NULL COMMENT '执行次数',
  `SUCCESS_TIMES` int(10) NOT NULL COMMENT '成功次数',
  `LAST_EXECUTE_TIME` datetime DEFAULT NULL COMMENT '上一次执行的时间',
  `STATE` int(3) DEFAULT NULL COMMENT '1-公告未被gmserver接收，2-公告已被gmserver接收，3-执行中，4-公告已执行完毕，5-公告已撤销',
  `CANCEL_TIME` datetime DEFAULT NULL COMMENT '同步目标游戏',
  PRIMARY KEY (`BULLETIN_ID`,`SERVER_ID`,`GATEWAY_ID`),
  CONSTRAINT `FK_BULL_INFO_BULL_DTL` FOREIGN KEY (`BULLETIN_ID`) REFERENCES `log_bulletin_info` (`BULLETIN_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='游戏公告详情';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_bulletin_detail`
--

LOCK TABLES `log_bulletin_detail` WRITE;
/*!40000 ALTER TABLE `log_bulletin_detail` DISABLE KEYS */;
INSERT INTO `log_bulletin_detail` VALUES (1,104001,0,0,0,NULL,1,NULL),(2,104001,0,0,0,NULL,1,NULL),(3,104001,0,1,0,'2014-04-14 02:38:45',5,'2014-04-14 02:48:12'),(4,104001,0,1,0,'2014-04-14 02:47:23',4,NULL),(5,104001,0,1,0,'2014-04-14 02:48:26',4,NULL),(6,104001,0,1,0,'2014-04-14 02:49:20',4,NULL);
/*!40000 ALTER TABLE `log_bulletin_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_bulletin_info`
--

DROP TABLE IF EXISTS `log_bulletin_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_bulletin_info` (
  `BULLETIN_ID` int(10) NOT NULL COMMENT '公告id',
  `GAME_ID` int(3) NOT NULL COMMENT '游戏编号',
  `GATEWAY_TYPE` int(3) NOT NULL COMMENT '网关类型，0-体验区，1-正式区',
  `TITLE` varchar(512) NOT NULL COMMENT '公告标题',
  `GATEWAY_ID` int(6) NOT NULL COMMENT '网关ID',
  `SERVER_ID` int(8) NOT NULL COMMENT '线id',
  `START_TIME` datetime NOT NULL COMMENT '开始时间',
  `END_TIME` datetime NOT NULL COMMENT '结束时间',
  `INTERVALS` int(10) NOT NULL COMMENT '发送时间间隔',
  `CONTENT` varchar(2048) NOT NULL COMMENT '公告内容',
  `TOTAL_TIMES` int(10) NOT NULL COMMENT '总共执行次数',
  `STATE` int(3) NOT NULL COMMENT '1-公告未被gmserver接收，2-公告已被gmserver接收，3-执行中，4-公告已执行完毕，5-公告已撤销',
  `CANCEL_TIME` datetime DEFAULT NULL COMMENT '撤销时间',
  `OPERATOR_NAME` varchar(32) NOT NULL COMMENT '添加人名称',
  `INSERT_TIME` datetime NOT NULL COMMENT '添加时间',
  `CANCEL_OPER_NAME` varchar(32) DEFAULT NULL COMMENT '撤销人名称',
  `BOOKING` varchar(5) NOT NULL DEFAULT '-1' COMMENT '即时预约',
  `APPROVAL_RESULT` int(3) NOT NULL DEFAULT '-1' COMMENT '审批结果。-1-未进行审批.1- 通过。2 - 驳回；3 - 直接取消。若state=101时，200 - 表示执行成功；201 - 表示执行失败。',
  `OPER_STATE` int(3) NOT NULL DEFAULT '-1' COMMENT '状态,0 - 草稿，1 - 已提交审批,等待审批一；2- 等待审批二；100 - 通过审批；101 - 已执行操作。-1 - 表示删除。',
  PRIMARY KEY (`BULLETIN_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='记录发布公告日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_bulletin_info`
--

LOCK TABLES `log_bulletin_info` WRITE;
/*!40000 ALTER TABLE `log_bulletin_info` DISABLE KEYS */;
INSERT INTO `log_bulletin_info` VALUES (1,1204,1,'无标题',-1,0,'2014-04-14 01:24:53','2014-04-14 07:24:53',21600,'test',2,5,'2014-04-14 02:38:07','SpaceCowboy','2014-04-14 01:24:53','SpaceCowboy','-1',-1,-1),(2,1204,1,'无标题',-1,0,'2014-04-14 01:28:07','2014-04-14 07:28:07',21600,'test',2,5,'2014-04-14 02:37:41','SpaceCowboy','2014-04-14 01:28:07','SpaceCowboy','-1',-1,-1),(3,1204,1,'无标题',-1,0,'2014-04-14 02:38:35','2014-04-15 08:38:35',21600,'test',6,5,'2014-04-14 02:48:12','SpaceCowboy','2014-04-14 02:38:35','SpaceCowboy','-1',-1,-1),(4,1204,1,'无标题',-1,0,'2014-04-14 02:47:23','2014-04-14 02:47:23',21600,'test',1,4,NULL,'SpaceCowboy','2014-04-14 02:47:23',NULL,'-1',-1,-1),(5,1204,1,'无标题',-1,0,'2014-04-14 02:48:26','2014-04-14 02:48:26',21600,'test',1,4,NULL,'SpaceCowboy','2014-04-14 02:48:26',NULL,'-1',-1,-1),(6,1204,1,'无标题',-1,0,'2014-04-14 02:49:10','2014-04-14 02:49:10',21600,'test',1,4,NULL,'SpaceCowboy','2014-04-14 02:49:10',NULL,'-1',-1,-1);
/*!40000 ALTER TABLE `log_bulletin_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_change_amount`
--

DROP TABLE IF EXISTS `log_change_amount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_change_amount` (
  `CHANGE_ID` int(10) NOT NULL COMMENT '日志id',
  `GAME_ID` int(3) NOT NULL COMMENT '游戏编号',
  `GATEWAY_TYPE` int(3) NOT NULL COMMENT '区服类型,0-体验区,1-正式区',
  `GATEWAY_ID` int(6) NOT NULL COMMENT '网关ID,0-全区全服',
  `SERVER_ID` int(8) NOT NULL COMMENT '线ID',
  `PASSPORT_NAME` varchar(32) NOT NULL COMMENT '玩家账号名称',
  `ROLE_NAME` varchar(32) NOT NULL COMMENT '角色名称',
  `ROLE_ID` int(10) NOT NULL COMMENT '角色id',
  `CHANGE_TYPE` int(3) NOT NULL COMMENT '补偿类型，1-经验，2-金钱，3-三元点，4-悟性',
  `CHANGE_AMOUNT` int(10) NOT NULL COMMENT '补偿的数量',
  `REMAIN_AMOUNT` int(10) NOT NULL COMMENT '角色在操作成功后的剩余数量，若为-1，表示未知。',
  `REASON` varchar(1024) NOT NULL COMMENT '补偿原因',
  `STATE` int(4) unsigned NOT NULL COMMENT '状态,0 - 草稿，1 - 已提交审批,等待审批一；2- 等待审批二；100 - 通过审批；101 - 已执行操作。-1 - 表示删除。',
  `APPROVAL_RESULT` int(3) NOT NULL COMMENT '审批结果。-1-未进行审批.1- 通过。2 - 驳回；3 - 直接取消。若state=101时，200 - 表示执行成功；201 - 表示执行失败。',
  `OPERATOR_NAME` varchar(32) NOT NULL COMMENT '操作员名称',
  `INSERT_TIME` datetime NOT NULL COMMENT '记录插入时间',
  PRIMARY KEY (`CHANGE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='数据修改日志表，包括金钱，经验，三元点，悟性';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_change_amount`
--

LOCK TABLES `log_change_amount` WRITE;
/*!40000 ALTER TABLE `log_change_amount` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_change_amount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_change_amount_approval`
--

DROP TABLE IF EXISTS `log_change_amount_approval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_change_amount_approval` (
  `LOG_ID` int(10) NOT NULL COMMENT '日志编号',
  `CHANGE_ID` int(10) NOT NULL COMMENT '活动奖品补偿日志编号',
  `APPROVAL_NUM` int(3) NOT NULL COMMENT '审批步骤,1-1次审批,2-2次审批,100-执行',
  `APPROVAL_TIME` datetime NOT NULL COMMENT '审批时间',
  `APPROVAL_COMMENT` varchar(1024) NOT NULL COMMENT '审批意见',
  `APPROVAL_RESULT` int(3) NOT NULL COMMENT '审批结果。1- 通过。2 - 驳回；3 - 直接取消。若approval_num =100时，200 - 表示执行成功；201- 表示执行失败。',
  `OPERATOR_NAME` varchar(32) NOT NULL COMMENT '审批人姓名',
  PRIMARY KEY (`LOG_ID`),
  KEY `FK_LOG_CHANGE_APPROVAL` (`CHANGE_ID`),
  CONSTRAINT `FK_LOG_CHANGE_APPROVAL` FOREIGN KEY (`CHANGE_ID`) REFERENCES `log_change_amount` (`CHANGE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='数据修改审批日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_change_amount_approval`
--

LOCK TABLES `log_change_amount_approval` WRITE;
/*!40000 ALTER TABLE `log_change_amount_approval` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_change_amount_approval` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_change_sys_resources`
--

DROP TABLE IF EXISTS `log_change_sys_resources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_change_sys_resources` (
  `OPERETOR` varchar(16) DEFAULT NULL COMMENT '修改者',
  `IP_ADDRESS` varchar(50) DEFAULT NULL COMMENT '修改者登录IP',
  `CHANGE_TIME` datetime NOT NULL COMMENT '修改时间',
  `ACTION` varchar(8) NOT NULL COMMENT '修改类型',
  `OLD_RES_URL` varchar(1024) DEFAULT NULL COMMENT '修改前的资源连接',
  `NEW_RES_URL` varchar(1024) DEFAULT NULL COMMENT '修改后的资源连接'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='记录表sys_resources被修改时间的日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_change_sys_resources`
--

LOCK TABLES `log_change_sys_resources` WRITE;
/*!40000 ALTER TABLE `log_change_sys_resources` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_change_sys_resources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_clean_package`
--

DROP TABLE IF EXISTS `log_clean_package`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_clean_package` (
  `LOG_ID` int(10) NOT NULL COMMENT '日志id',
  `GAME_ID` int(3) NOT NULL COMMENT '游戏编号',
  `GATEWAY_ID` int(6) NOT NULL COMMENT '网关id',
  `SERVER_ID` int(8) NOT NULL COMMENT '线id',
  `ROLE_ID` int(10) NOT NULL COMMENT '角色id',
  `ROLE_NAME` varchar(32) NOT NULL COMMENT '角色名称',
  `PASSPORT_NAME` varchar(32) NOT NULL COMMENT '角色所属账号',
  `OPERATOR_NAME` varchar(32) NOT NULL COMMENT '操作人',
  `INSERT_TIME` datetime NOT NULL COMMENT '操作时间',
  `RESON` varchar(1024) NOT NULL COMMENT '详细描述',
  `DETAIL` varchar(4000) NOT NULL COMMENT '清空的物品记录',
  PRIMARY KEY (`LOG_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='清空玩家包裹日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_clean_package`
--

LOCK TABLES `log_clean_package` WRITE;
/*!40000 ALTER TABLE `log_clean_package` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_clean_package` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_clearpoint_comp`
--

DROP TABLE IF EXISTS `log_clearpoint_comp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_clearpoint_comp` (
  `COMPENSATE_ID` int(8) NOT NULL COMMENT '日志id',
  `GAME_ID` int(8) NOT NULL COMMENT '游戏编号',
  `REASON` varchar(4000) NOT NULL COMMENT '原因',
  `STATE` int(8) unsigned NOT NULL COMMENT '状态,0 - 草稿，1 - 已提交审批,等待审批一；2- 等待审批二；100 - 通过审批；101 - 已执行操作。-1 - 表示删除。',
  `APPROVAL_RESULT` int(8) NOT NULL COMMENT '审批结果。-1-未进行审批.1- 通过。2 - 驳回；3 - 直接取消。',
  `OPERATOR_NAME` varchar(100) NOT NULL COMMENT '操作员名称',
  `INSERT_TIME` datetime NOT NULL COMMENT '记录插入时间',
  `POINTTYPE` int(8) NOT NULL COMMENT '积分类型',
  PRIMARY KEY (`COMPENSATE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='清除充值积分日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_clearpoint_comp`
--

LOCK TABLES `log_clearpoint_comp` WRITE;
/*!40000 ALTER TABLE `log_clearpoint_comp` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_clearpoint_comp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_clearpoint_comp_approval`
--

DROP TABLE IF EXISTS `log_clearpoint_comp_approval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_clearpoint_comp_approval` (
  `LOG_ID` int(10) NOT NULL COMMENT '日志编号',
  `COMPENSATE_ID` int(10) NOT NULL COMMENT '技能补偿日志编号',
  `APPROVAL_NUM` int(3) NOT NULL COMMENT '审批步骤,1-1次审批,2-2次审批,100-执行',
  `APPROVAL_TIME` datetime NOT NULL COMMENT '审批时间',
  `APPROVAL_COMMENT` varchar(1024) NOT NULL COMMENT '审批意见',
  `APPROVAL_RESULT` int(3) NOT NULL COMMENT '审批结果。1- 通过。2 - 驳回；3 - 直接取消。若approval_num =100时，200 - 表示执行成功；201- 表示执行失败。',
  `OPERATOR_NAME` varchar(32) NOT NULL COMMENT '审批人姓名',
  PRIMARY KEY (`LOG_ID`),
  KEY `FK_CLEARPOINT_COMP_APPROVAL` (`COMPENSATE_ID`),
  CONSTRAINT `FK_CLEARPOINT_COMP_APPROVAL` FOREIGN KEY (`COMPENSATE_ID`) REFERENCES `log_clearpoint_comp` (`COMPENSATE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='清除充值积分审批日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_clearpoint_comp_approval`
--

LOCK TABLES `log_clearpoint_comp_approval` WRITE;
/*!40000 ALTER TABLE `log_clearpoint_comp_approval` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_clearpoint_comp_approval` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_close_pass_card`
--

DROP TABLE IF EXISTS `log_close_pass_card`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_close_pass_card` (
  `PASSPORT_ID` int(10) NOT NULL,
  `CHANGE_ID` int(10) NOT NULL COMMENT '日志id',
  `PASSPORT_NAME` varchar(32) NOT NULL COMMENT '绑定帐号名',
  `PLAYER_NAME` varchar(64) NOT NULL COMMENT '玩家姓名',
  `PRIVATE_ID` varchar(32) NOT NULL COMMENT '身份证号码',
  `STATE` int(3) NOT NULL COMMENT '状态,0 - 草稿，1 - 已提交审批,等待审批一；2- 等待审批二；100 - 通过审批；101 - 已执行操作。-1 - 表示删除。',
  `APPROVAL_RESULT` int(3) NOT NULL COMMENT '审批结果。-1-未进行审批.1- 通过。2 - 驳回；3 - 直接取消。若state=101时，200 - 表示执行成功；201 - 表示执行失败。',
  `REASON` varchar(1024) NOT NULL COMMENT '修改原因',
  `OPERATOR_NAME` varchar(32) NOT NULL COMMENT '操作员名称',
  `INSERT_TIME` datetime NOT NULL COMMENT '记录插入时间',
  PRIMARY KEY (`CHANGE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='密保卡解绑日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_close_pass_card`
--

LOCK TABLES `log_close_pass_card` WRITE;
/*!40000 ALTER TABLE `log_close_pass_card` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_close_pass_card` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_close_pass_card_approval`
--

DROP TABLE IF EXISTS `log_close_pass_card_approval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_close_pass_card_approval` (
  `LOG_ID` int(10) NOT NULL COMMENT '日志编号',
  `CHANGE_ID` int(10) NOT NULL COMMENT '修改绑定邮箱日志编号',
  `APPROVAL_NUM` int(3) NOT NULL COMMENT '审批步骤,1-1次审批,2-2次审批,100-执行',
  `APPROVAL_TIME` datetime NOT NULL COMMENT '审批时间',
  `APPROVAL_COMMENT` varchar(1024) NOT NULL COMMENT '审批意见',
  `APPROVAL_RESULT` int(3) NOT NULL COMMENT '审批结果。1- 通过。2 - 驳回；3 - 直接取消。若approval_num =100时，200 - 表示执行成功；201- 表示执行失败。',
  `OPERATOR_NAME` varchar(32) NOT NULL COMMENT '审批人姓名',
  PRIMARY KEY (`LOG_ID`),
  KEY `FK_LOG_CLOS_REFERENCE_LOG_CLOS` (`CHANGE_ID`),
  CONSTRAINT `FK_LOG_CLOS_REFERENCE_LOG_CLOS` FOREIGN KEY (`CHANGE_ID`) REFERENCES `log_close_pass_card` (`CHANGE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='密保卡解绑审批日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_close_pass_card_approval`
--

LOCK TABLES `log_close_pass_card_approval` WRITE;
/*!40000 ALTER TABLE `log_close_pass_card_approval` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_close_pass_card_approval` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_egmserver_command`
--

DROP TABLE IF EXISTS `log_egmserver_command`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_egmserver_command` (
  `RECORD_ID` int(10) NOT NULL COMMENT '在web db中的标识',
  `CMD_TYPE` int(8) NOT NULL,
  `SERVER_ID` int(8) NOT NULL,
  `START_TIME` datetime NOT NULL,
  `CMD_PARAM` varchar(2048) NOT NULL COMMENT '命令参数',
  `GAME_ID` int(3) NOT NULL COMMENT '游戏id',
  `GATEWAY_ID` int(6) DEFAULT NULL,
  `END_TIME` datetime DEFAULT NULL,
  `TOTAL_NUM` int(8) NOT NULL COMMENT '执行总数',
  `EXECUTED_NUM` int(8) NOT NULL COMMENT '当前执行次数',
  `BE_DONE` int(8) DEFAULT '0',
  `CMD_ID` int(10) NOT NULL,
  PRIMARY KEY (`CMD_ID`),
  KEY `LOG_EGMSERVER_COMMAND_IX` (`RECORD_ID`,`CMD_TYPE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='eGMServer 命令体验业务表-包含所有稍后执行命令，如发布公告，双倍等';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_egmserver_command`
--

LOCK TABLES `log_egmserver_command` WRITE;
/*!40000 ALTER TABLE `log_egmserver_command` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_egmserver_command` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_end_fight_state`
--

DROP TABLE IF EXISTS `log_end_fight_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_end_fight_state` (
  `LOG_ID` int(10) NOT NULL COMMENT '日志id',
  `GAME_ID` int(3) NOT NULL COMMENT '游戏编号',
  `GATEWAY_TYPE` int(3) NOT NULL COMMENT '网关类型，0-体验区，1-正式区',
  `GATEWAY_ID` int(6) NOT NULL COMMENT '网关id',
  `SERVER_ID` int(8) NOT NULL COMMENT '线id',
  `ROLE_NAME` varchar(32) NOT NULL COMMENT '角色名称',
  `PASSPORT_NAME` varchar(32) NOT NULL COMMENT '角色所属账号',
  `OPERATOR_NAME` varchar(32) NOT NULL COMMENT '操作人',
  `INSERT_TIME` datetime NOT NULL COMMENT '操作时间',
  PRIMARY KEY (`LOG_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='结束玩家战斗状态日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_end_fight_state`
--

LOCK TABLES `log_end_fight_state` WRITE;
/*!40000 ALTER TABLE `log_end_fight_state` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_end_fight_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_end_task`
--

DROP TABLE IF EXISTS `log_end_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_end_task` (
  `LOG_ID` int(10) NOT NULL COMMENT '日志id',
  `GAME_ID` int(3) NOT NULL COMMENT '游戏编号',
  `GATEWAY_TYPE` int(3) NOT NULL COMMENT '网关类型，0-体验区，1-正式区',
  `GATEWAY_ID` int(6) NOT NULL COMMENT '网关id',
  `SERVER_ID` int(8) NOT NULL COMMENT '线id',
  `ROLE_NAME` varchar(32) NOT NULL COMMENT '角色名称',
  `PASSPORT_NAME` varchar(32) NOT NULL COMMENT '角色所属账号',
  `TASK_NAME` varchar(128) NOT NULL COMMENT '任务名称',
  `OPERATOR_NAME` varchar(32) NOT NULL COMMENT '操作人',
  `INSERT_TIME` datetime NOT NULL COMMENT '操作时间',
  PRIMARY KEY (`LOG_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='结束任务日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_end_task`
--

LOCK TABLES `log_end_task` WRITE;
/*!40000 ALTER TABLE `log_end_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_end_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_freeze_account`
--

DROP TABLE IF EXISTS `log_freeze_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_freeze_account` (
  `LOG_ID` int(10) NOT NULL,
  `GAME_ID` int(3) NOT NULL COMMENT '游戏编号',
  `PASSPORT_ID` int(10) NOT NULL COMMENT 'passport编号',
  `GATEWAY_TYPE` int(3) NOT NULL COMMENT '区服类型，0=体验区，1=正式区',
  `STATE` int(3) NOT NULL COMMENT '状态,1=冻结中,2=已恢复',
  `FREEZE_TIME` datetime NOT NULL COMMENT '冻结时间',
  `RESTORE_TIME` datetime DEFAULT NULL COMMENT '恢复时间',
  `LAST_SECONDS` int(10) NOT NULL COMMENT '冻结帐号持续时间，单位为秒',
  `REASON` varchar(1024) DEFAULT NULL COMMENT '冻结原因',
  `OPERATOR_NAME` varchar(32) NOT NULL COMMENT '冻结操作员名称',
  `RESTORE_OPER_NAME` varchar(32) DEFAULT NULL COMMENT '恢复时，操作员的名称',
  PRIMARY KEY (`LOG_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='记录冻结帐号日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_freeze_account`
--

LOCK TABLES `log_freeze_account` WRITE;
/*!40000 ALTER TABLE `log_freeze_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_freeze_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_freeze_account_detail`
--

DROP TABLE IF EXISTS `log_freeze_account_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_freeze_account_detail` (
  `LOG_ID` int(10) NOT NULL COMMENT '日志id',
  `GATEWAY_ID` int(6) NOT NULL COMMENT '网关id',
  `STATE` int(3) NOT NULL COMMENT '1-未被gmserver接收，2-已被gmserver接收，3-执行中，4-执行完毕，5-人工停止',
  `FREEZE_TIME` datetime DEFAULT NULL COMMENT 'gm执行的时间',
  `RESTORE_TIME` datetime DEFAULT NULL COMMENT 'gm成功停止时间',
  PRIMARY KEY (`LOG_ID`,`GATEWAY_ID`),
  CONSTRAINT `FK_LOG_FREE_REFERENCE_LOG_FREE` FOREIGN KEY (`LOG_ID`) REFERENCES `log_freeze_account` (`LOG_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='冻结账号详情';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_freeze_account_detail`
--

LOCK TABLES `log_freeze_account_detail` WRITE;
/*!40000 ALTER TABLE `log_freeze_account_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_freeze_account_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_freeze_mac`
--

DROP TABLE IF EXISTS `log_freeze_mac`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_freeze_mac` (
  `LOG_ID` int(8) NOT NULL COMMENT '记录ID',
  `GAME_ID` int(8) NOT NULL COMMENT '游戏ID',
  `GATEWAY_ID` int(8) NOT NULL COMMENT '网关ID',
  `MAC` varchar(64) NOT NULL COMMENT 'MAC地址',
  `START_TIME` varchar(64) NOT NULL COMMENT '开始时间',
  `PERIOD` int(8) NOT NULL COMMENT '冻结时长',
  `OPER_TYPE` int(8) NOT NULL COMMENT '操作类型',
  `OPER` varchar(64) NOT NULL COMMENT '操作人',
  `REASON` varchar(4000) NOT NULL COMMENT '操作原因',
  PRIMARY KEY (`LOG_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_freeze_mac`
--

LOCK TABLES `log_freeze_mac` WRITE;
/*!40000 ALTER TABLE `log_freeze_mac` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_freeze_mac` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_gold_comp`
--

DROP TABLE IF EXISTS `log_gold_comp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_gold_comp` (
  `COMPENSATE_ID` int(10) NOT NULL COMMENT '日志id',
  `GAME_ID` int(3) NOT NULL COMMENT '游戏编号',
  `GATEWAY_TYPE` int(3) NOT NULL COMMENT '区服类型,0-体验区,1-正式区',
  `SERIAL_NUMBER` int(12) NOT NULL COMMENT '编号，12位数字',
  `GATEWAY_ID` int(6) NOT NULL COMMENT '网关ID,0-全区全服',
  `SUBJECT_ID` int(4) DEFAULT NULL,
  `COMPENSATE_CONTENT` varchar(4000) NOT NULL COMMENT '补偿列表',
  `REASON` varchar(1024) NOT NULL COMMENT '补偿原因',
  `STATE` int(3) NOT NULL COMMENT '状态,0 - 草稿，1 - 已提交审批,等待审批一；2- 等待审批二；100 - 通过审批；101 - 已执行操作。-1 - 表示删除。',
  `APPROVAL_RESULT` int(3) NOT NULL COMMENT '审批结果。-1-未进行审批.1- 通过。2 - 驳回；3 - 直接取消。若state=101时，200 - 表示执行成功；201 - 表示执行失败。',
  `OPERATOR_NAME` varchar(32) NOT NULL COMMENT '操作员名称',
  `INSERT_TIME` datetime NOT NULL COMMENT '记录插入时间',
  PRIMARY KEY (`COMPENSATE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='金券补偿日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_gold_comp`
--

LOCK TABLES `log_gold_comp` WRITE;
/*!40000 ALTER TABLE `log_gold_comp` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_gold_comp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_gold_comp_approval`
--

DROP TABLE IF EXISTS `log_gold_comp_approval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_gold_comp_approval` (
  `LOG_ID` int(10) NOT NULL COMMENT '日志编号',
  `COMPENSATE_ID` int(10) NOT NULL COMMENT '金券补偿日志编号',
  `APPROVAL_NUM` int(3) NOT NULL COMMENT '审批步骤,1-1次审批,2-2次审批,100-执行',
  `APPROVAL_TIME` datetime NOT NULL COMMENT '审批时间',
  `APPROVAL_COMMENT` varchar(1024) NOT NULL COMMENT '审批意见',
  `APPROVAL_RESULT` int(3) NOT NULL COMMENT '审批结果。1- 通过。2 - 驳回；3 - 直接取消。若approval_num =100时，200 - 表示执行成功；201- 表示执行失败。',
  `OPERATOR_NAME` varchar(32) NOT NULL COMMENT '审批人姓名',
  PRIMARY KEY (`LOG_ID`),
  KEY `FK_LOG_GOLD_REFERENCE_LOG_GOLD` (`COMPENSATE_ID`),
  CONSTRAINT `FK_LOG_GOLD_REFERENCE_LOG_GOLD` FOREIGN KEY (`COMPENSATE_ID`) REFERENCES `log_gold_comp` (`COMPENSATE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='金券补偿审批日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_gold_comp_approval`
--

LOCK TABLES `log_gold_comp_approval` WRITE;
/*!40000 ALTER TABLE `log_gold_comp_approval` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_gold_comp_approval` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_multi_exp`
--

DROP TABLE IF EXISTS `log_multi_exp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_multi_exp` (
  `CHANGE_ID` int(10) NOT NULL,
  `GAME_ID` int(3) NOT NULL COMMENT '游戏编号',
  `GATEWAY_TYPE` int(3) NOT NULL COMMENT '区服类型，0-体验区，1-正式区',
  `GATEWAY_ID` int(6) NOT NULL COMMENT '网关ID',
  `SERVER_ID` int(8) NOT NULL COMMENT '线id',
  `EXP_TYPE` varchar(64) NOT NULL COMMENT '加倍经验类型',
  `EXP_RATE` int(6) NOT NULL COMMENT '经验加倍的倍率',
  `START_TIME` datetime NOT NULL,
  `END_TIME` datetime NOT NULL,
  `STOP_TIME` datetime DEFAULT NULL COMMENT '人工停止时间',
  `STATE` int(3) NOT NULL COMMENT '1-未被gmserver接收，2-已被gmserver接收，3-执行中，4-执行完毕，5-人工停止',
  `OPERATOR_NAME` varchar(32) NOT NULL COMMENT '操作员名称',
  `INSERT_TIME` datetime NOT NULL COMMENT '操作时间',
  `STOP_OPER_NAME` varchar(32) DEFAULT NULL COMMENT '结束操作员名称',
  `REASON` varchar(2048) NOT NULL,
  `EXP_TYPE_CODE` varchar(32) NOT NULL COMMENT '加倍经验类型code',
  `BOOKING` int(3) NOT NULL DEFAULT '-1' COMMENT '即时预约',
  `APPROVAL_RESULT` int(3) NOT NULL DEFAULT '-1' COMMENT '审批结果。-1-未进行审批.1- 通过。2 - 驳回；3 - 直接取消。若state=101时，200 - 表示执行成功；201 - 表示执行失败。',
  `OPER_STATE` int(3) NOT NULL DEFAULT '-1' COMMENT '状态,0 - 草稿，1 - 已提交审批,等待审批一；2- 等待审批二；100 - 通过审批；101 - 已执行操作。-1 - 表示删除。',
  PRIMARY KEY (`CHANGE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='记录设置双倍经验日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_multi_exp`
--

LOCK TABLES `log_multi_exp` WRITE;
/*!40000 ALTER TABLE `log_multi_exp` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_multi_exp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_multi_exp_approval`
--

DROP TABLE IF EXISTS `log_multi_exp_approval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_multi_exp_approval` (
  `LOG_ID` int(10) NOT NULL COMMENT '日志编号',
  `COMPENSATE_ID` int(10) NOT NULL COMMENT '双倍经验日志编号',
  `APPROVAL_NUM` int(3) NOT NULL COMMENT '审批步骤,1-1次审批,2-2次审批,100-执行',
  `APPROVAL_TIME` datetime NOT NULL COMMENT '审批时间',
  `APPROVAL_COMMENT` varchar(1024) NOT NULL COMMENT '审批意见',
  `APPROVAL_RESULT` int(3) NOT NULL COMMENT '审批结果。1- 通过。2 - 驳回；3 - 直接取消。若approval_num =100时，200 - 表示执行成功；201- 表示执行失败。',
  `OPERATOR_NAME` varchar(32) NOT NULL,
  PRIMARY KEY (`LOG_ID`),
  KEY `FK_LOG_MULTI_EXP_APPROVAL` (`COMPENSATE_ID`),
  CONSTRAINT `FK_LOG_MULTI_EXP_APPROVAL` FOREIGN KEY (`COMPENSATE_ID`) REFERENCES `log_multi_exp` (`CHANGE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='双倍经验审批日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_multi_exp_approval`
--

LOCK TABLES `log_multi_exp_approval` WRITE;
/*!40000 ALTER TABLE `log_multi_exp_approval` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_multi_exp_approval` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_multi_exp_detail`
--

DROP TABLE IF EXISTS `log_multi_exp_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_multi_exp_detail` (
  `CHANGE_ID` int(10) NOT NULL COMMENT '双倍经验设置id',
  `GATEWAY_ID` int(6) NOT NULL COMMENT '网关id',
  `SERVER_ID` int(8) NOT NULL COMMENT '线id',
  `STATE` int(3) NOT NULL COMMENT '1-未被gmserver接收，2-已被gmserver接收，3-执行中，4-执行完毕，5-人工停止',
  `EXECUTIVE_TIME` datetime DEFAULT NULL COMMENT 'gm执行的时间',
  `STOP_TIME` datetime DEFAULT NULL COMMENT 'gm成功停止时间',
  PRIMARY KEY (`CHANGE_ID`,`SERVER_ID`,`GATEWAY_ID`),
  CONSTRAINT `FK_LOG_MULT_REFERENCE_LOG_MULT` FOREIGN KEY (`CHANGE_ID`) REFERENCES `log_multi_exp` (`CHANGE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='多倍经验设置详情';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_multi_exp_detail`
--

LOCK TABLES `log_multi_exp_detail` WRITE;
/*!40000 ALTER TABLE `log_multi_exp_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_multi_exp_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_news`
--

DROP TABLE IF EXISTS `log_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_news` (
  `NEWS_ID` int(10) NOT NULL COMMENT '新闻id',
  `GAME_ID` int(3) NOT NULL COMMENT '游戏编号',
  `GATEWAY_TYPE` int(3) NOT NULL COMMENT '网关类型，0-体验区，1-正式区',
  `TITLE` varchar(512) NOT NULL COMMENT '标题',
  `GATEWAY_ID` int(6) NOT NULL COMMENT '网关ID',
  `SERVER_ID` int(8) NOT NULL COMMENT '线id',
  `START_TIME` datetime NOT NULL COMMENT '开始时间',
  `END_TIME` datetime NOT NULL COMMENT '结束时间',
  `INTERVALS` int(10) NOT NULL COMMENT '发送时间间隔',
  `CONTENT` varchar(2048) NOT NULL COMMENT '内容',
  `TOTAL_TIMES` int(10) NOT NULL COMMENT '总共执行次数',
  `STATE` int(3) NOT NULL COMMENT '1-未被gmserver接收，2-已被gmserver接收，3-执行中，4-已执行完毕，5-已撤销',
  `CANCEL_TIME` datetime DEFAULT NULL COMMENT '撤销时间',
  `OPERATOR_NAME` varchar(32) NOT NULL COMMENT '添加人名称',
  `INSERT_TIME` datetime NOT NULL COMMENT '添加时间',
  `CANCEL_OPER_NAME` varchar(32) DEFAULT NULL COMMENT '撤销人名称',
  PRIMARY KEY (`NEWS_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='记录发布新闻日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_news`
--

LOCK TABLES `log_news` WRITE;
/*!40000 ALTER TABLE `log_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_news_detail`
--

DROP TABLE IF EXISTS `log_news_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_news_detail` (
  `NEWS_ID` int(10) NOT NULL COMMENT '新闻id',
  `GATEWAY_ID` int(6) NOT NULL COMMENT '网关id',
  `SERVER_ID` int(8) NOT NULL COMMENT '线id',
  `EXECUTIVE_TIMES` int(10) NOT NULL COMMENT '执行次数',
  `SUCCESS_TIMES` int(10) NOT NULL COMMENT '成功次数',
  `LAST_EXECUTE_TIME` datetime DEFAULT NULL COMMENT '上一次执行的时间',
  `STATE` decimal(3,0) DEFAULT NULL COMMENT '1-未被gmserver接收，2-已被gmserver接收，3-执行中，4-已执行完毕，5-已撤销',
  `CANCEL_TIME` datetime DEFAULT NULL COMMENT 'gm成功撤销时间',
  PRIMARY KEY (`NEWS_ID`,`GATEWAY_ID`,`SERVER_ID`),
  CONSTRAINT `FK_LOG_NEWS_REFERENCE_LOG_NEWS` FOREIGN KEY (`NEWS_ID`) REFERENCES `log_news` (`NEWS_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='游戏详情';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_news_detail`
--

LOCK TABLES `log_news_detail` WRITE;
/*!40000 ALTER TABLE `log_news_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_news_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_online_gm`
--

DROP TABLE IF EXISTS `log_online_gm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_online_gm` (
  `GM_ID` int(10) NOT NULL,
  `PASSPORT_NAME` varchar(32) NOT NULL COMMENT '从passport系统读取',
  `REAL_NAME` varchar(64) NOT NULL COMMENT '真实名称',
  `CREATE_TIME` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '创建时间',
  `LOGIN_IP` varchar(1024) DEFAULT NULL COMMENT '绑定的登录ip',
  `EMAIL` varchar(128) NOT NULL COMMENT '电子邮箱',
  `ACOUNT_TYPE` int(10) DEFAULT '0' COMMENT '甯愬彿绫诲瀷',
  PRIMARY KEY (`GM_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_online_gm`
--

LOCK TABLES `log_online_gm` WRITE;
/*!40000 ALTER TABLE `log_online_gm` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_online_gm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_paymoneyall_approval`
--

DROP TABLE IF EXISTS `log_paymoneyall_approval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_paymoneyall_approval` (
  `LOG_ID` int(10) NOT NULL COMMENT '日志编号',
  `COMPENSATE_ID` int(10) NOT NULL COMMENT '技能补偿日志编号',
  `APPROVAL_NUM` int(3) NOT NULL COMMENT '审批步骤,1-1次审批,2-2次审批,100-执行',
  `APPROVAL_TIME` datetime NOT NULL COMMENT '审批时间',
  `APPROVAL_COMMENT` varchar(1024) NOT NULL COMMENT '审批意见',
  `APPROVAL_RESULT` int(3) NOT NULL COMMENT '审批结果。1- 通过。2 - 驳回；3 - 直接取消。若approval_num =100时，200 - 表示执行成功；201- 表示执行失败。',
  `OPERATOR_NAME` varchar(32) NOT NULL COMMENT '审批人姓名',
  PRIMARY KEY (`LOG_ID`),
  KEY `FK_LOG_PAYMONEYALL_APPROVAL` (`COMPENSATE_ID`),
  CONSTRAINT `FK_LOG_PAYMONEYALL_APPROVAL` FOREIGN KEY (`COMPENSATE_ID`) REFERENCES `log_paymoneyall_comp` (`COMPENSATE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='全区性质金钱补偿审批日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_paymoneyall_approval`
--

LOCK TABLES `log_paymoneyall_approval` WRITE;
/*!40000 ALTER TABLE `log_paymoneyall_approval` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_paymoneyall_approval` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_paymoneyall_comp`
--

DROP TABLE IF EXISTS `log_paymoneyall_comp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_paymoneyall_comp` (
  `COMPENSATE_ID` int(10) NOT NULL COMMENT '日志id',
  `GAME_ID` int(3) NOT NULL COMMENT '游戏编号',
  `GATEWAY_TYPE` int(3) NOT NULL COMMENT '区服类型,0-体验区,1-正式区',
  `GATEWAY_ID` int(10) NOT NULL COMMENT '网关ID,0-全区全服',
  `SERVER_ID` int(10) NOT NULL COMMENT '所在线',
  `MONEY_TYPE` int(10) NOT NULL COMMENT '金钱类型',
  `MONEY_NUM` int(10) NOT NULL COMMENT '金钱数目',
  `REASON` varchar(1024) NOT NULL COMMENT '补偿原因',
  `STATE` int(3) NOT NULL COMMENT '状态,0 - 草稿，1 - 已提交审批,等待审批一；2- 等待审批二；100 - 通过审批；101 - 已执行操作。-1 - 表示删除。',
  `APPROVAL_RESULT` int(3) NOT NULL COMMENT '审批结果。-1-未进行审批.1- 通过。2 - 驳回；3 - 直接取消。若state=101时，200 - 表示执行成功；201 - 表示执行失败。',
  `OPERATOR_NAME` varchar(32) NOT NULL COMMENT '操作员名称',
  `INSERT_TIME` datetime NOT NULL COMMENT '记录插入时间',
  PRIMARY KEY (`COMPENSATE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='全区性质金钱补偿表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_paymoneyall_comp`
--

LOCK TABLES `log_paymoneyall_comp` WRITE;
/*!40000 ALTER TABLE `log_paymoneyall_comp` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_paymoneyall_comp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_pet_comp`
--

DROP TABLE IF EXISTS `log_pet_comp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_pet_comp` (
  `COMPENSATE_ID` int(10) NOT NULL COMMENT '日志id',
  `GAME_ID` int(3) NOT NULL COMMENT '游戏编号',
  `GATEWAY_TYPE` int(3) NOT NULL COMMENT '区服类型,0-体验区,1-正式区',
  `MENU_VALUE_ID` int(12) NOT NULL COMMENT '动态菜单值id',
  `GATEWAY_ID` int(6) NOT NULL COMMENT '网关ID,0-全区全服',
  `SERVER_ID` int(8) NOT NULL COMMENT '线ID',
  `PASSPORT_NAME` varchar(32) NOT NULL COMMENT '玩家账号名称',
  `ROLE_NAME` varchar(32) NOT NULL COMMENT '角色名称',
  `ROLE_ID` int(10) NOT NULL COMMENT '角色id',
  `OPER_TYPE` varchar(16) NOT NULL COMMENT '操作类型，添加或者修改',
  `REASON` varchar(1024) NOT NULL COMMENT '补偿原因',
  `STATE` int(3) NOT NULL COMMENT '状态,0 - 草稿，1 - 已提交审批,等待审批一；2- 等待审批二；100 - 通过审批；101 - 已执行操作。-1 - 表示删除。',
  `APPROVAL_RESULT` int(3) NOT NULL COMMENT '审批结果。-1-未进行审批.1- 通过。2 - 驳回；3 - 直接取消。若state=101时，200 - 表示执行成功；201 - 表示执行失败。',
  `OPERATOR_NAME` varchar(32) NOT NULL COMMENT '操作员名称',
  `INSERT_TIME` datetime NOT NULL COMMENT '记录插入时间',
  PRIMARY KEY (`COMPENSATE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='随处补偿日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_pet_comp`
--

LOCK TABLES `log_pet_comp` WRITE;
/*!40000 ALTER TABLE `log_pet_comp` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_pet_comp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_pet_comp_approval`
--

DROP TABLE IF EXISTS `log_pet_comp_approval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_pet_comp_approval` (
  `LOG_ID` int(10) NOT NULL COMMENT '日志编号',
  `COMPENSATE_ID` int(10) NOT NULL COMMENT '补偿日志编号',
  `APPROVAL_NUM` int(3) NOT NULL COMMENT '审批步骤,1-1次审批,2-2次审批,100-执行',
  `APPROVAL_TIME` datetime NOT NULL COMMENT '审批时间',
  `APPROVAL_COMMENT` varchar(1024) NOT NULL COMMENT '审批意见',
  `APPROVAL_RESULT` int(3) NOT NULL COMMENT '审批结果。1- 通过。2 - 驳回；3 - 直接取消。若approval_num =100时，200 - 表示执行成功；201- 表示执行失败。',
  `OPERATOR_NAME` varchar(32) NOT NULL COMMENT '审批人姓名',
  PRIMARY KEY (`LOG_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='随处补偿审批日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_pet_comp_approval`
--

LOCK TABLES `log_pet_comp_approval` WRITE;
/*!40000 ALTER TABLE `log_pet_comp_approval` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_pet_comp_approval` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_pet_menu_value`
--

DROP TABLE IF EXISTS `log_pet_menu_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_pet_menu_value` (
  `MENU_VALUE_ID` int(12) NOT NULL COMMENT '动态菜单值id',
  `ITEM_NAME` varchar(16) NOT NULL COMMENT '菜单项名称',
  `ITEM_VALUE` varchar(32) DEFAULT NULL COMMENT '菜单值',
  PRIMARY KEY (`MENU_VALUE_ID`,`ITEM_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='记录随处补偿生成时动态菜单的值';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_pet_menu_value`
--

LOCK TABLES `log_pet_menu_value` WRITE;
/*!40000 ALTER TABLE `log_pet_menu_value` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_pet_menu_value` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_product`
--

DROP TABLE IF EXISTS `log_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_product` (
  `PRODUCT_ID` int(10) NOT NULL COMMENT '道具id',
  `GAME_ID` int(3) NOT NULL COMMENT '游戏编号',
  `GATEWAY_TYPE` int(3) NOT NULL COMMENT '网关类型，0-体验区，1-正式区',
  `PRODUCT_CODE` varchar(32) NOT NULL COMMENT '道具编号',
  `PRODUCT_NAME` varchar(32) NOT NULL COMMENT '道具名称',
  `PRODUCT_SUB_CLASS` int(4) NOT NULL COMMENT '道具子类',
  `PRODUCT_LEVEL` int(3) NOT NULL COMMENT '道具等级',
  `PRODUCT_USE_TYPE` int(1) NOT NULL COMMENT '道具使用类型',
  `PRODUCT_PERIOD` int(10) NOT NULL COMMENT '道具期限',
  `PRODUCT_ATTRIBUTES` varchar(64) DEFAULT NULL COMMENT '道具属性',
  `PRODUCT_CLASS` int(2) NOT NULL COMMENT '道具类别',
  `START_TIME` datetime DEFAULT NULL COMMENT '开始时间',
  `END_TIME` datetime DEFAULT NULL COMMENT '结束时间',
  `PRODUCT_DESC` varchar(4000) NOT NULL COMMENT '道具描述',
  `STATE` int(3) NOT NULL COMMENT '1-未被gmserver接收，2-已被gmserver接收，3-未激活，4-已激活，5-已禁用',
  `INSERT_OPERATOR_NAME` varchar(32) NOT NULL COMMENT '添加人名称',
  `START_OPERATOR_NAME` varchar(32) DEFAULT NULL COMMENT '开始人',
  `INSERT_TIME` datetime NOT NULL COMMENT '添加时间',
  `END_OPERATOR_NAME` varchar(32) DEFAULT NULL COMMENT '撤销人名称',
  PRIMARY KEY (`PRODUCT_ID`),
  UNIQUE KEY `INDEX_1` (`GAME_ID`,`GATEWAY_TYPE`,`PRODUCT_CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='记录添加道具日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_product`
--

LOCK TABLES `log_product` WRITE;
/*!40000 ALTER TABLE `log_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_product_price`
--

DROP TABLE IF EXISTS `log_product_price`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_product_price` (
  `PRICE_ID` int(10) NOT NULL COMMENT '价格id',
  `PRODUCT_ID` int(10) NOT NULL COMMENT '道具id',
  `SUBJECT_ID` int(4) NOT NULL COMMENT '货币类型',
  `PRICE_ORIGIN` int(10) NOT NULL COMMENT '原价',
  `PRICE_DISCOUNT` int(10) NOT NULL COMMENT '折扣价',
  `START_TIME` datetime DEFAULT NULL COMMENT '开始时间',
  `END_TIME` datetime DEFAULT NULL COMMENT '结束时间',
  `STATE` int(3) NOT NULL COMMENT '1-未被gmserver接收，2-已被gmserver接收，3-未激活，4-已激活，5-已禁用',
  `INSERT_OPERATOR_NAME` varchar(32) NOT NULL COMMENT '添加人名称',
  `START_OPERATOR_NAME` varchar(32) DEFAULT NULL COMMENT '开始人',
  `INSERT_TIME` datetime NOT NULL COMMENT '添加时间',
  `END_OPERATOR_NAME` varchar(32) DEFAULT NULL COMMENT '撤销人名称',
  `ERATING_PRICE_ID` int(10) DEFAULT NULL COMMENT 'erating价格id',
  `LIMITNUM` int(8) DEFAULT NULL COMMENT '限量数量',
  `LIMITDATE` datetime DEFAULT NULL COMMENT '限时时间',
  PRIMARY KEY (`PRICE_ID`),
  KEY `FK_LOG_PROD_REF_LOG_PROD2` (`PRODUCT_ID`),
  CONSTRAINT `FK_LOG_PROD_REF_LOG_PROD2` FOREIGN KEY (`PRODUCT_ID`) REFERENCES `log_product` (`PRODUCT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='记录添加道具价格日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_product_price`
--

LOCK TABLES `log_product_price` WRITE;
/*!40000 ALTER TABLE `log_product_price` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_product_price` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_role_comp`
--

DROP TABLE IF EXISTS `log_role_comp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_role_comp` (
  `COMPENSATE_ID` int(10) NOT NULL COMMENT '日志id',
  `COMPENSATE_TYPE` int(3) NOT NULL COMMENT '补偿类型： 1-积分补偿',
  `GAME_ID` int(3) NOT NULL COMMENT '游戏编号',
  `GATEWAY_TYPE` int(10) NOT NULL COMMENT '区服类型,0-体验区,1-正式区',
  `GATEWAY_ID` int(3) DEFAULT '-1' COMMENT '网关id，若对应的sys_role_comp_type表中的为1 的时候， 才有用',
  `SERVICE_ID` int(10) NOT NULL COMMENT '玩家ID',
  `PASSPORT_NAME` varchar(32) NOT NULL COMMENT '玩家账号名称',
  `REASON` varchar(1024) NOT NULL COMMENT '补偿原因',
  `STATE` int(3) NOT NULL COMMENT '状态,0 - 草稿，1 - 已提交审批,等待审批一；2- 等待审批二；100 - 通过审批；101 - 已执行操作。-1 - 表示删除。',
  `APPROVAL_RESULT` int(3) NOT NULL COMMENT '审批结果。-1-未进行审批.1- 通过。2 - 驳回；3 - 直接取消。若state=101时，200 - 表示执行成功；201 - 表示执行失败。',
  `INSERT_TIME` datetime NOT NULL COMMENT '记录插入时间',
  `DIVIDED_TYPE` int(3) NOT NULL COMMENT '改补偿所属的分类(0表示该补偿下面没有分类)',
  PRIMARY KEY (`COMPENSATE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='角色补偿日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_role_comp`
--

LOCK TABLES `log_role_comp` WRITE;
/*!40000 ALTER TABLE `log_role_comp` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_role_comp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_role_comp_approval`
--

DROP TABLE IF EXISTS `log_role_comp_approval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_role_comp_approval` (
  `LOG_ID` int(10) NOT NULL COMMENT '日志编号',
  `COMPENSATE_ID` int(10) NOT NULL COMMENT '补偿日志编号',
  `APPROVAL_NUM` int(3) NOT NULL COMMENT '审批步骤,1-1次审批,2-2次审批,100-执行',
  `APPROVAL_TIME` datetime NOT NULL COMMENT '审批时间',
  `APPROVAL_COMMENT` varchar(1024) NOT NULL COMMENT '审批意见',
  `APPROVAL_RESULT` int(3) NOT NULL COMMENT '审批结果。1- 通过。2 - 驳回；3 - 直接取消。若approval_num =100时，200 - 表示执行成功；201- 表示执行失败。',
  `OPERATOR_NAME` varchar(32) NOT NULL COMMENT '审批人姓名',
  PRIMARY KEY (`LOG_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='随处补偿审批日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_role_comp_approval`
--

LOCK TABLES `log_role_comp_approval` WRITE;
/*!40000 ALTER TABLE `log_role_comp_approval` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_role_comp_approval` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_role_comp_menu_value`
--

DROP TABLE IF EXISTS `log_role_comp_menu_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_role_comp_menu_value` (
  `COMPENSATE_ID` int(10) NOT NULL COMMENT '所属的补偿编号',
  `ITEM_NAME` varchar(16) NOT NULL COMMENT '菜单项名称',
  `ITEM_VALUE` varchar(32) DEFAULT NULL COMMENT '菜单值',
  PRIMARY KEY (`COMPENSATE_ID`,`ITEM_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='记录角色补偿生成时动态菜单的值';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_role_comp_menu_value`
--

LOCK TABLES `log_role_comp_menu_value` WRITE;
/*!40000 ALTER TABLE `log_role_comp_menu_value` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_role_comp_menu_value` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_role_kickoff`
--

DROP TABLE IF EXISTS `log_role_kickoff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_role_kickoff` (
  `LOG_ID` int(10) NOT NULL,
  `GAME_ID` int(3) NOT NULL COMMENT '游戏编号',
  `GATEWAY_TYPE` int(3) NOT NULL COMMENT '区服类型，0=体验区，1=正式区',
  `PASSPORT_NAME` varchar(32) DEFAULT NULL COMMENT '通行证名称',
  `ROLE_NAME` varchar(32) NOT NULL COMMENT '角色名称',
  `GATEWAY_ID` int(6) NOT NULL COMMENT '网关编号',
  `SERVER_ID` int(8) NOT NULL COMMENT '线编号',
  `STATE` int(3) NOT NULL COMMENT '状态，1 - 已踢下线；2-已恢复',
  `KICKOFF_TIME` datetime NOT NULL COMMENT '下线时间',
  `RESTORE_TIME` datetime DEFAULT NULL COMMENT '恢复时间',
  `LAST_SECONDS` int(10) NOT NULL COMMENT '下线持续时间，单位为秒\n            1分钟，5分钟，10分钟，30分钟，1小时，2小时，5小时，12小时\n            ，24小时，2天，三天，一周，一个月，！打入地狱！',
  `REASON` varchar(256) NOT NULL COMMENT '踢下线的简短原因。由下拉框选择。\n            选择项：\n            辱骂/诽谤/淫谈悖说\n            非法小广告\n            恶意刷钱/装备',
  `DESCRIPTION` varchar(1024) DEFAULT NULL COMMENT '踢下线的详细描述',
  `OPERATOR_NAME` varchar(32) NOT NULL COMMENT '操作员名称',
  `RESTORE_OPER_NAME` varchar(32) DEFAULT NULL COMMENT '恢复时，操作员的名称',
  PRIMARY KEY (`LOG_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='记录踢人日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_role_kickoff`
--

LOCK TABLES `log_role_kickoff` WRITE;
/*!40000 ALTER TABLE `log_role_kickoff` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_role_kickoff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_role_kickoff2`
--

DROP TABLE IF EXISTS `log_role_kickoff2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_role_kickoff2` (
  `LOG_ID` int(10) NOT NULL,
  `GAME_ID` int(3) NOT NULL COMMENT '游戏编号',
  `GATEWAY_TYPE` int(3) NOT NULL COMMENT '区服类型，0=体验区，1=正式区',
  `PASSPORT_NAME` varchar(32) DEFAULT NULL COMMENT '通行证名称',
  `ROLE_NAME` varchar(32) NOT NULL COMMENT '角色名称',
  `GATEWAY_ID` int(6) NOT NULL COMMENT '网关编号',
  `SERVER_ID` int(8) NOT NULL COMMENT '线编号',
  `KICKOFF_TIME` datetime NOT NULL COMMENT '下线时间',
  `REASON` varchar(256) NOT NULL COMMENT '踢下线的简短原因。由下拉框选择。\n            选择项：\n            辱骂/诽谤/淫谈悖说\n            非法小广告\n            恶意刷钱/装备',
  `DESCRIPTION` varchar(1024) DEFAULT NULL COMMENT '踢下线的详细描述',
  `OPERATOR_NAME` varchar(32) NOT NULL COMMENT '操作员名称',
  PRIMARY KEY (`LOG_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='记录踢人日志,该踢人不冻结角色';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_role_kickoff2`
--

LOCK TABLES `log_role_kickoff2` WRITE;
/*!40000 ALTER TABLE `log_role_kickoff2` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_role_kickoff2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_role_move`
--

DROP TABLE IF EXISTS `log_role_move`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_role_move` (
  `LOG_ID` int(10) NOT NULL,
  `GAME_ID` int(3) NOT NULL COMMENT '游戏编号',
  `GATEWAY_TYPE` int(3) NOT NULL COMMENT '区服类型，0=体验区，1=正式区',
  `PASSPORT_NAME` varchar(32) DEFAULT NULL COMMENT '通行证名称',
  `ROLE_NAME` varchar(32) NOT NULL COMMENT '角色名称',
  `GATEWAY_ID` int(6) NOT NULL COMMENT '网关编号',
  `SERVER_ID` int(8) NOT NULL COMMENT '线编号',
  `SCENE_NAME` varchar(64) NOT NULL COMMENT '场景名称',
  `MOVE_TIME` datetime NOT NULL COMMENT '拉人操作时间',
  `STATE` int(3) NOT NULL COMMENT '1-拉人成功，2-拉人失败',
  `REASON` varchar(256) NOT NULL COMMENT '拉人的简短原因。由下拉框选择。\n            选择项：\n            角色被卡\n             其他',
  `DESCRIPTION` varchar(1024) DEFAULT NULL COMMENT '拉人的详细描述',
  `OPERATOR_NAME` varchar(32) NOT NULL COMMENT '操作员名称',
  PRIMARY KEY (`LOG_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='记录拉人日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_role_move`
--

LOCK TABLES `log_role_move` WRITE;
/*!40000 ALTER TABLE `log_role_move` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_role_move` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_role_operation`
--

DROP TABLE IF EXISTS `log_role_operation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_role_operation` (
  `LOG_ID` int(10) NOT NULL,
  `GAME_ID` int(4) NOT NULL COMMENT '游戏编号',
  `GATEWAY_ID` int(6) NOT NULL COMMENT '网关编号',
  `ROLE_NAME` varchar(32) NOT NULL COMMENT '角色名称',
  `OPERATE_DESC` varchar(2048) DEFAULT NULL COMMENT '拉人的详细描述',
  `RESULT_CODE` int(4) NOT NULL COMMENT '0',
  `OPERATE_TYPE` int(4) NOT NULL COMMENT '操作类型',
  `OPERATE_TIME` datetime NOT NULL COMMENT '操作时间',
  `OPERATOR_NAME` varchar(32) NOT NULL COMMENT '操作员名称',
  PRIMARY KEY (`LOG_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='记录对角色的所有操作日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_role_operation`
--

LOCK TABLES `log_role_operation` WRITE;
/*!40000 ALTER TABLE `log_role_operation` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_role_operation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_role_shutup`
--

DROP TABLE IF EXISTS `log_role_shutup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_role_shutup` (
  `LOG_ID` int(10) NOT NULL,
  `GAME_ID` int(3) NOT NULL COMMENT '游戏编号',
  `GATEWAY_TYPE` int(3) NOT NULL COMMENT '区服类型，0=体验区，1=正式区',
  `PASSPORT_NAME` varchar(32) DEFAULT NULL COMMENT '通行证名称',
  `ROLE_NAME` varchar(32) NOT NULL COMMENT '角色名称',
  `GATEWAY_ID` int(6) NOT NULL COMMENT '网关编号',
  `SERVER_ID` int(8) NOT NULL COMMENT '线编号',
  `STATE` int(3) NOT NULL COMMENT '状态，1 - 已禁言；2- 已恢复',
  `CHANNEL` varchar(64) NOT NULL COMMENT '禁言频道，下拉框选择',
  `SHUTUP_TIME` datetime NOT NULL COMMENT '执行禁言的时间',
  `RESTORE_TIME` datetime DEFAULT NULL COMMENT '恢复时间',
  `LAST_SECONDS` int(10) NOT NULL COMMENT '禁言持续时间，单位为秒\n            1分钟，5分钟，10分钟，30分钟，1小时，2小时，5小时，12小时\n            ，24小时，2天，三天，一周，一个月，！打入地狱！',
  `REASON` varchar(256) NOT NULL COMMENT '禁言的简短原因。由下拉框选择。\n            选择项：\n            辱骂/诽谤/淫谈悖说\n            非法小广告\n            恶意刷钱/装备',
  `DESCRIPTION` varchar(1024) DEFAULT NULL COMMENT '禁言的详细描述',
  `OPERATOR_NAME` varchar(32) NOT NULL COMMENT '操作员名称',
  `RESTORE_OPER_NAME` varchar(32) DEFAULT NULL COMMENT '恢复时，操作员的名称',
  PRIMARY KEY (`LOG_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='记录禁言日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_role_shutup`
--

LOCK TABLES `log_role_shutup` WRITE;
/*!40000 ALTER TABLE `log_role_shutup` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_role_shutup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_serialcode`
--

DROP TABLE IF EXISTS `log_serialcode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_serialcode` (
  `LOG_ID` int(8) NOT NULL COMMENT '日志ID',
  `GAME_ID` int(3) NOT NULL COMMENT '游戏ID',
  `ACTIVITY_ID` int(8) NOT NULL COMMENT '活动号',
  `MEDIA_NAME` varchar(200) NOT NULL COMMENT '媒体名称',
  `USE_LIMIT` int(8) NOT NULL COMMENT '使用限制',
  `SERIAL_NUM` int(8) NOT NULL COMMENT '生成数量',
  `PASSPORT_NAME` varchar(200) NOT NULL COMMENT '操作人',
  `OPER_TIME` datetime NOT NULL COMMENT '操作时间',
  `FILE_PATH` varchar(200) NOT NULL COMMENT 'LOG文件路径',
  PRIMARY KEY (`LOG_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_serialcode`
--

LOCK TABLES `log_serialcode` WRITE;
/*!40000 ALTER TABLE `log_serialcode` DISABLE KEYS */;
INSERT INTO `log_serialcode` VALUES (1,1204,1514072101,'Código Promocional',0,5,'SpaceCowboy','2014-07-22 17:23:53','/home/jboss/jboss-4.0.2/activitycode1514072101_1406060633856.txt'),(2,1204,1514072101,'1',0,1,'SpaceCowboy','2014-07-22 22:56:26','/home/jboss/jboss-4.0.2/activitycode1514072101_1406080586637.txt');
/*!40000 ALTER TABLE `log_serialcode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_skill_comp`
--

DROP TABLE IF EXISTS `log_skill_comp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_skill_comp` (
  `COMPENSATE_ID` int(10) NOT NULL COMMENT '日志id',
  `GAME_ID` int(3) NOT NULL COMMENT '游戏编号',
  `GATEWAY_TYPE` int(3) NOT NULL COMMENT '区服类型,0-体验区,1-正式区',
  `ROLE_ID` int(10) NOT NULL COMMENT '角色ID',
  `ROLE_NAME` varchar(500) NOT NULL COMMENT '角色名称',
  `GATEWAY_ID` int(10) NOT NULL COMMENT '网关ID,0-全区全服',
  `SERVER_ID` int(10) NOT NULL COMMENT '所在线',
  `SKILL_ID` int(10) NOT NULL COMMENT '技能ID',
  `SKILL_NAME` varchar(500) NOT NULL COMMENT '技能名称',
  `SKILL_LEVEL` int(10) NOT NULL COMMENT '技能等级',
  `REASON` varchar(1024) NOT NULL COMMENT '补偿原因',
  `STATE` int(3) NOT NULL COMMENT '状态,0 - 草稿，1 - 已提交审批,等待审批一；2- 等待审批二；100 - 通过审批；101 - 已执行操作。-1 - 表示删除。',
  `APPROVAL_RESULT` int(3) NOT NULL COMMENT '审批结果。-1-未进行审批.1- 通过。2 - 驳回；3 - 直接取消。若state=101时，200 - 表示执行成功；201 - 表示执行失败。',
  `OPERATOR_NAME` varchar(32) NOT NULL COMMENT '操作员名称',
  `INSERT_TIME` datetime NOT NULL COMMENT '记录插入时间',
  PRIMARY KEY (`COMPENSATE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='技能补偿日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_skill_comp`
--

LOCK TABLES `log_skill_comp` WRITE;
/*!40000 ALTER TABLE `log_skill_comp` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_skill_comp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_skill_comp_approval`
--

DROP TABLE IF EXISTS `log_skill_comp_approval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_skill_comp_approval` (
  `LOG_ID` int(10) NOT NULL COMMENT '日志编号',
  `COMPENSATE_ID` int(10) NOT NULL COMMENT '技能补偿日志编号',
  `APPROVAL_NUM` int(3) NOT NULL COMMENT '审批步骤,1-1次审批,2-2次审批,100-执行',
  `APPROVAL_TIME` datetime NOT NULL COMMENT '审批时间',
  `APPROVAL_COMMENT` varchar(1024) NOT NULL COMMENT '审批意见',
  `APPROVAL_RESULT` int(3) NOT NULL COMMENT '审批结果。1- 通过。2 - 驳回；3 - 直接取消。若approval_num =100时，200 - 表示执行成功；201- 表示执行失败。',
  `OPERATOR_NAME` varchar(32) NOT NULL COMMENT '审批人姓名',
  PRIMARY KEY (`LOG_ID`),
  KEY `FK_LOG_SKILL_COMP_APPROVAL` (`COMPENSATE_ID`),
  CONSTRAINT `FK_LOG_SKILL_COMP_APPROVAL` FOREIGN KEY (`COMPENSATE_ID`) REFERENCES `log_skill_comp` (`COMPENSATE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='技能补偿审批日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_skill_comp_approval`
--

LOCK TABLES `log_skill_comp_approval` WRITE;
/*!40000 ALTER TABLE `log_skill_comp_approval` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_skill_comp_approval` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_syn_charge_activity`
--

DROP TABLE IF EXISTS `log_syn_charge_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_syn_charge_activity` (
  `ACTIVITY_ID` int(10) NOT NULL,
  `GAME_ID` int(3) NOT NULL,
  `SRC_ACTIVITY_ID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='充值活动同步记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_syn_charge_activity`
--

LOCK TABLES `log_syn_charge_activity` WRITE;
/*!40000 ALTER TABLE `log_syn_charge_activity` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_syn_charge_activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_syn_charge_give_item`
--

DROP TABLE IF EXISTS `log_syn_charge_give_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_syn_charge_give_item` (
  `ACTIVITY_ID` int(10) DEFAULT NULL,
  `GAME_ID` int(3) DEFAULT NULL,
  `SRC_ACTIVITY_TYPE_ID` int(10) DEFAULT NULL,
  `SRC_GAME_ID` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='网站活动同步记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_syn_charge_give_item`
--

LOCK TABLES `log_syn_charge_give_item` WRITE;
/*!40000 ALTER TABLE `log_syn_charge_give_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_syn_charge_give_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_syn_oper`
--

DROP TABLE IF EXISTS `log_syn_oper`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_syn_oper` (
  `LOG_ID` int(8) NOT NULL COMMENT '操作日志id',
  `LOG_OPER_TYPE` int(8) NOT NULL COMMENT '操作类型(1表示同步网关,2表示同步服务器,3表示同步passport)',
  `LOG_OPER_ID` int(8) NOT NULL COMMENT '操作人员',
  `LOG_TIME` datetime DEFAULT NULL COMMENT '操作时间',
  `LOG_SOURCE_GAME_ID` int(6) NOT NULL COMMENT '同步源游戏',
  `LOG_TARGET_GAME_ID` int(6) NOT NULL,
  PRIMARY KEY (`LOG_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='同步操作详情';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_syn_oper`
--

LOCK TABLES `log_syn_oper` WRITE;
/*!40000 ALTER TABLE `log_syn_oper` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_syn_oper` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_transfer`
--

DROP TABLE IF EXISTS `log_transfer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_transfer` (
  `change_id` int(10) NOT NULL AUTO_INCREMENT,
  `GAME_ID` int(3) NOT NULL COMMENT '游戏编号',
  `GATEWAY_TYPE` int(3) NOT NULL COMMENT '区服类型,0-体验区,1-正式区',
  `PASSPORT_NAME` varchar(32) NOT NULL COMMENT '帐号名',
  `FROM_GATEWAY_ID` int(6) NOT NULL COMMENT '转出的网关id',
  `TO_GATEWAY_ID` int(6) NOT NULL COMMENT '转入的网关id',
  `order_id` varchar(32) DEFAULT NULL,
  `STATE` int(3) NOT NULL COMMENT '状态,0 - 草稿，1 - 已提交审批,等待审批一；2- 等待审批二；100 - 通过审批；101 - 已执行操作。-1 - 表示删除。',
  `APPROVAL_RESULT` int(3) NOT NULL COMMENT '审批结果。-1-未进行审批.1- 通过。2 - 驳回；3 - 直接取消。若state=101时，200 - 表示执行成功；201 - 表示执行失败。',
  `REASON` varchar(1024) NOT NULL COMMENT '修改原因',
  `OPERATOR_NAME` varchar(32) NOT NULL COMMENT '操作员名称',
  `INSERT_TIME` datetime NOT NULL COMMENT '记录插入时间',
  PRIMARY KEY (`change_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='转账日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_transfer`
--

LOCK TABLES `log_transfer` WRITE;
/*!40000 ALTER TABLE `log_transfer` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_transfer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_transfer_approval`
--

DROP TABLE IF EXISTS `log_transfer_approval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_transfer_approval` (
  `log_id` int(10) NOT NULL AUTO_INCREMENT,
  `CHANGE_ID` int(10) NOT NULL COMMENT '转账日志编号',
  `APPROVAL_NUM` int(3) NOT NULL COMMENT '审批步骤,1-1次审批,2-2次审批,100-执行',
  `APPROVAL_TIME` datetime NOT NULL COMMENT '审批时间',
  `APPROVAL_COMMENT` varchar(1024) NOT NULL COMMENT '审批意见',
  `APPROVAL_RESULT` int(3) NOT NULL COMMENT '审批结果。1- 通过。2 - 驳回；3 - 直接取消。若approval_num =100时，200 - 表示执行成功；201- 表示执行失败。',
  `OPERATOR_NAME` varchar(32) NOT NULL COMMENT '审批人姓名',
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='转账审批日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_transfer_approval`
--

LOCK TABLES `log_transfer_approval` WRITE;
/*!40000 ALTER TABLE `log_transfer_approval` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_transfer_approval` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_trustee_account`
--

DROP TABLE IF EXISTS `log_trustee_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_trustee_account` (
  `LOG_ID` int(10) NOT NULL COMMENT '日志id',
  `GAME_ID` int(3) NOT NULL COMMENT '游戏编号',
  `GATEWAY_TYPE` int(3) NOT NULL COMMENT '网关类型，0-体验区，1-正式区',
  `PASSPORT_NAME` varchar(32) NOT NULL COMMENT 'passport_name',
  `TRUSTEE_TIME` datetime NOT NULL COMMENT '托管时间',
  `RESTORE_TIME` datetime DEFAULT NULL COMMENT '恢复时间',
  `REASON` varchar(256) NOT NULL COMMENT '托管原因',
  `ALLOW_IP` varchar(32) NOT NULL COMMENT '登陆ip',
  `TRUSTEE_TYPE` int(3) NOT NULL COMMENT '托管类型，0- 登录托管，1-登录和二级密码同时托管',
  `STATE` int(3) NOT NULL COMMENT '状态，1-托管中，2-已恢复',
  `OPERATOR_NAME` varchar(32) NOT NULL COMMENT '托管操作人',
  `RESTORE_OPER_NAME` varchar(32) DEFAULT NULL COMMENT '恢复操作人',
  PRIMARY KEY (`LOG_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='托管帐号日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_trustee_account`
--

LOCK TABLES `log_trustee_account` WRITE;
/*!40000 ALTER TABLE `log_trustee_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_trustee_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_trustee_account_detail`
--

DROP TABLE IF EXISTS `log_trustee_account_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_trustee_account_detail` (
  `LOG_ID` int(10) NOT NULL COMMENT '日志id',
  `GATEWAY_ID` int(6) NOT NULL COMMENT '网关id',
  `STATE` int(3) NOT NULL COMMENT '1-未被gmserver接收，2-已被gmserver接收，3-执行中，4-执行完毕，5-人工停止',
  `TRUSTEE_TIME` datetime DEFAULT NULL COMMENT 'gm执行的时间',
  `RESTORE_TIME` datetime DEFAULT NULL COMMENT '成功停止时间',
  PRIMARY KEY (`LOG_ID`,`GATEWAY_ID`),
  CONSTRAINT `FK_LOG_TRUS_REFERENCE_LOG_TRUS` FOREIGN KEY (`LOG_ID`) REFERENCES `log_trustee_account` (`LOG_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='托管账号详情';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_trustee_account_detail`
--

LOCK TABLES `log_trustee_account_detail` WRITE;
/*!40000 ALTER TABLE `log_trustee_account_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_trustee_account_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_union_gateway`
--

DROP TABLE IF EXISTS `log_union_gateway`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_union_gateway` (
  `OLD_GATEWAY_ID` int(6) NOT NULL COMMENT '要被合并的网关id',
  `OLD_GATEWAY_NAME` varchar(256) DEFAULT NULL COMMENT '要被合并的网关名称',
  `NEW_GATEWAY_ID` int(6) NOT NULL COMMENT '新的合并的网关id',
  `NEW_GATEWAY_NAME` varchar(256) DEFAULT NULL COMMENT '新的合并的网关名称',
  `GAME_ID` int(3) NOT NULL COMMENT '游戏id',
  `BEGIN_TIME` datetime DEFAULT NULL COMMENT '合服开始时间',
  `END_TIME` datetime DEFAULT NULL COMMENT '合服结束时间',
  `STATE` int(2) DEFAULT '-1' COMMENT '合服状态：-1 未执行。 0 正在执行。1 合服任务成功结束  2合服任务异常结束',
  `OPERATOR` varchar(32) DEFAULT NULL COMMENT '操作人的passportName',
  `INSERT_TIME` datetime DEFAULT NULL COMMENT '任务插入时间',
  `INSERT_OPERATOR` varchar(32) DEFAULT NULL COMMENT '插入人的passportName',
  `TASK_ID` int(6) NOT NULL DEFAULT '-1' COMMENT '所属的合服计划id',
  PRIMARY KEY (`OLD_GATEWAY_ID`,`NEW_GATEWAY_ID`,`GAME_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='网关合服表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_union_gateway`
--

LOCK TABLES `log_union_gateway` WRITE;
/*!40000 ALTER TABLE `log_union_gateway` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_union_gateway` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_union_gateway_task`
--

DROP TABLE IF EXISTS `log_union_gateway_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_union_gateway_task` (
  `TASK_ID` int(6) NOT NULL,
  `TASK_NAME` varchar(256) NOT NULL COMMENT '合服计划名称',
  `LAST_BACK_TIME_BEGIN` datetime DEFAULT NULL COMMENT '合服计划上一次  备份开始时间',
  `LAST_BACK_TIME_END` datetime DEFAULT NULL COMMENT '合服计划 上一次 备份结束时间',
  `BACK_STATUS` int(2) DEFAULT '-1' COMMENT '备份状态',
  `EXE_STATUS` int(2) DEFAULT '-1' COMMENT '执行状态',
  `BACK_TIME_BEGIN` datetime DEFAULT NULL COMMENT '当前备份最后开始时间',
  `BACK_TIME_END` datetime DEFAULT NULL COMMENT '当前备份最后结束时间',
  `BACK_OPERATOR` varchar(32) DEFAULT NULL COMMENT '备份人',
  `EXE_OPERATOR` varchar(32) DEFAULT NULL COMMENT '执行人',
  `EXE_TIME_BEGIN` datetime DEFAULT NULL COMMENT '执行的开始时间',
  `EXE_TIME_END` datetime DEFAULT NULL COMMENT '执行的结束时间',
  `GAME_ID` int(3) NOT NULL,
  `INSERT_TIME` datetime DEFAULT NULL,
  PRIMARY KEY (`TASK_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_union_gateway_task`
--

LOCK TABLES `log_union_gateway_task` WRITE;
/*!40000 ALTER TABLE `log_union_gateway_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_union_gateway_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_user_operations`
--

DROP TABLE IF EXISTS `log_user_operations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_user_operations` (
  `LOG_ID` int(15) NOT NULL AUTO_INCREMENT COMMENT '序列',
  `PASSPORT_ID` int(10) NOT NULL COMMENT 'passport ID',
  `PASSPORT_NAME` varchar(32) NOT NULL COMMENT 'passport帐号名',
  `OPER_REAL_NAME` varchar(64) DEFAULT NULL COMMENT '操作员真名',
  `OPER_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '操作时间',
  `OPER_IP` varchar(32) DEFAULT NULL COMMENT '操作者的IP',
  `RESULT_CODE` int(3) NOT NULL COMMENT '执行结果，1-成功，2-失败',
  `OPER_DESC` varchar(2048) NOT NULL COMMENT '操作描述',
  `OPER_TYPE` varchar(64) NOT NULL COMMENT '操作类型',
  `GAME_ID` int(8) DEFAULT NULL COMMENT '游戏ID',
  `PLAYER_NAME` varchar(50) DEFAULT NULL COMMENT '玩家帐号',
  `ROLE_NAME` varchar(50) DEFAULT NULL COMMENT '角色名称',
  `GATEWAY_ID` int(8) DEFAULT NULL COMMENT '网关ID',
  `GATEWAY_NAME` varchar(1024) DEFAULT NULL COMMENT '网关名称',
  `REASON` varchar(500) DEFAULT NULL COMMENT '原因',
  PRIMARY KEY (`LOG_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=200 DEFAULT CHARSET=utf8 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_user_operations`
--

LOCK TABLES `log_user_operations` WRITE;
/*!40000 ALTER TABLE `log_user_operations` DISABLE KEYS */;
INSERT INTO `log_user_operations` VALUES (1,1072508,'SpaceCowboy','SpaceCowboy','2013-07-23 03:19:47','177.47.22.70',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(2,1072508,'SpaceCowboy','SpaceCowboy','2013-07-23 03:34:50','177.47.22.70',1,'Switch account login successful','Switch User Login',1204,NULL,NULL,0,'server0',NULL),(3,1072508,'SpaceCowboy','SpaceCowboy','2013-07-23 03:34:58','177.47.22.70',1,'Switch account login successful','Switch User Login',1204,NULL,NULL,0,'server0',NULL),(4,1072508,'SpaceCowboy','SpaceCowboy','2013-07-23 06:00:29','177.47.22.70',1,'Switch account login successful','Switch User Login',1204,NULL,NULL,0,'server0',NULL),(5,1072508,'SpaceCowboy','SpaceCowboy','2013-07-23 06:00:51','177.47.22.70',1,'Switch account login successful','Switch User Login',1204,NULL,NULL,0,'server0',NULL),(6,1072508,'SpaceCowboy','SpaceCowboy','2013-07-23 06:01:07','177.47.22.70',1,'Switch account login successful','Switch User Login',1204,NULL,NULL,0,'server0',NULL),(7,1072508,'SpaceCowboy','SpaceCowboy','2013-11-18 03:44:45','113.208.129.51',1,'用户登录成功','用户登录',1204,NULL,NULL,0,'server0',NULL),(8,1072508,'SpaceCowboy','SpaceCowboy','2013-11-18 03:45:58','113.208.129.51',1,'添加系统角色成功，角色名：Brazil','添加系统角色',0,NULL,NULL,0,'server0',NULL),(9,1072508,'SpaceCowboy','SpaceCowboy','2013-11-18 03:46:11','113.208.129.51',1,'配置系统角色权限成功，角色Id：2','配置角色权限',0,NULL,NULL,0,'server0',NULL),(10,1072508,'SpaceCowboy','SpaceCowboy','2013-11-18 03:47:32','113.208.129.51',1,'添加用户成功，用户:globalgames1','添加用户',0,NULL,NULL,0,'server0',NULL),(11,1072508,'SpaceCowboy','SpaceCowboy','2013-11-18 03:47:40','113.208.129.51',1,'配置用户角色成功，用户Id：432712651','配置用户角色',0,NULL,NULL,0,'server0',NULL),(12,432712651,'globalgames1','111','2013-11-18 03:49:05','113.208.129.51',1,'用户登录成功','用户登录',1204,NULL,NULL,0,'server0',NULL),(13,-1,'未知','未知','2013-11-18 03:52:25','119.147.146.189',2,'试图匿名访问资源或登录超时：/generaterandomcode.do','访问控制',0,NULL,NULL,0,'server0',NULL),(14,1072508,'SpaceCowboy','SpaceCowboy','2013-12-19 01:18:18','218.213.93.70',1,'用户登录成功','用户登录',1204,NULL,NULL,0,'server0',NULL),(15,1072508,'SpaceCowboy','SpaceCowboy','2013-12-19 02:49:52','218.213.93.70',1,'用户登录成功','用户登录',1204,NULL,NULL,0,'server0',NULL),(16,1072508,'SpaceCowboy','SpaceCowboy','2013-12-19 03:08:14','218.213.93.70',1,'添加用户成功，用户:braziltest1','添加用户',0,NULL,NULL,0,'server0',NULL),(17,1072508,'SpaceCowboy','SpaceCowboy','2013-12-19 03:08:23','218.213.93.70',1,'删除用户成功，用户Id：432712652','删除用户',0,NULL,NULL,0,'server0',NULL),(18,1072508,'SpaceCowboy','SpaceCowboy','2013-12-19 03:10:43','218.213.93.70',1,'用户登录成功','用户登录',1204,NULL,NULL,0,'server0',NULL),(19,1072508,'SpaceCowboy','SpaceCowboy','2013-12-19 03:11:20','218.213.93.70',1,'添加用户成功，用户:braziltest1','添加用户',0,NULL,NULL,0,'server0',NULL),(20,1072508,'SpaceCowboy','SpaceCowboy','2013-12-19 07:12:26','218.213.93.70',1,'配置用户角色成功，用户Id：432712652','配置用户角色',0,NULL,NULL,0,'server0',NULL),(21,1072508,'SpaceCowboy','SpaceCowboy','2013-12-19 07:12:43','218.213.93.70',1,'配置用户角色成功，用户Id：432712652','配置用户角色',0,NULL,NULL,0,'server0',NULL),(22,1072508,'SpaceCowboy','SpaceCowboy','2013-12-19 07:16:17','218.213.93.70',1,'配置系统角色权限成功，角色Id：2','配置角色权限',0,NULL,NULL,0,'server0',NULL),(23,1072508,'SpaceCowboy','SpaceCowboy','2013-12-19 07:16:17','218.213.93.70',1,'配置系统角色权限成功，角色Id：2','配置角色权限',0,NULL,NULL,0,'server0',NULL),(24,1072508,'SpaceCowboy','SpaceCowboy','2013-12-19 07:16:35','218.213.93.70',1,'配置用户角色成功，用户Id：432712652','配置用户角色',0,NULL,NULL,0,'server0',NULL),(25,432712652,'braziltest1','111','2013-12-19 07:20:11','218.213.93.70',1,'用户登录成功','用户登录',1204,NULL,NULL,0,'server0',NULL),(26,1072508,'SpaceCowboy','SpaceCowboy','2013-12-19 07:23:55','218.213.93.70',1,'用户登录成功','用户登录',1204,NULL,NULL,0,'server0',NULL),(27,1072508,'SpaceCowboy','SpaceCowboy','2013-12-19 07:25:06','218.213.93.70',1,'配置用户角色成功，用户Id：432712651','配置用户角色',0,NULL,NULL,0,'server0',NULL),(28,1072508,'SpaceCowboy','SpaceCowboy','2013-12-19 07:34:16','218.213.93.70',1,'添加用户成功，用户:braziltest2','添加用户',0,NULL,NULL,0,'server0',NULL),(29,1072508,'SpaceCowboy','SpaceCowboy','2013-12-19 07:34:46','218.213.93.70',1,'添加用户成功，用户:braziltest3','添加用户',0,NULL,NULL,0,'server0',NULL),(30,1072508,'SpaceCowboy','SpaceCowboy','2013-12-19 07:35:09','218.213.93.70',1,'添加用户成功，用户:braziltest4','添加用户',0,NULL,NULL,0,'server0',NULL),(31,1072508,'SpaceCowboy','SpaceCowboy','2013-12-19 07:35:20','218.213.93.70',1,'配置用户角色成功，用户Id：432712651','配置用户角色',0,NULL,NULL,0,'server0',NULL),(32,1072508,'SpaceCowboy','SpaceCowboy','2013-12-19 07:35:29','218.213.93.70',1,'配置用户角色成功，用户Id：432712655','配置用户角色',0,NULL,NULL,0,'server0',NULL),(33,1072508,'SpaceCowboy','SpaceCowboy','2013-12-19 07:35:43','218.213.93.70',1,'配置用户角色成功，用户Id：432712654','配置用户角色',0,NULL,NULL,0,'server0',NULL),(34,1072508,'SpaceCowboy','SpaceCowboy','2013-12-19 07:35:50','218.213.93.70',1,'配置用户角色成功，用户Id：432712653','配置用户角色',0,NULL,NULL,0,'server0',NULL),(35,1072508,'SpaceCowboy','SpaceCowboy','2013-12-19 07:35:55','218.213.93.70',1,'配置用户角色成功，用户Id：432712652','配置用户角色',0,NULL,NULL,0,'server0',NULL),(36,1072508,'SpaceCowboy','SpaceCowboy','2013-12-19 07:36:03','218.213.93.70',1,'配置用户角色成功，用户Id：432712651','配置用户角色',0,NULL,NULL,0,'server0',NULL),(37,1072508,'SpaceCowboy','SpaceCowboy','2013-12-19 07:36:15','218.213.93.70',1,'配置用户角色成功，用户Id：432712655','配置用户角色',0,NULL,NULL,0,'server0',NULL),(38,1072508,'SpaceCowboy','SpaceCowboy','2013-12-19 07:36:19','218.213.93.70',1,'配置用户角色成功，用户Id：432712654','配置用户角色',0,NULL,NULL,0,'server0',NULL),(39,1072508,'SpaceCowboy','SpaceCowboy','2013-12-19 07:36:23','218.213.93.70',1,'配置用户角色成功，用户Id：432712653','配置用户角色',0,NULL,NULL,0,'server0',NULL),(40,1072508,'SpaceCowboy','SpaceCowboy','2013-12-19 07:36:27','218.213.93.70',1,'配置用户角色成功，用户Id：432712652','配置用户角色',0,NULL,NULL,0,'server0',NULL),(41,1072508,'SpaceCowboy','SpaceCowboy','2013-12-19 07:36:32','218.213.93.70',1,'配置用户角色成功，用户Id：432712651','配置用户角色',0,NULL,NULL,0,'server0',NULL),(42,432712651,'globalgames1','111','2013-12-19 12:28:35','177.134.2.242',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(43,432712651,'globalgames1','111','2013-12-19 20:20:03','177.134.2.242',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(44,432712651,'globalgames1','111','2013-12-20 19:56:19','177.41.202.46',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(45,432712651,'globalgames1','111','2013-12-23 20:00:29','177.134.0.183',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(46,432712651,'globalgames1','111','2013-12-23 20:03:05','177.134.0.183',1,'Add User Successful, User :polaris','Add User ',0,NULL,NULL,0,'server0',NULL),(47,432712651,'globalgames1','111','2013-12-26 21:30:52','177.134.0.15',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(48,432712651,'globalgames1','111','2013-12-30 13:31:35','177.41.207.6',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(49,432712651,'globalgames1','111','2013-12-30 13:32:23','177.41.207.6',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(50,432712651,'globalgames1','111','2014-01-08 17:51:11','177.134.26.110',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(51,432712653,'braziltest2','braziltest2','2014-01-08 17:59:03','177.47.22.70',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(52,432712651,'globalgames1','111','2014-02-17 21:40:39','177.41.207.43',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(53,432712651,'globalgames1','111','2014-02-18 12:07:06','177.41.206.55',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(54,1072508,'SpaceCowboy','SpaceCowboy','2014-03-06 04:24:26','113.208.129.51',1,'用户登录成功','用户登录',1204,NULL,NULL,0,'server0',NULL),(55,432712651,'globalgames1','111','2014-03-06 12:12:21','177.134.1.97',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(56,432712655,'braziltest4','braziltest4','2014-03-06 12:54:18','177.134.1.97',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(57,432712655,'braziltest4','braziltest4','2014-03-06 12:56:47','177.134.1.97',1,'Switch account login successful','Switch User Login',1204,NULL,NULL,0,'server0',NULL),(58,432712655,'braziltest4','braziltest4','2014-03-06 12:57:57','177.134.1.97',1,'Switch account login successful','Switch User Login',1204,NULL,NULL,0,'server0',NULL),(59,432712655,'braziltest4','braziltest4','2014-03-06 13:04:45','177.134.1.97',1,'Add System Character Successful, Character Name: caca','Add System Character ',0,NULL,NULL,0,'server0',NULL),(60,432712655,'braziltest4','braziltest4','2014-03-06 13:05:56','177.134.1.97',1,'Configure System Character Access Rights Successful, Character Id: 3','Configure Character Access Rights',0,NULL,NULL,0,'server0',NULL),(61,432712655,'braziltest4','braziltest4','2014-03-06 13:06:06','177.134.1.97',1,'Configure System Character Access Rights Successful, Character Id: 3','Configure Character Access Rights',0,NULL,NULL,0,'server0',NULL),(62,432712655,'braziltest4','braziltest4','2014-03-06 13:06:51','177.134.1.97',1,'Edit System Character Successful, Character Id: 3','Edit System Character ',0,NULL,NULL,0,'server0',NULL),(63,432712655,'braziltest4','braziltest4','2014-03-06 13:07:09','177.134.1.97',1,'Configure System Character Access Rights Successful, Character Id: 3','Configure Character Access Rights',0,NULL,NULL,0,'server0',NULL),(64,432712655,'braziltest4','braziltest4','2014-03-06 13:07:15','177.134.1.97',1,'Edit System Character Successful, Character Id: 3','Edit System Character ',0,NULL,NULL,0,'server0',NULL),(65,432712652,'braziltest1','111','2014-03-06 15:37:22','177.47.22.70',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(66,432712655,'braziltest4','braziltest4','2014-03-06 20:51:41','177.134.1.97',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(67,432712655,'braziltest4','braziltest4','2014-03-06 20:54:00','177.134.1.97',1,'Configure System Character Access Rights Successful, Character Id: 3','Configure Character Access Rights',0,NULL,NULL,0,'server0',NULL),(68,432712655,'braziltest4','braziltest4','2014-03-06 20:54:43','177.134.1.97',1,'Edit System Character Successful, Character Id: 3','Edit System Character ',0,NULL,NULL,0,'server0',NULL),(69,432712652,'braziltest1','111','2014-03-21 19:15:11','177.47.22.70',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(70,432712652,'braziltest1','111','2014-04-03 14:20:01','177.47.22.70',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(71,1072508,'SpaceCowboy','SpaceCowboy','2014-04-14 04:03:09','113.208.129.60',1,'用户登录成功','用户登录',1204,NULL,NULL,0,'server0',NULL),(72,-1,'未知','未知','2014-04-14 04:03:11','119.147.146.189',2,'试图匿名访问资源或登录超时：/showframe.do?method=showtop','访问控制',0,NULL,NULL,0,'server0',NULL),(73,1072508,'SpaceCowboy','SpaceCowboy','2014-04-14 04:03:28','113.208.129.60',1,'添加用户成功，用户:jjuslulu','添加用户',0,NULL,NULL,0,'server0',NULL),(74,1072508,'SpaceCowboy','SpaceCowboy','2014-04-14 04:04:33','113.208.129.60',1,'添加用户成功，用户:GLOBALgames01','添加用户',0,NULL,NULL,0,'server0',NULL),(75,1072508,'SpaceCowboy','SpaceCowboy','2014-04-14 04:04:43','113.208.129.60',1,'添加用户成功，用户:GLOBALgames02','添加用户',0,NULL,NULL,0,'server0',NULL),(76,1072508,'SpaceCowboy','SpaceCowboy','2014-04-14 04:04:54','113.208.129.60',1,'添加用户成功，用户:GLOBALgames03','添加用户',0,NULL,NULL,0,'server0',NULL),(77,1072508,'SpaceCowboy','SpaceCowboy','2014-04-14 04:05:04','113.208.129.60',1,'添加用户成功，用户:GLOBALgames04','添加用户',0,NULL,NULL,0,'server0',NULL),(78,1072508,'SpaceCowboy','SpaceCowboy','2014-04-14 04:05:14','113.208.129.60',1,'添加用户成功，用户:GLOBALgames05','添加用户',0,NULL,NULL,0,'server0',NULL),(79,1072508,'SpaceCowboy','SpaceCowboy','2014-04-14 04:05:24','113.208.129.60',1,'添加用户成功，用户:GLOBALgames06','添加用户',0,NULL,NULL,0,'server0',NULL),(80,1072508,'SpaceCowboy','SpaceCowboy','2014-04-14 04:05:35','113.208.129.60',1,'添加系统角色成功，角色名：GLOBALgames','添加系统角色',0,NULL,NULL,0,'server0',NULL),(81,1072508,'SpaceCowboy','SpaceCowboy','2014-04-14 04:05:55','113.208.129.60',1,'配置系统角色权限成功，角色Id：4','配置角色权限',0,NULL,NULL,0,'server0',NULL),(82,1072508,'SpaceCowboy','SpaceCowboy','2014-04-14 04:06:21','113.208.129.60',1,'配置用户角色成功，用户Id：432712663','配置用户角色',0,NULL,NULL,0,'server0',NULL),(83,1072508,'SpaceCowboy','SpaceCowboy','2014-04-14 04:06:26','113.208.129.60',1,'配置用户角色成功，用户Id：432712662','配置用户角色',0,NULL,NULL,0,'server0',NULL),(84,1072508,'SpaceCowboy','SpaceCowboy','2014-04-14 04:06:30','113.208.129.60',1,'配置用户角色成功，用户Id：432712661','配置用户角色',0,NULL,NULL,0,'server0',NULL),(85,1072508,'SpaceCowboy','SpaceCowboy','2014-04-14 04:06:35','113.208.129.60',1,'配置用户角色成功，用户Id：432712661','配置用户角色',0,NULL,NULL,0,'server0',NULL),(86,1072508,'SpaceCowboy','SpaceCowboy','2014-04-14 04:06:40','113.208.129.60',1,'配置用户角色成功，用户Id：432712660','配置用户角色',0,NULL,NULL,0,'server0',NULL),(87,1072508,'SpaceCowboy','SpaceCowboy','2014-04-14 04:06:46','113.208.129.60',1,'配置用户角色成功，用户Id：432712659','配置用户角色',0,NULL,NULL,0,'server0',NULL),(88,1072508,'SpaceCowboy','SpaceCowboy','2014-04-14 04:06:51','113.208.129.60',1,'配置用户角色成功，用户Id：432712658','配置用户角色',0,NULL,NULL,0,'server0',NULL),(89,1072508,'SpaceCowboy','SpaceCowboy','2014-04-14 04:06:57','113.208.129.60',1,'配置用户角色成功，用户Id：432712657','配置用户角色',0,NULL,NULL,0,'server0',NULL),(90,1072508,'SpaceCowboy','SpaceCowboy','2014-04-14 04:08:07','113.208.129.60',1,'添加网关成功!','添加网关',1204,NULL,NULL,104001,'test server',NULL),(91,1072508,'SpaceCowboy','SpaceCowboy','2014-04-14 04:22:57','113.208.129.60',1,'用户登录成功','用户登录',1204,NULL,NULL,0,'server0',NULL),(92,1072508,'SpaceCowboy','SpaceCowboy','2014-04-14 05:37:05','113.208.129.60',1,'修改网关成功!','修改网关',1204,NULL,NULL,104001,'test server',NULL),(93,1072508,'SpaceCowboy','SpaceCowboy','2014-04-14 05:37:13','113.208.129.60',1,'删除服务器成功!','删除游戏服务器',1204,NULL,NULL,104001,'test server',NULL),(94,1072508,'SpaceCowboy','SpaceCowboy','2014-04-14 05:37:33','113.208.129.60',1,'添加服务器成功!','添加游戏服务器',1204,NULL,NULL,104001,'test server',NULL),(95,1072508,'SpaceCowboy','SpaceCowboy','2014-04-14 05:37:43','113.208.129.60',2,'Unauthorised Resource Access Attempt: /showIssueBulletinCompensate.do','Access Control',0,NULL,NULL,0,'server0',NULL),(96,1072508,'SpaceCowboy','SpaceCowboy','2014-04-14 05:37:54','113.208.129.60',1,'用户登录成功','用户登录',1204,NULL,NULL,0,'server0',NULL),(97,1072508,'SpaceCowboy','SpaceCowboy','2014-04-14 05:38:18','113.208.129.60',2,'Unauthorised Resource Access Attempt: /showIssueBulletinCompensate.do','Access Control',0,NULL,NULL,0,'server0',NULL),(98,1072508,'SpaceCowboy','SpaceCowboy','2014-04-14 05:38:45','113.208.129.60',1,'发送公告成功!公告内容:test','发送公告',1204,NULL,NULL,0,'server0',NULL),(99,1072508,'SpaceCowboy','SpaceCowboy','2014-04-14 05:47:02','113.208.129.60',1,'修改服务器成功!','修改游戏服务器',1204,NULL,NULL,104001,'test server',NULL),(100,1072508,'SpaceCowboy','SpaceCowboy','2014-04-14 05:47:23','113.208.129.60',1,'发送公告成功!公告内容:test','发送公告',1204,NULL,NULL,0,'server0',NULL),(101,1072508,'SpaceCowboy','SpaceCowboy','2014-04-14 05:48:06','113.208.129.60',1,'修改服务器成功!','修改游戏服务器',1204,NULL,NULL,104001,'test server',NULL),(102,1072508,'SpaceCowboy','SpaceCowboy','2014-04-14 05:48:26','113.208.129.60',1,'发送公告成功!公告内容:test','发送公告',1204,NULL,NULL,0,'server0',NULL),(103,1072508,'SpaceCowboy','SpaceCowboy','2014-04-14 05:48:42','113.208.129.60',1,'修改服务器成功!','修改游戏服务器',1204,NULL,NULL,104001,'test server',NULL),(104,1072508,'SpaceCowboy','SpaceCowboy','2014-04-14 05:49:20','113.208.129.60',1,'发送公告成功!公告内容:test','发送公告',1204,NULL,NULL,0,'server0',NULL),(105,1072508,'SpaceCowboy','SpaceCowboy','2014-04-14 05:57:09','113.208.129.60',1,'配置系统角色权限成功，角色Id：4','配置角色权限',0,NULL,NULL,0,'server0',NULL),(106,432712658,'GLOBALgames01','GLOBALgames01','2014-04-14 06:05:01','113.208.129.60',1,'用户登录成功','用户登录',1204,NULL,NULL,0,'server0',NULL),(107,1072508,'SpaceCowboy','SpaceCowboy','2014-04-14 06:11:13','113.208.129.60',1,'用户登录成功','用户登录',1204,NULL,NULL,0,'server0',NULL),(108,432712658,'GLOBALgames01','GLOBALgames01','2014-04-25 02:58:02','189.34.157.177',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(109,1072508,'SpaceCowboy','SpaceCowboy','2014-04-25 02:59:29','113.208.129.60',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(110,432712650,'egmweb2','egmweb2','2014-04-28 09:01:14','113.208.129.50',1,'用户登录成功','用户登录',1204,NULL,NULL,0,'server0',NULL),(111,432712650,'egmweb2','egmweb2','2014-04-28 09:01:40','113.208.129.50',1,'资源关联游戏成功!','资源关联游戏',0,NULL,NULL,0,'server0',NULL),(112,1072508,'SpaceCowboy','SpaceCowboy','2014-04-28 10:20:38','113.208.129.50',1,'用户登录成功','用户登录',1204,NULL,NULL,0,'server0',NULL),(113,1072508,'SpaceCowboy','SpaceCowboy','2014-04-28 10:20:54','113.208.129.50',1,'用户登录成功','用户登录',1204,NULL,NULL,0,'server0',NULL),(114,1072508,'SpaceCowboy','SpaceCowboy','2014-04-28 12:11:39','113.208.129.50',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(115,-1,'未知','未知','2014-04-28 12:41:49','101.226.33.221',2,'试图匿名访问资源或登录超时：/showFrame.do?method=showTop','访问控制',0,NULL,NULL,0,'server0',NULL),(116,-1,'未知','未知','2014-04-28 12:41:49','112.64.235.251',2,'试图匿名访问资源或登录超时：/showFrame.do?method=showBottom','访问控制',0,NULL,NULL,0,'server0',NULL),(117,-1,'未知','未知','2014-04-28 12:42:02','101.226.65.102',2,'试图匿名访问资源或登录超时：/showFrame.do?method=showLeft','访问控制',0,NULL,NULL,0,'server0',NULL),(118,432712659,'GLOBALgames02','GLOBALgames02','2014-05-03 04:12:01','189.34.243.238',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(119,432712659,'GLOBALgames02','GLOBALgames02','2014-05-03 18:15:24','189.34.243.238',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(120,432712652,'braziltest1','111','2014-05-08 14:47:35','177.47.22.70',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(121,432712658,'GLOBALgames01','GLOBALgames01','2014-05-08 17:48:28','177.47.22.70',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(122,432712658,'GLOBALgames01','GLOBALgames01','2014-05-08 17:51:01','177.47.22.70',1,'Delete System Character Successful, Character Id: 3','Delete System Character ',0,NULL,NULL,0,'server0',NULL),(123,432712658,'GLOBALgames01','GLOBALgames01','2014-05-08 17:51:09','177.47.22.70',1,'Edit System Character Successful, Character Id: 4','Edit System Character ',0,NULL,NULL,0,'server0',NULL),(124,432712658,'GLOBALgames01','GLOBALgames01','2014-05-08 17:52:02','177.47.22.70',1,'Add System Character Successful, Character Name: 001[GM]','Add System Character ',0,NULL,NULL,0,'server0',NULL),(125,432712658,'GLOBALgames01','GLOBALgames01','2014-05-21 16:47:11','179.215.89.170',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(126,1072508,'SpaceCowboy','SpaceCowboy','2014-07-20 02:41:51','113.208.129.60',1,'用户登录成功','用户登录',1204,NULL,NULL,0,'server0',NULL),(127,432712657,'jjuslulu','lucinda','2014-07-20 02:53:07','177.47.22.70',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(128,1072508,'SpaceCowboy','SpaceCowboy','2014-07-20 02:55:05','113.208.129.60',1,'配置系统角色权限成功，角色Id：4','配置角色权限',0,NULL,NULL,0,'server0',NULL),(129,1072508,'SpaceCowboy','SpaceCowboy','2014-07-20 02:55:11','113.208.129.60',1,'配置系统角色权限成功，角色Id：2','配置角色权限',0,NULL,NULL,0,'server0',NULL),(130,1072508,'SpaceCowboy','SpaceCowboy','2014-07-20 02:55:16','113.208.129.60',1,'配置系统角色权限成功，角色Id：1','配置角色权限',0,NULL,NULL,0,'server0',NULL),(131,432712657,'jjuslulu','lucinda','2014-07-20 02:55:41','177.47.22.70',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(132,432712657,'jjuslulu','lucinda','2014-07-20 02:55:52','177.47.22.70',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(133,432712657,'jjuslulu','lucinda','2014-07-20 02:56:15','177.47.22.70',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(134,1072508,'SpaceCowboy','SpaceCowboy','2014-07-20 02:57:42','113.208.129.60',1,'配置用户角色成功，用户Id：432712657','配置用户角色',0,NULL,NULL,0,'server0',NULL),(135,432712657,'jjuslulu','lucinda','2014-07-20 02:57:58','177.47.22.70',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(136,432712657,'jjuslulu','lucinda','2014-07-20 02:58:10','177.47.22.70',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(137,1072508,'SpaceCowboy','SpaceCowboy','2014-07-20 02:58:10','113.208.129.60',1,'配置用户角色成功，用户Id：432712657','配置用户角色',0,NULL,NULL,0,'server0',NULL),(138,432712657,'jjuslulu','lucinda','2014-07-20 02:58:28','177.47.22.70',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(139,1072508,'SpaceCowboy','SpaceCowboy','2014-07-20 02:59:33','113.208.129.60',1,'用户登录成功','用户登录',1204,NULL,NULL,0,'server0',NULL),(140,1072508,'SpaceCowboy','SpaceCowboy','2014-07-20 03:00:34','177.47.22.70',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(141,1072508,'SpaceCowboy','SpaceCowboy','2014-07-20 13:56:36','177.47.22.70',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(142,-1,'未知','未知','2014-07-22 01:51:49','113.208.129.60',2,'试图匿名访问资源或登录超时：/showFrame.do?method=showTop','访问控制',0,NULL,NULL,0,'server0',NULL),(143,-1,'未知','未知','2014-07-22 01:51:49','113.208.129.60',2,'试图匿名访问资源或登录超时：/showFrame.do?method=showMiddle','访问控制',0,NULL,NULL,0,'server0',NULL),(144,-1,'未知','未知','2014-07-22 01:51:50','113.208.129.60',2,'试图匿名访问资源或登录超时：/showFrame.do?method=showBottom','访问控制',0,NULL,NULL,0,'server0',NULL),(145,-1,'Unknown','Unknown','2014-07-22 20:21:17','177.47.22.70',2,'Anonymous Resource Access Attempt or Login Expired: /showSetPackage.do?activityId=1514071801&activityType=3&version=new','Access Control',0,NULL,NULL,0,'server0',NULL),(146,1072508,'SpaceCowboy','SpaceCowboy','2014-07-22 20:21:25','177.47.22.70',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(147,1072508,'SpaceCowboy','SpaceCowboy','2014-07-22 20:23:53','177.47.22.70',1,'Generate Activation Code Successful!','Generate Activation Code',1204,NULL,NULL,0,'server0',NULL),(148,1072508,'SpaceCowboy','SpaceCowboy','2014-07-23 01:55:07','113.208.129.60',1,'用户登录成功','用户登录',1204,NULL,NULL,0,'server0',NULL),(149,1072508,'SpaceCowboy','SpaceCowboy','2014-07-23 01:56:26','113.208.129.60',1,'生成激活码成功!','生成激活码',1204,NULL,NULL,0,'server0',NULL),(150,432712657,'jjuslulu','lucinda','2014-07-25 01:56:40','189.34.211.101',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(151,1072508,'SpaceCowboy','SpaceCowboy','2014-07-25 01:56:56','189.34.211.101',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(152,-1,'Unknown','Unknown','2014-07-26 15:28:16','189.34.132.34',2,'Anonymous Resource Access Attempt or Login Expired: /showActivityModel.do?version=new','Access Control',0,NULL,NULL,0,'server0',NULL),(153,1072508,'SpaceCowboy','SpaceCowboy','2014-07-26 15:28:27','189.34.132.34',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(154,1072508,'SpaceCowboy','SpaceCowboy','2014-07-26 15:29:02','189.34.132.34',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(155,1072508,'SpaceCowboy','SpaceCowboy','2014-09-07 08:19:42','177.47.22.70',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(156,1072508,'SpaceCowboy','SpaceCowboy','2014-09-13 11:59:49','189.34.132.34',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(157,1072508,'SpaceCowboy','SpaceCowboy','2014-09-14 15:13:50','177.47.22.70',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(158,1072508,'SpaceCowboy','SpaceCowboy','2014-09-14 15:47:08','177.47.22.70',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(159,432712662,'GLOBALgames05','GLOBALgames05','2014-09-18 13:33:46','177.47.22.70',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(160,432712662,'GLOBALgames05','GLOBALgames05','2014-09-18 13:35:23','177.47.22.70',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(161,432712662,'GLOBALgames05','GLOBALgames05','2014-09-18 13:36:00','177.47.22.70',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(162,1072508,'SpaceCowboy','SpaceCowboy','2014-09-26 14:16:04','177.47.22.70',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(163,1072508,'SpaceCowboy','SpaceCowboy','2014-10-07 12:51:35','177.47.22.70',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(164,1072508,'SpaceCowboy','SpaceCowboy','2015-01-12 19:28:36','177.47.22.70',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(165,1072508,'SpaceCowboy','SpaceCowboy','2015-01-13 11:29:00','189.34.142.36',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(166,1072508,'SpaceCowboy','SpaceCowboy','2015-01-13 13:54:30','177.47.22.70',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(167,1072508,'SpaceCowboy','SpaceCowboy','2015-01-19 13:33:13','177.47.22.70',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(168,1072508,'SpaceCowboy','SpaceCowboy','2015-01-20 12:18:07','177.47.22.70',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(169,1072508,'SpaceCowboy','SpaceCowboy','2015-01-20 12:21:28','189.34.133.137',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(170,1072508,'SpaceCowboy','SpaceCowboy','2015-01-20 12:30:55','177.47.22.70',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(171,1072508,'SpaceCowboy','SpaceCowboy','2015-04-16 19:10:26','177.47.22.70',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(172,1072508,'SpaceCowboy','SpaceCowboy','2016-05-30 16:14:03','179.215.124.50',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(173,432712652,'braziltest1','111','2017-06-23 21:51:38','179.215.124.118',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(174,432712652,'braziltest1','111','2017-06-23 21:51:54','179.215.124.118',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(175,432712652,'braziltest1','111','2017-06-23 21:52:43','179.215.124.118',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(176,432712652,'braziltest1','111','2017-06-23 21:53:59','179.215.124.118',1,'Add System Character Successful, Character Name: thiago','Add System Character ',0,NULL,NULL,0,'server0',NULL),(177,432712652,'braziltest1','111','2017-06-23 21:56:41','179.215.124.118',1,'Edit Server Successful!','Edit Game Server ',1204,NULL,NULL,104001,'test server',NULL),(178,432712651,'globalgames1','111','2017-06-24 03:57:38','189.69.68.183',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(179,432712651,'globalgames1','111','2017-06-24 03:58:07','189.69.68.183',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(180,432712651,'globalgames1','111','2017-06-24 03:58:57','189.69.68.183',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(181,432712651,'globalgames1','111','2017-06-24 22:23:46','189.69.68.183',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(182,432712652,'braziltest1','111','2017-06-25 02:32:57','189.69.68.183',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(183,432712652,'braziltest1','111','2017-06-25 06:20:51','189.69.68.183',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(184,432712652,'braziltest1','111','2017-06-27 00:21:04','179.215.124.118',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(185,432712652,'braziltest1','111','2017-06-27 00:25:13','179.215.124.118',2,'Unauthorised Resource Access Attempt: /showAddRelationGames.do','Access Control',0,NULL,NULL,0,'server0',NULL),(186,432712652,'braziltest1','111','2017-06-27 00:25:50','179.215.124.118',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(187,432712652,'braziltest1','111','2017-06-27 00:26:01','179.215.124.118',2,'Unauthorised Resource Access Attempt: /showAddRelationGames.do','Access Control',0,NULL,NULL,0,'server0',NULL),(188,432712652,'braziltest1','111','2017-06-27 07:44:55','189.69.68.183',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(189,432712652,'braziltest1','111','2017-06-27 07:45:19','189.69.68.183',1,'Switch account login successful','Switch User Login',1204,NULL,NULL,0,'server0',NULL),(190,432712652,'braziltest1','111','2017-06-27 07:47:45','189.69.68.183',1,'Switch account login successful','Switch User Login',1204,NULL,NULL,0,'server0',NULL),(191,432712652,'braziltest1','111','2017-06-27 22:08:28','189.69.68.183',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(192,432712652,'braziltest1','111','2017-06-27 22:10:12','189.69.68.183',1,'Switch account login successful','Switch User Login',1204,NULL,NULL,0,'server0',NULL),(193,432712652,'braziltest1','111','2017-06-27 22:10:22','189.69.68.183',1,'Switch account login successful','Switch User Login',1204,NULL,NULL,0,'server0',NULL),(194,1072508,'SpaceCowboy','SpaceCowboy','2017-06-27 22:18:09','189.69.68.183',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(195,1072508,'SpaceCowboy','SpaceCowboy','2017-06-27 22:18:28','189.69.68.183',1,'Edit Gateway Successful!','Edit Gateway ',1204,NULL,NULL,104001,'test server',NULL),(196,1072508,'SpaceCowboy','SpaceCowboy','2017-06-27 22:18:33','189.69.68.183',2,'Unauthorised Resource Access Attempt: /showAddRelationGames.do','Access Control',0,NULL,NULL,0,'server0',NULL),(197,1072508,'SpaceCowboy','SpaceCowboy','2017-06-28 18:41:36','179.215.124.118',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL),(198,1072508,'SpaceCowboy','SpaceCowboy','2017-06-28 18:46:57','179.215.124.118',1,'Edit Gateway Successful!','Edit Gateway ',1204,NULL,NULL,104001,'test server',NULL),(199,1072508,'SpaceCowboy','SpaceCowboy','2017-06-29 23:43:53','179.215.124.118',1,'Account login successful','User Login',1204,NULL,NULL,0,'server0',NULL);
/*!40000 ALTER TABLE `log_user_operations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_user_operations_091022`
--

DROP TABLE IF EXISTS `log_user_operations_091022`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_user_operations_091022` (
  `LOG_ID` int(15) NOT NULL,
  `PASSPORT_ID` int(10) NOT NULL,
  `PASSPORT_NAME` varchar(32) NOT NULL,
  `OPER_REAL_NAME` varchar(64) DEFAULT NULL,
  `OPER_DATE` datetime NOT NULL,
  `OPER_IP` varchar(32) DEFAULT NULL,
  `RESULT_CODE` int(3) NOT NULL,
  `OPER_DESC` varchar(2048) NOT NULL,
  `OPER_TYPE` varchar(64) NOT NULL,
  `GAME_ID` int(8) DEFAULT NULL,
  `PLAYER_NAME` varchar(50) DEFAULT NULL,
  `ROLE_NAME` varchar(50) DEFAULT NULL,
  `GATEWAY_ID` int(8) DEFAULT NULL,
  `GATEWAY_NAME` varchar(100) DEFAULT NULL,
  `REASON` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_user_operations_091022`
--

LOCK TABLES `log_user_operations_091022` WRITE;
/*!40000 ALTER TABLE `log_user_operations_091022` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_user_operations_091022` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_channel`
--

DROP TABLE IF EXISTS `sys_channel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_channel` (
  `GAME_ID` int(3) NOT NULL COMMENT '游戏编号',
  `CHANNEL_CODE` varchar(32) NOT NULL COMMENT '频道编号',
  `CHANNEL_NAME` varchar(64) NOT NULL COMMENT '频道名称',
  PRIMARY KEY (`GAME_ID`,`CHANNEL_CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='游戏频道信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_channel`
--

LOCK TABLES `sys_channel` WRITE;
/*!40000 ALTER TABLE `sys_channel` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_channel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_dictionary`
--

DROP TABLE IF EXISTS `sys_dictionary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_dictionary` (
  `DICTIONARY_ID` int(10) NOT NULL,
  `DICT_TYPE` varchar(32) DEFAULT NULL COMMENT '字典类型，物品-item，游戏频道-channel，游戏场景-scene，职业-occupation，联盟-league',
  `GAME_ID` int(3) DEFAULT NULL COMMENT '游戏编号',
  `DICT_CODE` varchar(32) DEFAULT NULL COMMENT '代码',
  `DICT_NAME` varchar(64) DEFAULT NULL COMMENT '名称',
  PRIMARY KEY (`DICTIONARY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='字典表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_dictionary`
--

LOCK TABLES `sys_dictionary` WRITE;
/*!40000 ALTER TABLE `sys_dictionary` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_dictionary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_exp_type`
--

DROP TABLE IF EXISTS `sys_exp_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_exp_type` (
  `GAME_ID` int(3) NOT NULL COMMENT '游戏编号',
  `EXP_TYPE_CODE` varchar(32) NOT NULL COMMENT '类型代码',
  `EXP_TYPE_NAME` varchar(64) NOT NULL COMMENT '类型名称',
  PRIMARY KEY (`GAME_ID`,`EXP_TYPE_CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='加倍经验类型';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_exp_type`
--

LOCK TABLES `sys_exp_type` WRITE;
/*!40000 ALTER TABLE `sys_exp_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_exp_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_game`
--

DROP TABLE IF EXISTS `sys_game`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_game` (
  `GAME_ID` int(3) NOT NULL COMMENT '游戏代码',
  `GAME_NAME` varchar(64) NOT NULL COMMENT '游戏名称',
  `OWNER_TYPE` int(1) DEFAULT '0' COMMENT '所属版本类型 1、自主版  2、联运版',
  PRIMARY KEY (`GAME_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_game`
--

LOCK TABLES `sys_game` WRITE;
/*!40000 ALTER TABLE `sys_game` DISABLE KEYS */;
INSERT INTO `sys_game` VALUES (1204,'巴西黎明_TEST',1);
/*!40000 ALTER TABLE `sys_game` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_game_resources`
--

DROP TABLE IF EXISTS `sys_game_resources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_game_resources` (
  `GAME_RES_ID` int(10) NOT NULL COMMENT '如果表中无记录，id=1，否则id=max(id) + 1',
  `GAME_ID` int(3) NOT NULL COMMENT '游戏编号，-1资源对应于所有游戏(只能给开发人员使用)',
  `RES_ID` int(6) NOT NULL COMMENT '资源编号',
  PRIMARY KEY (`GAME_RES_ID`),
  KEY `FK_RES_GAME_RES` (`RES_ID`),
  CONSTRAINT `FK_RES_GAME_RES` FOREIGN KEY (`RES_ID`) REFERENCES `sys_resources` (`RES_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='游戏与资源关系表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_game_resources`
--

LOCK TABLES `sys_game_resources` WRITE;
/*!40000 ALTER TABLE `sys_game_resources` DISABLE KEYS */;
INSERT INTO `sys_game_resources` VALUES (19,-10,13),(20,-11,14),(21,-11,16),(24,-11,18),(40,-11,32),(272,-11,226),(436,-11,274),(3241,-11,13),(3242,-11,14),(3243,-11,16),(3244,-11,274),(3245,-11,18),(3246,-11,32),(3247,-11,226),(3262,-11,13),(3263,-11,14),(3264,-11,16),(3265,-11,274),(3266,-11,18),(3267,-11,32),(3268,-11,226),(3921,-11,13),(3922,-11,14),(3923,-11,16),(3924,-11,274),(3925,-11,18),(3926,-11,32),(3927,-11,226),(4105,-11,13),(4106,-11,14),(4107,-11,16),(4108,-11,274),(4109,-11,18),(4110,-11,32),(4111,-11,226),(4150,-11,13),(4151,-11,14),(4152,-11,16),(4153,-11,274),(4154,-11,18),(4155,-11,32),(4156,-11,226),(4185,-11,13),(4186,-11,14),(4187,-11,16),(4188,-11,274),(4189,-11,18),(4190,-11,32),(4191,-11,226),(4388,-11,13),(4389,-11,14),(4390,-11,16),(4391,-11,274),(4392,-11,18),(4393,-11,32),(4394,-11,226),(4593,-11,13),(4594,-11,14),(4595,-11,16),(4596,-11,274),(4597,-11,18),(4598,-11,32),(4599,-11,226),(4686,-11,13),(4687,-11,14),(4688,-11,16),(4689,-11,274),(4690,-11,18),(4691,-11,32),(4692,-11,226),(4895,-11,13),(4896,-11,14),(4897,-11,16),(4898,-11,274),(4899,-11,18),(4900,-11,32),(4901,-11,226),(5112,-11,13),(5113,-11,14),(5114,-11,16),(5115,-11,274),(5116,-11,18),(5117,-11,32),(5118,-11,226),(5324,-11,13),(5325,-11,14),(5326,-11,16),(5327,-11,274),(5328,-11,18),(5329,-11,32),(5330,-11,226),(5573,-11,13),(5574,-11,14),(5575,-11,16),(5576,-11,274),(5577,-11,18),(5578,-11,32),(5579,-11,226),(5641,-11,13),(5642,-11,14),(5643,-11,16),(5644,-11,274),(5645,-11,18),(5646,-11,32),(5647,-11,226),(5856,-11,13),(5857,-11,14),(5858,-11,16),(5859,-11,274),(5860,-11,18),(5861,-11,32),(5862,-11,226),(6071,-11,13),(6072,-11,14),(6073,-11,16),(6074,-11,274),(6075,-11,18),(6076,-11,32),(6077,-11,226),(6286,-11,13),(6287,-11,14),(6288,-11,16),(6289,-11,274),(6290,-11,18),(6291,-11,32),(6292,-11,226),(6541,-11,13),(6542,-11,14),(6543,-11,16),(6544,-11,274),(6545,-11,18),(6546,-11,32),(6547,-11,226),(6785,-11,13),(6786,-11,14),(6787,-11,16),(6788,-11,274),(6789,-11,18),(6790,-11,32),(6791,-11,226),(7032,-11,13),(7033,-11,14),(7034,-11,16),(7035,-11,274),(7036,-11,18),(7037,-11,32),(7038,-11,226),(7261,-11,13),(7262,-11,14),(7263,-11,16),(7264,-11,274),(7265,-11,18),(7266,-11,32),(7267,-11,226),(7507,-11,13),(7508,-11,14),(7509,-11,16),(7510,-11,274),(7511,-11,18),(7512,-11,32),(7513,-11,226),(7562,-11,13),(7563,-11,14),(7564,-11,16),(7565,-11,274),(7566,-11,18),(7567,-11,32),(7568,-11,226),(7858,-11,13),(7859,-11,14),(7860,-11,16),(7861,-11,274),(7862,-11,18),(7863,-11,32),(7864,-11,226),(8101,-11,13),(8102,-11,14),(8103,-11,16),(8104,-11,274),(8105,-11,18),(8106,-11,32),(8107,-11,226),(8350,-11,13),(8351,-11,14),(8352,-11,16),(8353,-11,274),(8354,-11,18),(8355,-11,32),(8356,-11,226),(9156,55,13),(9193,1204,22),(9194,1204,23),(9195,1204,40),(9196,1204,43),(9198,1204,47),(9199,1204,49),(9200,1204,51),(9201,1204,55),(9202,1204,57),(9203,1204,308),(9204,1204,60),(9205,1204,253),(9206,1204,258),(9207,1204,639),(9208,1204,640),(9209,1204,103),(9210,1204,104),(9211,1204,159),(9212,1204,280),(9214,1204,188),(9216,1204,214),(9217,1204,220),(9218,1204,1),(9219,1204,4),(9220,1204,2),(9222,1204,7),(9223,1204,8),(9224,1204,10),(9225,1204,34),(9226,1204,35),(9236,1204,22),(9237,1204,23),(9238,1204,40),(9239,1204,43),(9241,1204,47),(9242,1204,49),(9243,1204,51),(9244,1204,55),(9245,1204,57),(9246,1204,308),(9247,1204,60),(9248,1204,253),(9249,1204,258),(9250,1204,639),(9251,1204,640),(9252,1204,103),(9253,1204,104),(9254,1204,159),(9255,1204,160),(9256,1204,280),(9263,1204,188),(9265,1204,214),(9266,1204,220),(9267,1204,1),(9268,1204,4),(9269,1204,2),(9271,1204,7),(9272,1204,8),(9273,1204,10),(9274,1204,34),(9275,1204,35),(9276,1204,22),(9277,1204,23),(9278,1204,38),(9279,1204,40),(9280,1204,43),(9281,1204,47),(9282,1204,49),(9283,1204,51),(9284,1204,55),(9285,1204,57),(9286,1204,308),(9288,1204,982),(9289,1204,1017),(9291,1204,60),(9292,1204,66),(9293,1204,294),(9294,1204,71),(9295,1204,74),(9296,1204,253),(9297,1204,258),(9298,1204,639),(9299,1204,640),(9300,1204,670),(9301,1204,103),(9302,1204,104),(9303,1204,159),(9304,1204,160),(9305,1204,166),(9306,1204,280),(9307,1204,188),(9309,1204,193),(9310,1204,214),(9311,1204,220),(9312,1204,1),(9313,1204,4),(9314,1204,2),(9315,1204,7),(9316,1204,8),(9317,1204,10),(9318,1204,34),(9319,1204,35),(9320,1204,22),(9321,1204,23),(9322,1204,38),(9323,1204,40),(9324,1204,43),(9325,1204,47),(9326,1204,49),(9327,1204,51),(9328,1204,55),(9329,1204,57),(9330,1204,308),(9332,1204,982),(9333,1204,1017),(9335,1204,60),(9336,1204,66),(9337,1204,294),(9338,1204,71),(9339,1204,74),(9340,1204,253),(9341,1204,258),(9342,1204,639),(9343,1204,640),(9344,1204,670),(9345,1204,103),(9346,1204,104),(9347,1204,159),(9348,1204,160),(9349,1204,166),(9350,1204,280),(9351,1204,188),(9353,1204,193),(9354,1204,214),(9355,1204,220),(9356,1204,1),(9357,1204,4),(9358,1204,2),(9359,1204,7),(9360,1204,8),(9361,1204,10),(9362,1204,34),(9363,1204,35),(9364,1204,22),(9365,1204,23),(9366,1204,38),(9367,1204,40),(9368,1204,43),(9369,1204,47),(9370,1204,49),(9371,1204,51),(9372,1204,55),(9373,1204,57),(9374,1204,308),(9375,1204,982),(9376,1204,1017),(9378,1204,60),(9379,1204,66),(9380,1204,294),(9381,1204,71),(9382,1204,74),(9383,1204,253),(9384,1204,258),(9385,1204,639),(9386,1204,640),(9387,1204,670),(9388,1204,103),(9389,1204,104),(9390,1204,159),(9391,1204,160),(9392,1204,166),(9393,1204,280),(9394,1204,188),(9396,1204,193),(9397,1204,214),(9398,1204,220),(9399,1204,1),(9400,1204,4),(9401,1204,2),(9402,1204,795),(9403,1204,7),(9404,1204,8),(9405,1204,10),(9406,1204,34),(9407,1204,35),(9408,1204,22),(9409,1204,23),(9410,1204,38),(9411,1204,40),(9412,1204,43),(9413,1204,47),(9414,1204,49),(9415,1204,51),(9416,1204,55),(9417,1204,57),(9418,1204,308),(9419,1204,982),(9420,1204,1017),(9422,1204,60),(9423,1204,66),(9424,1204,294),(9425,1204,71),(9426,1204,74),(9427,1204,253),(9428,1204,258),(9429,1204,639),(9430,1204,640),(9431,1204,670),(9432,1204,103),(9433,1204,104),(9434,1204,159),(9435,1204,160),(9436,1204,166),(9437,1204,280),(9438,1204,188),(9440,1204,193),(9441,1204,214),(9442,1204,220),(9443,1204,1),(9444,1204,4),(9445,1204,2),(9446,1204,795),(9447,1204,7),(9448,1204,8),(9449,1204,10),(9450,1204,34),(9451,1204,35),(9452,1204,22),(9453,1204,23),(9454,1204,38),(9455,1204,40),(9456,1204,43),(9457,1204,47),(9458,1204,49),(9459,1204,51),(9460,1204,55),(9461,1204,57),(9462,1204,308),(9463,1204,982),(9464,1204,1017),(9466,1204,60),(9467,1204,66),(9468,1204,294),(9469,1204,71),(9470,1204,74),(9471,1204,253),(9472,1204,258),(9473,1204,639),(9474,1204,640),(9475,1204,670),(9476,1204,103),(9477,1204,104),(9478,1204,159),(9479,1204,160),(9480,1204,166),(9481,1204,280),(9482,1204,188),(9484,1204,193),(9485,1204,214),(9486,1204,220),(9487,1204,1),(9488,1204,4),(9489,1204,2),(9490,1204,795),(9491,1204,7),(9492,1204,8),(9493,1204,10),(9494,1204,34),(9495,1204,35),(9496,1204,22),(9497,1204,23),(9498,1204,38),(9499,1204,40),(9500,1204,43),(9501,1204,47),(9502,1204,49),(9503,1204,51),(9504,1204,55),(9505,1204,57),(9506,1204,308),(9507,1204,982),(9508,1204,1017),(9510,1204,60),(9511,1204,66),(9512,1204,294),(9513,1204,71),(9514,1204,74),(9515,1204,253),(9516,1204,258),(9517,1204,639),(9518,1204,640),(9519,1204,670),(9520,1204,103),(9521,1204,104),(9522,1204,159),(9523,1204,160),(9524,1204,166),(9525,1204,280),(9526,1204,188),(9528,1204,193),(9529,1204,214),(9530,1204,220),(9531,1204,1),(9532,1204,4),(9533,1204,2),(9534,1204,795),(9535,1204,7),(9536,1204,8),(9537,1204,10),(9538,1204,34),(9539,1204,35),(9540,1204,22),(9541,1204,23),(9542,1204,38),(9543,1204,40),(9544,1204,43),(9545,1204,47),(9546,1204,49),(9547,1204,51),(9548,1204,55),(9549,1204,57),(9550,1204,308),(9551,1204,982),(9552,1204,1017),(9554,1204,60),(9555,1204,66),(9556,1204,294),(9557,1204,71),(9558,1204,74),(9559,1204,253),(9560,1204,258),(9561,1204,639),(9562,1204,640),(9563,1204,670),(9564,1204,103),(9565,1204,104),(9566,1204,159),(9567,1204,160),(9568,1204,166),(9569,1204,280),(9570,1204,188),(9572,1204,193),(9573,1204,214),(9574,1204,220),(9575,1204,1),(9576,1204,4),(9577,1204,2),(9578,1204,795),(9579,1204,7),(9580,1204,8),(9581,1204,10),(9582,1204,34),(9583,1204,35),(9584,1204,22),(9585,1204,23),(9586,1204,38),(9587,1204,40),(9588,1204,43),(9589,1204,47),(9590,1204,49),(9591,1204,51),(9592,1204,55),(9593,1204,57),(9594,1204,308),(9595,1204,982),(9596,1204,1017),(9598,1204,60),(9599,1204,66),(9600,1204,294),(9601,1204,71),(9602,1204,74),(9603,1204,253),(9604,1204,258),(9605,1204,639),(9606,1204,640),(9607,1204,670),(9608,1204,103),(9609,1204,104),(9610,1204,159),(9611,1204,160),(9612,1204,166),(9613,1204,280),(9614,1204,188),(9616,1204,193),(9617,1204,214),(9618,1204,220),(9619,1204,1),(9620,1204,4),(9621,1204,2),(9622,1204,795),(9623,1204,7),(9624,1204,8),(9625,1204,10),(9626,1204,34),(9627,1204,35),(9628,1204,22),(9629,1204,23),(9630,1204,38),(9631,1204,40),(9632,1204,43),(9633,1204,47),(9634,1204,49),(9635,1204,51),(9636,1204,55),(9637,1204,57),(9638,1204,308),(9639,1204,982),(9640,1204,1017),(9642,1204,60),(9643,1204,66),(9644,1204,294),(9645,1204,71),(9646,1204,74),(9647,1204,253),(9648,1204,258),(9649,1204,639),(9650,1204,640),(9651,1204,670),(9652,1204,103),(9653,1204,104),(9654,1204,159),(9655,1204,160),(9656,1204,166),(9657,1204,280),(9658,1204,188),(9660,1204,193),(9661,1204,214),(9662,1204,220),(9663,1204,1),(9664,1204,4),(9665,1204,2),(9666,1204,795),(9667,1204,7),(9668,1204,8),(9669,1204,10),(9670,1204,34),(9671,1204,35),(9672,1204,22),(9673,1204,23),(9674,1204,38),(9675,1204,40),(9676,1204,43),(9677,1204,47),(9678,1204,49),(9679,1204,51),(9680,1204,55),(9681,1204,57),(9682,1204,308),(9683,1204,982),(9684,1204,1017),(9686,1204,60),(9687,1204,66),(9688,1204,294),(9689,1204,71),(9690,1204,74),(9691,1204,253),(9692,1204,258),(9693,1204,639),(9694,1204,640),(9695,1204,670),(9696,1204,103),(9697,1204,104),(9698,1204,159),(9699,1204,160),(9700,1204,166),(9701,1204,280),(9702,1204,188),(9703,1204,193),(9704,1204,214),(9705,1204,220),(9706,1204,1),(9707,1204,4),(9708,1204,2),(9709,1204,795),(9710,1204,7),(9711,1204,8),(9712,1204,10),(9713,1204,34),(9714,1204,35),(9715,1204,22),(9716,1204,23),(9717,1204,38),(9718,1204,40),(9719,1204,43),(9720,1204,47),(9721,1204,49),(9722,1204,51),(9723,1204,55),(9724,1204,57),(9725,1204,308),(9726,1204,982),(9727,1204,1017),(9728,1204,60),(9729,1204,66),(9730,1204,294),(9731,1204,71),(9732,1204,74),(9733,1204,253),(9734,1204,258),(9735,1204,639),(9736,1204,640),(9737,1204,670),(9738,1204,103),(9739,1204,104),(9740,1204,159),(9741,1204,160),(9742,1204,166),(9743,1204,280),(9744,1204,188),(9745,1204,193),(9746,1204,214),(9747,1204,220),(9748,1204,1),(9749,1204,4),(9750,1204,2),(9751,1204,795),(9752,1204,7),(9753,1204,8),(9754,1204,10),(9755,1204,34),(9756,1204,35),(9757,1204,22),(9758,1204,23),(9759,1204,38),(9760,1204,40),(9761,1204,43),(9762,1204,47),(9763,1204,49),(9764,1204,51),(9765,1204,55),(9766,1204,57),(9767,1204,308),(9768,1204,982),(9769,1204,1017),(9770,1204,60),(9771,1204,66),(9772,1204,294),(9773,1204,71),(9774,1204,74),(9775,1204,253),(9776,1204,258),(9777,1204,639),(9778,1204,640),(9779,1204,670),(9780,1204,103),(9781,1204,104),(9782,1204,159),(9783,1204,160),(9784,1204,166),(9785,1204,280),(9786,1204,1078),(9787,1204,188),(9788,1204,193),(9789,1204,214),(9790,1204,220);
/*!40000 ALTER TABLE `sys_game_resources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_game_server`
--

DROP TABLE IF EXISTS `sys_game_server`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_game_server` (
  `GAME_ID` int(3) NOT NULL COMMENT '游戏编号',
  `GATEWAY_ID` int(6) NOT NULL COMMENT '网关编号',
  `SERVER_ID` int(8) NOT NULL,
  `SERVER_NAME` varchar(64) NOT NULL,
  `URL` varchar(1024) NOT NULL COMMENT 'gm_server连接游戏世界的url',
  `GROUP_ID` int(2) NOT NULL,
  PRIMARY KEY (`GAME_ID`,`GATEWAY_ID`,`SERVER_ID`),
  CONSTRAINT `FK_SYS_GAME_REFERENCE_SYS_GATE` FOREIGN KEY (`GAME_ID`, `GATEWAY_ID`) REFERENCES `sys_gateway` (`GAME_ID`, `GATEWAY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='游戏服务器信息表。';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_game_server`
--

LOCK TABLES `sys_game_server` WRITE;
/*!40000 ALTER TABLE `sys_game_server` DISABLE KEYS */;
INSERT INTO `sys_game_server` VALUES (1204,104001,0,'test server','177.234.153.155:18008',0);
/*!40000 ALTER TABLE `sys_game_server` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_game_server1`
--

DROP TABLE IF EXISTS `sys_game_server1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_game_server1` (
  `GAME_ID` int(3) NOT NULL,
  `GATEWAY_ID` int(6) NOT NULL,
  `SERVER_ID` int(8) NOT NULL,
  `SERVER_NAME` varchar(64) NOT NULL,
  `URL` varchar(1024) NOT NULL,
  `GROUP_ID` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_game_server1`
--

LOCK TABLES `sys_game_server1` WRITE;
/*!40000 ALTER TABLE `sys_game_server1` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_game_server1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_gateway`
--

DROP TABLE IF EXISTS `sys_gateway`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_gateway` (
  `GAME_ID` int(3) NOT NULL COMMENT '游戏编号',
  `GATEWAY_ID` int(6) NOT NULL COMMENT '网关编号',
  `GATEWAY_TYPE` int(4) NOT NULL COMMENT '区服类型，0-体验区，1-正式区',
  `GATEWAY_PROVIDER` int(3) NOT NULL COMMENT '网关提供商，1-电信，2-网通',
  `GATEWAY_NAME` varchar(512) NOT NULL COMMENT '网关的名称。',
  `URL` varchar(1024) NOT NULL COMMENT 'gm_server服务器url',
  PRIMARY KEY (`GAME_ID`,`GATEWAY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='存储网关信息表。';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_gateway`
--

LOCK TABLES `sys_gateway` WRITE;
/*!40000 ALTER TABLE `sys_gateway` DISABLE KEYS */;
INSERT INTO `sys_gateway` VALUES (1204,104001,1,1,'test server','192.168.177.94:9999');
/*!40000 ALTER TABLE `sys_gateway` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_item`
--

DROP TABLE IF EXISTS `sys_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_item` (
  `ITEM_CODE` varchar(32) NOT NULL COMMENT '物品编号',
  `GAME_ID` int(3) NOT NULL COMMENT '游戏编号',
  `ITEM_NAME` varchar(64) NOT NULL COMMENT '物品名称',
  PRIMARY KEY (`ITEM_CODE`,`GAME_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='活动奖品信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_item`
--

LOCK TABLES `sys_item` WRITE;
/*!40000 ALTER TABLE `sys_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_league`
--

DROP TABLE IF EXISTS `sys_league`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_league` (
  `GAME_ID` int(3) NOT NULL COMMENT '游戏编号',
  `LEAGUE_CODE` varchar(32) NOT NULL COMMENT '联盟代码',
  `LEAGUE_NAME` varchar(64) NOT NULL COMMENT '联盟名称',
  PRIMARY KEY (`GAME_ID`,`LEAGUE_CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='联盟信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_league`
--

LOCK TABLES `sys_league` WRITE;
/*!40000 ALTER TABLE `sys_league` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_league` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_occupation`
--

DROP TABLE IF EXISTS `sys_occupation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_occupation` (
  `GAME_ID` int(3) NOT NULL,
  `OCCUPATION_CODE` varchar(32) NOT NULL,
  `OCCUPATION_NAME` varchar(64) NOT NULL,
  PRIMARY KEY (`GAME_ID`,`OCCUPATION_CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='职业信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_occupation`
--

LOCK TABLES `sys_occupation` WRITE;
/*!40000 ALTER TABLE `sys_occupation` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_occupation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_oper_role`
--

DROP TABLE IF EXISTS `sys_oper_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_oper_role` (
  `OPER_ID` int(10) NOT NULL COMMENT '操作员id',
  `ROLE_ID` int(6) NOT NULL COMMENT '角色id',
  PRIMARY KEY (`OPER_ID`,`ROLE_ID`),
  KEY `SYS_OPER_ROLE_FK1` (`ROLE_ID`),
  CONSTRAINT `SYS_OPER_ROLE_FK1` FOREIGN KEY (`ROLE_ID`) REFERENCES `sys_roles` (`ROLE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_oper_role`
--

LOCK TABLES `sys_oper_role` WRITE;
/*!40000 ALTER TABLE `sys_oper_role` DISABLE KEYS */;
INSERT INTO `sys_oper_role` VALUES (432712650,1),(432712651,2),(432712652,2),(432712653,2),(432712654,2),(432712655,2),(432712657,4),(432712658,4),(432712659,4),(432712660,4),(432712661,4),(432712662,4),(432712663,4);
/*!40000 ALTER TABLE `sys_oper_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_operators`
--

DROP TABLE IF EXISTS `sys_operators`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_operators` (
  `OPER_ID` int(10) NOT NULL COMMENT '操作员passport_id',
  `PASSPORT_NAME` varchar(32) NOT NULL COMMENT '从passport系统读取',
  `OPER_REAL_NAME` varchar(64) NOT NULL COMMENT '真实名称',
  `CREATE_TIME` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '创建时间',
  `LAST_LOGIN_IP` varchar(16) DEFAULT NULL COMMENT '最近登录ip',
  `LAST_LOGIN_TIME` datetime DEFAULT NULL COMMENT '最近登录时间',
  `OPER_EMAIL` varchar(128) NOT NULL COMMENT '电子邮箱',
  `LOGIN_COUNT` int(10) NOT NULL DEFAULT '0' COMMENT '登录次数,默认为0',
  `SUPERIOR_OPER` int(10) NOT NULL DEFAULT '0' COMMENT '上级用户',
  `OPER_LEVEL` int(2) NOT NULL DEFAULT '0' COMMENT '用户级别：  0 是普通管理员 10是GM上线人员 11是pfwork  20 客服总监  30游戏管理员',
  `GAME_ID` int(3) NOT NULL DEFAULT '0' COMMENT '-1 对应所有游戏(当 用户级别 为10 和11时)有效，正数对应相应的游戏',
  PRIMARY KEY (`OPER_ID`,`GAME_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_operators`
--

LOCK TABLES `sys_operators` WRITE;
/*!40000 ALTER TABLE `sys_operators` DISABLE KEYS */;
INSERT INTO `sys_operators` VALUES (1072508,'SpaceCowboy','SpaceCowboy','2017-06-29 23:43:52','179.215.124.118','2017-06-29 20:43:52','egmweb2@linekong.com',43,432712650,30,1204),(1072509,'linekong','linekong','2011-06-02 13:12:13',NULL,NULL,'egmweb2@linekong.com',0,432712650,30,1204),(432712650,'egmweb2','egmweb2','2014-04-28 09:01:14','113.208.129.50','2014-04-28 06:01:14','egmweb2@linekong.com',1,1899873,11,1204),(432712651,'globalgames1','111','2017-06-24 22:23:46','189.69.68.183','2017-06-24 19:23:46','111',16,1072508,0,1204),(432712652,'braziltest1','111','2017-06-27 22:08:28','189.69.68.183','2017-06-27 19:08:28','111',14,1072508,30,1204),(432712653,'braziltest2','braziltest2','2014-01-08 17:59:02','177.47.22.70','2014-01-08 15:59:02','22',1,1072508,0,1204),(432712654,'braziltest3','braziltest3','2013-12-19 07:34:46',NULL,NULL,'343',0,1072508,0,1204),(432712655,'braziltest4','braziltest4','2014-03-06 20:51:40','177.134.1.97','2014-03-06 17:51:40','434',2,1072508,0,1204),(432712656,'polaris','Daniele','2013-12-23 20:03:05',NULL,NULL,'daniele@globalgames.com.br',0,432712651,0,1204),(432712657,'jjuslulu','lucinda','2014-07-25 01:56:40','189.34.211.101','2014-07-24 22:56:40','1',8,1072508,0,1204),(432712658,'GLOBALgames01','GLOBALgames01','2014-05-21 16:47:11','179.215.89.170','2014-05-21 13:47:11','GLOBALgames01',4,1072508,0,1204),(432712659,'GLOBALgames02','GLOBALgames02','2014-05-03 18:15:23','189.34.243.238','2014-05-03 15:15:23','GLOBALgames02',2,1072508,0,1204),(432712660,'GLOBALgames03','GLOBALgames03','2014-04-14 04:04:54',NULL,NULL,'GLOBALgames03',0,1072508,0,1204),(432712661,'GLOBALgames04','GLOBALgames04','2014-04-14 04:05:04',NULL,NULL,'GLOBALgames04',0,1072508,0,1204),(432712662,'GLOBALgames05','GLOBALgames05','2014-09-18 13:36:00','177.47.22.70','2014-09-18 10:36:00','GLOBALgames05',3,1072508,0,1204),(432712663,'GLOBALgames06','GLOBALgames06','2014-04-14 04:05:24',NULL,NULL,'GLOBALgames06',0,1072508,0,1204);
/*!40000 ALTER TABLE `sys_operators` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_outer_resource`
--

DROP TABLE IF EXISTS `sys_outer_resource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_outer_resource` (
  `RES_ID` int(6) NOT NULL,
  `GAME_ID` int(4) NOT NULL,
  `RES_NAME` varchar(32) NOT NULL,
  `RES_DESC` varchar(256) DEFAULT NULL,
  `RES_URL` varchar(128) DEFAULT NULL COMMENT '资源url',
  `RES_TYPE` int(2) NOT NULL DEFAULT '0',
  `RES_PID` int(6) NOT NULL DEFAULT '0' COMMENT '父资源id',
  `RES_ORDER_NO` int(4) NOT NULL DEFAULT '0' COMMENT '排序id',
  `RES_UPDATE_TIME` datetime DEFAULT NULL COMMENT '更新时间',
  `RES_VISIT_TIME` datetime DEFAULT NULL COMMENT '访问时间',
  PRIMARY KEY (`RES_ID`,`GAME_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='外部资源表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_outer_resource`
--

LOCK TABLES `sys_outer_resource` WRITE;
/*!40000 ALTER TABLE `sys_outer_resource` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_outer_resource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_pet_menu`
--

DROP TABLE IF EXISTS `sys_pet_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_pet_menu` (
  `ITEM_ID` int(6) NOT NULL COMMENT '菜单项id',
  `GAME_ID` int(3) NOT NULL COMMENT '游戏id',
  `ITEM_NAME` varchar(16) NOT NULL COMMENT '菜单项名称',
  `ITEM_LABEL` varchar(32) NOT NULL COMMENT '菜单项显示名称',
  `ITEM_TYPE` int(1) NOT NULL COMMENT '菜单类型，1-文本框，2，下拉菜单',
  `ITEM_COMMENT` varchar(128) DEFAULT NULL COMMENT '菜单项注释',
  `OPTION_ID` int(3) DEFAULT NULL COMMENT '对应的下拉菜单id',
  `REQUIRED` int(1) NOT NULL COMMENT '是否必须，1-必须，2-不必须',
  `ORDER_NUMBER` int(2) NOT NULL COMMENT '排序号',
  `MENU_TYPE` int(1) NOT NULL,
  PRIMARY KEY (`ITEM_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='随从补偿与修改动态菜单配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_pet_menu`
--

LOCK TABLES `sys_pet_menu` WRITE;
/*!40000 ALTER TABLE `sys_pet_menu` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_pet_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_pet_menu_option`
--

DROP TABLE IF EXISTS `sys_pet_menu_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_pet_menu_option` (
  `OPTION_ID` int(3) NOT NULL COMMENT '下拉菜单id',
  `OPTION_LABEL` varchar(100) NOT NULL COMMENT '下拉菜单显示名称',
  `OPTION_VALUE` varchar(100) NOT NULL COMMENT '下拉菜单值',
  `CHECKED` int(1) NOT NULL COMMENT '是否默认选项,1-默认，2-不默认',
  `ORDER_NUMBER` int(2) NOT NULL COMMENT '排序号',
  PRIMARY KEY (`OPTION_ID`,`OPTION_VALUE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='随从补偿与修改动态菜单里的下拉菜单配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_pet_menu_option`
--

LOCK TABLES `sys_pet_menu_option` WRITE;
/*!40000 ALTER TABLE `sys_pet_menu_option` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_pet_menu_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_querydictionary`
--

DROP TABLE IF EXISTS `sys_querydictionary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_querydictionary` (
  `dictionary_id` int(11) NOT NULL AUTO_INCREMENT,
  `DICTIONARY_TYPE` int(8) NOT NULL COMMENT '字典类型',
  `OPTION_VALUE` varchar(200) NOT NULL COMMENT '选项值',
  `OPTION_TEXT` varchar(400) NOT NULL COMMENT '选项显示内容',
  `GAME_ID` int(8) NOT NULL COMMENT '游戏ID',
  `ORDER_NUM` int(8) DEFAULT NULL COMMENT '排序号',
  PRIMARY KEY (`dictionary_id`)
) ENGINE=InnoDB AUTO_INCREMENT=34428 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_querydictionary`
--

LOCK TABLES `sys_querydictionary` WRITE;
/*!40000 ALTER TABLE `sys_querydictionary` DISABLE KEYS */;
INSERT INTO `sys_querydictionary` VALUES (3393,2,'0','全部类型',16,0),(3394,2,'1','任务提交金钱',16,1),(3395,2,'2','任务获取金钱',16,2),(3396,2,'3','掉落拾取金钱',16,3),(3397,2,'4','交易获取金钱',16,4),(3398,2,'5','交易消耗金钱',16,5),(3399,2,'6','NPC购买消耗金钱',16,6),(3400,2,'7','NPC卖出获取金钱',16,7),(3401,2,'8','摊位购买消耗金钱',16,8),(3402,2,'9','摊位卖出获取金钱',16,9),(3403,2,'10','系统奖励金钱',16,10),(3404,2,'11','系统奖励金钱',16,11),(3405,2,'12','系统奖励金钱',16,12),(3406,2,'13','系统奖励金钱',16,13),(3407,2,'14','系统奖励金钱',16,14),(3408,2,'15','系统奖励金钱',16,15),(3409,2,'16','系统奖励金钱',16,16),(3410,2,'17','系统奖励金钱',16,17),(3411,4,'0','全部类型',16,0),(3412,4,'1','金币',16,1),(3413,3,'0','全部类型',16,0),(3414,3,'1','任务获取经验',16,1),(3415,3,'2','打怪获取经验',16,2),(3416,3,'3','打坐获取经验',16,3),(3417,3,'4','自己爆筋脉获取经验',16,4),(3418,3,'5','别人爆筋脉获取经验',16,5),(3419,3,'6','闭关获取经验',16,6),(3420,3,'7','修行问答获取经验',16,7),(3421,3,'8','系统补偿经验',16,8),(3422,3,'9','经验丹获取经验',16,9),(3423,5,'0','全部类型',16,0),(3424,5,'1','原始经验',16,1),(3425,5,'2','双倍经验',16,2),(3426,1,'0','全部类型',16,0),(3427,1,'1','残卷合成',16,1),(3428,1,'2','宝石合成',16,2),(3429,1,'3','宝石镶嵌',16,3),(3430,1,'4','宝石摘除',16,4),(3431,1,'5','装备升阶',16,5),(3432,1,'6','装备升品',16,6),(3433,1,'7','装备强化',16,7),(3434,1,'8','装备强化重置',16,8),(3435,1,'9','穿装备',16,9),(3436,1,'10','脱装备',16,10),(3437,1,'11','宠物品级强化',16,11),(3438,1,'12','宠物提升悟性',16,12),(3439,1,'13','宠物学习技能',16,13),(3440,1,'14','宠物穿装备',16,14),(3441,1,'15','宠物脱装备',16,15),(3442,1,'16','宠物升阶',16,16),(3443,1,'17','宠物强化潜力',16,17),(4583,1,'0','全部类型',16,0),(4584,1,'1','怪物掉落生成',16,1),(4585,1,'2','角色掉落生成',16,2),(4586,1,'3','GM命令掉落生成',16,3),(4587,1,'4','使用福袋宝箱生成',16,4),(4588,1,'101','宠物身上脱下装备获得',16,101),(4589,1,'102','商城购买获得',16,102),(4590,1,'103','残卷合成获得',16,103),(4591,1,'104','填充钱袋获得',16,104),(4592,1,'105','填充真气获得',16,105),(4593,1,'106','宝石合成获得',16,106),(4594,1,'107','宝石摘除获得',16,107),(4595,1,'108','副本通关奖励获得',16,108),(4596,1,'109','新手在线礼物获得',16,109),(4597,1,'110','打开礼包获得',16,110),(4598,1,'111','每周连续在线礼物获得',16,111),(4599,1,'112','新手升级礼包自动补偿获得',16,112),(4600,1,'114','任务物品获得',16,114),(4601,1,'115','任务奖励获得',16,115),(4602,1,'116','活动物品获得',16,116),(4603,1,'117','活动奖励获得',16,117),(4604,1,'118','成就奖励获得',16,118),(4605,1,'119','系统补偿获得',16,119),(4606,1,'120','掉落拾取获得',16,120),(4607,1,'121','打开福袋宝箱获得',16,121),(4608,1,'122','NPC商店购买获得',16,122),(4609,1,'123','面对面交易获得',16,123),(4610,1,'124','摆摊下架获得',16,124),(4611,1,'125','摊位购买获得',16,125),(4612,1,'126','背包整理获得',16,126),(4613,1,'127','仓库整理获得',16,127),(4614,1,'128','宠物卡片获取宠物',16,128),(4615,1,'129','抓获宠物获得',16,129),(4616,1,'130','物品拆分获得',16,130),(4617,1,'201','玩家消耗失去',16,201),(4618,1,'202','使用物品失去',16,202),(4619,1,'203','宠物穿装备失去',16,203),(4620,1,'204','残卷合成消耗失去',16,204),(4621,1,'205','宝石合成消耗失去',16,205),(4622,1,'206','装备镶嵌宝石消耗失去',16,206),(4623,1,'207','进入副本消耗失去',16,207),(4624,1,'208','进入百炼忍传消耗失去',16,208),(4625,1,'209','仓库扩展消耗失去',16,209),(4626,1,'210','背包扩展消耗失去',16,210),(4627,1,'211','宠物栏扩展消耗失去',16,211),(4628,1,'212','学习技能消耗失去',16,212),(4629,1,'213','喇叭喊话消耗失去',16,213),(4630,1,'214','卡片收集消耗失去',16,214),(4631,1,'215','创建家族消耗失去',16,215),(4632,1,'216','家族贡献失去',16,216),(4633,1,'217','族旗消耗失去',16,217),(4634,1,'218','PK掉落失去',16,218),(4635,1,'219','战场钥匙失去',16,219),(4636,1,'220','角色查找消耗失去',16,220),(4637,1,'221','装备升阶消耗失去',16,221),(4638,1,'222','装备提示品级消耗失去',16,222),(4639,1,'223','装备强化消耗失去',16,223),(4640,1,'224','装备强化重置消耗失去',16,224),(4641,1,'225','装备修理消耗失去',16,225),(4642,1,'226','装备破碎恢复消耗失去',16,226),(4643,1,'227','填充真气消耗失去',16,227),(4644,1,'228','爆经脉消耗失去',16,228),(4645,1,'229','重洗AP消耗失去',16,229),(4646,1,'230','任务物品提交失去',16,230),(4647,1,'231','宠物提升品级消耗失去',16,231),(4648,1,'232','宠物提升悟性消耗失去',16,232),(4649,1,'233','宠物升阶消耗失去',16,233),(4650,1,'234','宠物提升潜力消耗失去',16,234),(4651,1,'235','物品摊位上架失去',16,235),(4652,1,'236','摊位买出失去',16,236),(4653,1,'237','面对面交易失去',16,237),(4654,1,'238','NPC商店出售失去',16,238),(4655,1,'239','系统消耗失去',16,239),(4656,1,'240','宠物放生失去',16,240),(4657,1,'241','物品拆分失去',16,241),(4658,1,'242','背包整理失去',16,242),(4659,1,'243','仓库整理失去',16,243),(4660,1,'301','从背包带角色身上',16,301),(4661,1,'302','从背包带仓库',16,302),(4662,1,'303','从角色身上到背包',16,303),(4663,1,'304','从仓库到背包',16,304),(4664,1,'305','装备镶嵌宝石改变',16,305),(4665,1,'306','装备摘除宝石改变',16,306),(4666,1,'307','装备升阶改变',16,307),(4667,1,'308','装备提升品级改变',16,308),(4668,1,'309','装备强化改变',16,309),(4669,1,'310','装备强化重置改变',16,310),(4670,1,'311','装备耐久修理改变',16,311),(4671,1,'312','装备破碎修复改变',16,312),(4672,1,'313','宠物穿装备改变',16,313),(4673,1,'314','宠物脱装备改变',16,314),(4674,1,'315','宠物学习技能改变',16,315),(4675,1,'316','宠物提升品级改变',16,316),(4676,1,'317','宠物提升悟性改变',16,317),(4677,1,'318','宠物升阶改变',16,318),(4678,1,'319','宠物提升附加属性改变',16,319),(5063,1,'0','全部类型',16,0),(5064,1,'1','怪物掉落生成',16,1),(5065,1,'2','角色掉落生成',16,2),(5066,1,'3','GM命令掉落生成',16,3),(5067,1,'4','使用福袋宝箱生成',16,4),(5068,1,'101','宠物身上脱下装备获得',16,101),(5069,1,'102','商城购买获得',16,102),(5070,1,'103','残卷合成获得',16,103),(5071,1,'104','填充钱袋获得',16,104),(5072,1,'105','填充真气获得',16,105),(5073,1,'106','宝石合成获得',16,106),(5074,1,'107','宝石摘除获得',16,107),(5075,1,'108','副本通关奖励获得',16,108),(5076,1,'109','新手在线礼物获得',16,109),(5077,1,'110','打开礼包获得',16,110),(5078,1,'111','每周连续在线礼物获得',16,111),(5079,1,'112','新手升级礼包自动补偿获得',16,112),(5080,1,'114','任务物品获得',16,114),(5081,1,'115','任务奖励获得',16,115),(5082,1,'116','活动物品获得',16,116),(5083,1,'117','活动奖励获得',16,117),(5084,1,'118','成就奖励获得',16,118),(5085,1,'119','系统补偿获得',16,119),(5086,1,'120','掉落拾取获得',16,120),(5087,1,'121','打开福袋宝箱获得',16,121),(5088,1,'122','NPC商店购买获得',16,122),(5089,1,'123','面对面交易获得',16,123),(5090,1,'124','摆摊下架获得',16,124),(5091,1,'125','摊位购买获得',16,125),(5092,1,'126','背包整理获得',16,126),(5093,1,'127','仓库整理获得',16,127),(5094,1,'128','宠物卡片获取宠物',16,128),(5095,1,'129','抓获宠物获得',16,129),(5096,1,'130','物品拆分获得',16,130),(5097,1,'201','玩家消耗失去',16,201),(5098,1,'202','使用物品失去',16,202),(5099,1,'203','宠物穿装备失去',16,203),(5100,1,'204','残卷合成消耗失去',16,204),(5101,1,'205','宝石合成消耗失去',16,205),(5102,1,'206','装备镶嵌宝石消耗失去',16,206),(5103,1,'207','进入副本消耗失去',16,207),(5104,1,'208','进入百炼忍传消耗失去',16,208),(5105,1,'209','仓库扩展消耗失去',16,209),(5106,1,'210','背包扩展消耗失去',16,210),(5107,1,'211','宠物栏扩展消耗失去',16,211),(5108,1,'212','学习技能消耗失去',16,212),(5109,1,'213','喇叭喊话消耗失去',16,213),(5110,1,'214','卡片收集消耗失去',16,214),(5111,1,'215','创建家族消耗失去',16,215),(5112,1,'216','家族贡献失去',16,216),(5113,1,'217','族旗消耗失去',16,217),(5114,1,'218','PK掉落失去',16,218),(5115,1,'219','战场钥匙失去',16,219),(5116,1,'220','角色查找消耗失去',16,220),(5117,1,'221','装备升阶消耗失去',16,221),(5118,1,'222','装备提示品级消耗失去',16,222),(5119,1,'223','装备强化消耗失去',16,223),(5120,1,'224','装备强化重置消耗失去',16,224),(5121,1,'225','装备修理消耗失去',16,225),(5122,1,'226','装备破碎恢复消耗失去',16,226),(5123,1,'227','填充真气消耗失去',16,227),(5124,1,'228','爆经脉消耗失去',16,228),(5125,1,'229','重洗AP消耗失去',16,229),(5126,1,'230','任务物品提交失去',16,230),(5127,1,'231','宠物提升品级消耗失去',16,231),(5128,1,'232','宠物提升悟性消耗失去',16,232),(5129,1,'233','宠物升阶消耗失去',16,233),(5130,1,'234','宠物提升潜力消耗失去',16,234),(5131,1,'235','物品摊位上架失去',16,235),(5132,1,'236','摊位买出失去',16,236),(5133,1,'237','面对面交易失去',16,237),(5134,1,'238','NPC商店出售失去',16,238),(5135,1,'239','系统消耗失去',16,239),(5136,1,'240','宠物放生失去',16,240),(5137,1,'241','物品拆分失去',16,241),(5138,1,'242','背包整理失去',16,242),(5139,1,'243','仓库整理失去',16,243),(5140,1,'301','从背包带角色身上',16,301),(5141,1,'302','从背包带仓库',16,302),(5142,1,'303','从角色身上到背包',16,303),(5143,1,'304','从仓库到背包',16,304),(5144,1,'305','装备镶嵌宝石改变',16,305),(5145,1,'306','装备摘除宝石改变',16,306),(5146,1,'307','装备升阶改变',16,307),(5147,1,'308','装备提升品级改变',16,308),(5148,1,'309','装备强化改变',16,309),(5149,1,'310','装备强化重置改变',16,310),(5150,1,'311','装备耐久修理改变',16,311),(5151,1,'312','装备破碎修复改变',16,312),(5152,1,'313','宠物穿装备改变',16,313),(5153,1,'314','宠物脱装备改变',16,314),(5154,1,'315','宠物学习技能改变',16,315),(5155,1,'316','宠物提升品级改变',16,316),(5156,1,'317','宠物提升悟性改变',16,317),(5157,1,'318','宠物升阶改变',16,318),(5158,1,'319','宠物提升附加属性改变',16,319),(5543,1,'0','全部类型',16,0),(5544,1,'1','怪物掉落生成',16,1),(5545,1,'2','角色掉落生成',16,2),(5546,1,'3','GM命令掉落生成',16,3),(5547,1,'4','使用福袋宝箱生成',16,4),(5548,1,'101','宠物身上脱下装备获得',16,101),(5549,1,'102','商城购买获得',16,102),(5550,1,'103','残卷合成获得',16,103),(5551,1,'104','填充钱袋获得',16,104),(5552,1,'105','填充真气获得',16,105),(5553,1,'106','宝石合成获得',16,106),(5554,1,'107','宝石摘除获得',16,107),(5555,1,'108','副本通关奖励获得',16,108),(5556,1,'109','新手在线礼物获得',16,109),(5557,1,'110','打开礼包获得',16,110),(5558,1,'111','每周连续在线礼物获得',16,111),(5559,1,'112','新手升级礼包自动补偿获得',16,112),(5560,1,'114','任务物品获得',16,114),(5561,1,'115','任务奖励获得',16,115),(5562,1,'116','活动物品获得',16,116),(5563,1,'117','活动奖励获得',16,117),(5564,1,'118','成就奖励获得',16,118),(5565,1,'119','系统补偿获得',16,119),(5566,1,'120','掉落拾取获得',16,120),(5567,1,'121','打开福袋宝箱获得',16,121),(5568,1,'122','NPC商店购买获得',16,122),(5569,1,'123','面对面交易获得',16,123),(5570,1,'124','摆摊下架获得',16,124),(5571,1,'125','摊位购买获得',16,125),(5572,1,'126','背包整理获得',16,126),(5573,1,'127','仓库整理获得',16,127),(5574,1,'128','宠物卡片获取宠物',16,128),(5575,1,'129','抓获宠物获得',16,129),(5576,1,'130','物品拆分获得',16,130),(5577,1,'201','玩家消耗失去',16,201),(5578,1,'202','使用物品失去',16,202),(5579,1,'203','宠物穿装备失去',16,203),(5580,1,'204','残卷合成消耗失去',16,204),(5581,1,'205','宝石合成消耗失去',16,205),(5582,1,'206','装备镶嵌宝石消耗失去',16,206),(5583,1,'207','进入副本消耗失去',16,207),(5584,1,'208','进入百炼忍传消耗失去',16,208),(5585,1,'209','仓库扩展消耗失去',16,209),(5586,1,'210','背包扩展消耗失去',16,210),(5587,1,'211','宠物栏扩展消耗失去',16,211),(5588,1,'212','学习技能消耗失去',16,212),(5589,1,'213','喇叭喊话消耗失去',16,213),(5590,1,'214','卡片收集消耗失去',16,214),(5591,1,'215','创建家族消耗失去',16,215),(5592,1,'216','家族贡献失去',16,216),(5593,1,'217','族旗消耗失去',16,217),(5594,1,'218','PK掉落失去',16,218),(5595,1,'219','战场钥匙失去',16,219),(5596,1,'220','角色查找消耗失去',16,220),(5597,1,'221','装备升阶消耗失去',16,221),(5598,1,'222','装备提示品级消耗失去',16,222),(5599,1,'223','装备强化消耗失去',16,223),(5600,1,'224','装备强化重置消耗失去',16,224),(5601,1,'225','装备修理消耗失去',16,225),(5602,1,'226','装备破碎恢复消耗失去',16,226),(5603,1,'227','填充真气消耗失去',16,227),(5604,1,'228','爆经脉消耗失去',16,228),(5605,1,'229','重洗AP消耗失去',16,229),(5606,1,'230','任务物品提交失去',16,230),(5607,1,'231','宠物提升品级消耗失去',16,231),(5608,1,'232','宠物提升悟性消耗失去',16,232),(5609,1,'233','宠物升阶消耗失去',16,233),(5610,1,'234','宠物提升潜力消耗失去',16,234),(5611,1,'235','物品摊位上架失去',16,235),(5612,1,'236','摊位买出失去',16,236),(5613,1,'237','面对面交易失去',16,237),(5614,1,'238','NPC商店出售失去',16,238),(5615,1,'239','系统消耗失去',16,239),(5616,1,'240','宠物放生失去',16,240),(5617,1,'241','物品拆分失去',16,241),(5618,1,'242','背包整理失去',16,242),(5619,1,'243','仓库整理失去',16,243),(5620,1,'301','从背包带角色身上',16,301),(5621,1,'302','从背包带仓库',16,302),(5622,1,'303','从角色身上到背包',16,303),(5623,1,'304','从仓库到背包',16,304),(5624,1,'305','装备镶嵌宝石改变',16,305),(5625,1,'306','装备摘除宝石改变',16,306),(5626,1,'307','装备升阶改变',16,307),(5627,1,'308','装备提升品级改变',16,308),(5628,1,'309','装备强化改变',16,309),(5629,1,'310','装备强化重置改变',16,310),(5630,1,'311','装备耐久修理改变',16,311),(5631,1,'312','装备破碎修复改变',16,312),(5632,1,'313','宠物穿装备改变',16,313),(5633,1,'314','宠物脱装备改变',16,314),(5634,1,'315','宠物学习技能改变',16,315),(5635,1,'316','宠物提升品级改变',16,316),(5636,1,'317','宠物提升悟性改变',16,317),(5637,1,'318','宠物升阶改变',16,318),(5638,1,'319','宠物提升附加属性改变',16,319),(6023,1,'0','全部类型',16,0),(6024,1,'1','怪物掉落生成',16,1),(6025,1,'2','角色掉落生成',16,2),(6026,1,'3','GM命令掉落生成',16,3),(6027,1,'4','使用福袋宝箱生成',16,4),(6028,1,'101','宠物身上脱下装备获得',16,101),(6029,1,'102','商城购买获得',16,102),(6030,1,'103','残卷合成获得',16,103),(6031,1,'104','填充钱袋获得',16,104),(6032,1,'105','填充真气获得',16,105),(6033,1,'106','宝石合成获得',16,106),(6034,1,'107','宝石摘除获得',16,107),(6035,1,'108','副本通关奖励获得',16,108),(6036,1,'109','新手在线礼物获得',16,109),(6037,1,'110','打开礼包获得',16,110),(6038,1,'111','每周连续在线礼物获得',16,111),(6039,1,'112','新手升级礼包自动补偿获得',16,112),(6040,1,'114','任务物品获得',16,114),(6041,1,'115','任务奖励获得',16,115),(6042,1,'116','活动物品获得',16,116),(6043,1,'117','活动奖励获得',16,117),(6044,1,'118','成就奖励获得',16,118),(6045,1,'119','系统补偿获得',16,119),(6046,1,'120','掉落拾取获得',16,120),(6047,1,'121','打开福袋宝箱获得',16,121),(6048,1,'122','NPC商店购买获得',16,122),(6049,1,'123','面对面交易获得',16,123),(6050,1,'124','摆摊下架获得',16,124),(6051,1,'125','摊位购买获得',16,125),(6052,1,'126','背包整理获得',16,126),(6053,1,'127','仓库整理获得',16,127),(6054,1,'128','宠物卡片获取宠物',16,128),(6055,1,'129','抓获宠物获得',16,129),(6056,1,'130','物品拆分获得',16,130),(6057,1,'201','玩家消耗失去',16,201),(6058,1,'202','使用物品失去',16,202),(6059,1,'203','宠物穿装备失去',16,203),(6060,1,'204','残卷合成消耗失去',16,204),(6061,1,'205','宝石合成消耗失去',16,205),(6062,1,'206','装备镶嵌宝石消耗失去',16,206),(6063,1,'207','进入副本消耗失去',16,207),(6064,1,'208','进入百炼忍传消耗失去',16,208),(6065,1,'209','仓库扩展消耗失去',16,209),(6066,1,'210','背包扩展消耗失去',16,210),(6067,1,'211','宠物栏扩展消耗失去',16,211),(6068,1,'212','学习技能消耗失去',16,212),(6069,1,'213','喇叭喊话消耗失去',16,213),(6070,1,'214','卡片收集消耗失去',16,214),(6071,1,'215','创建家族消耗失去',16,215),(6072,1,'216','家族贡献失去',16,216),(6073,1,'217','族旗消耗失去',16,217),(6074,1,'218','PK掉落失去',16,218),(6075,1,'219','战场钥匙失去',16,219),(6076,1,'220','角色查找消耗失去',16,220),(6077,1,'221','装备升阶消耗失去',16,221),(6078,1,'222','装备提示品级消耗失去',16,222),(6079,1,'223','装备强化消耗失去',16,223),(6080,1,'224','装备强化重置消耗失去',16,224),(6081,1,'225','装备修理消耗失去',16,225),(6082,1,'226','装备破碎恢复消耗失去',16,226),(6083,1,'227','填充真气消耗失去',16,227),(6084,1,'228','爆经脉消耗失去',16,228),(6085,1,'229','重洗AP消耗失去',16,229),(6086,1,'230','任务物品提交失去',16,230),(6087,1,'231','宠物提升品级消耗失去',16,231),(6088,1,'232','宠物提升悟性消耗失去',16,232),(6089,1,'233','宠物升阶消耗失去',16,233),(6090,1,'234','宠物提升潜力消耗失去',16,234),(6091,1,'235','物品摊位上架失去',16,235),(6092,1,'236','摊位买出失去',16,236),(6093,1,'237','面对面交易失去',16,237),(6094,1,'238','NPC商店出售失去',16,238),(6095,1,'239','系统消耗失去',16,239),(6096,1,'240','宠物放生失去',16,240),(6097,1,'241','物品拆分失去',16,241),(6098,1,'242','背包整理失去',16,242),(6099,1,'243','仓库整理失去',16,243),(6100,1,'301','从背包带角色身上',16,301),(6101,1,'302','从背包带仓库',16,302),(6102,1,'303','从角色身上到背包',16,303),(6103,1,'304','从仓库到背包',16,304),(6104,1,'305','装备镶嵌宝石改变',16,305),(6105,1,'306','装备摘除宝石改变',16,306),(6106,1,'307','装备升阶改变',16,307),(6107,1,'308','装备提升品级改变',16,308),(6108,1,'309','装备强化改变',16,309),(6109,1,'310','装备强化重置改变',16,310),(6110,1,'311','装备耐久修理改变',16,311),(6111,1,'312','装备破碎修复改变',16,312),(6112,1,'313','宠物穿装备改变',16,313),(6113,1,'314','宠物脱装备改变',16,314),(6114,1,'315','宠物学习技能改变',16,315),(6115,1,'316','宠物提升品级改变',16,316),(6116,1,'317','宠物提升悟性改变',16,317),(6117,1,'318','宠物升阶改变',16,318),(6118,1,'319','宠物提升附加属性改变',16,319),(6503,2,'0','全部类型',16,0),(6504,2,'1','充值获得',16,1),(6505,2,'2','任务奖励获得',16,2),(6506,2,'3','拾取获得',16,3),(6507,2,'4','面对面交易获得',16,4),(6508,2,'5','出售物品到NPC获得',16,5),(6509,2,'6','摆摊出售物品获得',16,6),(6510,2,'7','系统补偿获得',16,7),(6511,2,'8','GM命令获得',16,8),(6512,2,'9','NPC脚本获得',16,9),(6513,2,'10','从仓库取出获得',16,10),(6514,2,'11','修行事件获得',16,11),(6515,2,'12','打开钱袋获得',16,12),(6516,2,'13','成就奖励获得',16,13),(6517,2,'14','打开礼包获得',16,14),(6518,2,'15','每周连续在线获得',16,15),(6519,2,'16','新手礼金获得',16,16),(6520,2,'17','每日签到礼金获得',16,17),(6521,2,'18','商城购买失去',16,18),(6522,2,'19','提交任务失去',16,19),(6523,2,'20','面对面交易失去',16,20),(6524,2,'21','NPC商店购买失去',16,21),(6525,2,'22','摊位购买失去',16,22),(6526,2,'23','家族创建失去',16,23),(6527,2,'24','族旗操作失去',16,24),(6528,2,'25','家族贡献失去',16,25),(6529,2,'26','残卷合成操作失去',16,26),(6530,2,'27','宝石合成操作失去',16,27),(6531,2,'28','装备升阶操作失去',16,28),(6532,2,'29','装备提升品级操作失去',16,29),(6533,2,'30','装备强化操作失去',16,30),(6534,2,'31','装备强化重置操作失去',16,31),(6535,2,'32','装备耐久修理失去',16,32),(6536,2,'33','装备破碎修复操作失去',16,33),(6537,2,'34','宠物提升品级操作失去',16,34),(6538,2,'35','宠物提升悟性操作失去',16,35),(6539,2,'36','宠物升阶操作失去',16,36),(6540,2,'37','宠物提升悟性操作失去',16,37),(6541,2,'38','技能升级操作失去',16,38),(6542,2,'39','存入仓库失去',16,39),(6543,2,'40','冲入钱袋失去',16,40),(6708,3,'0','全部类型',16,0),(6709,3,'1','任务奖励',16,1),(6710,3,'2','杀怪获得',16,2),(6711,3,'3','打坐获得',16,3),(6712,3,'4','自己爆八门获得',16,4),(6713,3,'5','别人爆把门分享获得',16,5),(6714,3,'6','闭关获得',16,6),(6715,3,'7','休息事件获得',16,7),(6716,3,'8','系统补偿获得',16,8),(6717,3,'9','吃经验丹获得',16,9),(6718,3,'10','战场地图获得',16,10),(6763,4,'0','全部类型',16,0),(6764,4,'1','金币',16,1),(6765,4,'4','礼金',16,2),(6766,4,'5','元宝',16,5),(6783,5,'0','全部类型',16,0),(6784,5,'1','原始经验',16,1),(6785,5,'2','多倍经验',16,2),(33418,13,'0','全部类型',16,0),(33419,13,'1','打怪获取阅历',16,1),(33420,13,'2','学意志消耗阅历',16,2),(33421,13,'3','一键学习意志消耗阅历',16,3),(33422,13,'4','卖意志获得阅历',16,4),(33423,13,'5','一键卖出意志获得阅历',16,5),(33424,13,'6','修行问答获取阅历',16,6),(34425,13,'7','系统补偿阅历',16,7),(34426,13,'8','阅历符获得阅历',16,8),(34427,13,'9','阅历丹获得阅历',16,9);
/*!40000 ALTER TABLE `sys_querydictionary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_res_relation`
--

DROP TABLE IF EXISTS `sys_res_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_res_relation` (
  `RES_ID` int(6) NOT NULL COMMENT '资源id',
  `REL_RES_ID` int(6) NOT NULL COMMENT '关联资源的id',
  PRIMARY KEY (`RES_ID`,`REL_RES_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='资源关联表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_res_relation`
--

LOCK TABLES `sys_res_relation` WRITE;
/*!40000 ALTER TABLE `sys_res_relation` DISABLE KEYS */;
INSERT INTO `sys_res_relation` VALUES (4,2),(4,3),(4,5),(4,6),(4,24),(4,25),(4,26),(4,612),(4,673),(8,9),(10,3),(10,5),(10,9),(10,11),(10,12),(10,27),(10,28),(10,29),(10,612),(10,645),(10,673),(10,870),(10,871),(10,872),(10,960),(10,961),(10,962),(10,985),(14,15),(14,20),(16,17),(18,15),(18,19),(18,20),(18,21),(18,251),(23,59),(30,31),(32,33),(36,37),(38,39),(40,41),(40,42),(43,44),(45,46),(45,794),(47,48),(47,1035),(49,50),(51,52),(53,54),(55,56),(57,58),(60,1036),(61,62),(61,63),(61,64),(61,65),(61,278),(61,399),(61,643),(66,67),(66,68),(66,69),(66,70),(71,67),(71,72),(71,73),(74,67),(74,75),(74,76),(74,459),(78,79),(78,80),(78,81),(78,82),(78,83),(78,84),(78,85),(78,86),(78,87),(78,88),(78,89),(78,90),(78,91),(78,92),(78,93),(78,94),(78,249),(78,354),(78,355),(95,96),(95,97),(95,98),(95,99),(95,279),(95,399),(95,644),(100,67),(100,101),(100,102),(103,1139),(104,105),(104,106),(104,107),(104,108),(104,109),(104,110),(104,111),(104,112),(104,113),(104,114),(104,115),(104,116),(104,117),(104,118),(104,119),(104,120),(104,121),(104,122),(104,356),(104,357),(123,124),(123,125),(123,126),(123,127),(123,128),(123,129),(123,130),(123,131),(123,132),(123,133),(123,134),(123,135),(123,136),(123,137),(123,138),(123,139),(123,140),(123,586),(123,587),(141,142),(141,143),(141,144),(141,145),(141,146),(141,147),(141,148),(141,149),(141,150),(141,151),(141,152),(141,153),(141,154),(141,155),(141,156),(141,157),(141,158),(141,574),(141,575),(141,576),(141,577),(141,578),(141,579),(141,580),(141,581),(141,582),(141,583),(160,161),(160,162),(160,163),(160,164),(160,165),(166,167),(166,168),(166,169),(166,170),(166,252),(171,172),(171,173),(171,174),(171,175),(171,176),(171,177),(171,178),(171,179),(171,180),(171,181),(171,182),(171,183),(171,184),(171,185),(171,186),(171,187),(171,1000),(171,1001),(171,1002),(189,194),(189,199),(189,204),(189,209),(190,195),(190,200),(190,207),(190,213),(191,196),(191,202),(191,205),(191,211),(192,197),(192,201),(192,206),(192,210),(193,198),(193,203),(193,208),(193,212),(214,215),(214,216),(214,217),(214,218),(214,219),(214,1013),(214,1014),(220,221),(220,222),(220,223),(220,224),(220,225),(220,1011),(220,1012),(226,227),(226,228),(226,229),(231,232),(231,233),(231,234),(231,235),(231,236),(231,237),(231,238),(231,239),(231,240),(231,241),(231,242),(231,243),(231,244),(231,245),(231,246),(231,247),(231,248),(231,570),(231,571),(253,254),(253,255),(258,256),(258,257),(259,260),(259,261),(262,256),(262,263),(264,265),(264,266),(264,310),(267,268),(269,270),(269,636),(271,272),(274,275),(276,277),(280,281),(280,282),(280,283),(280,284),(280,285),(280,286),(280,436),(280,437),(280,460),(280,461),(280,462),(280,463),(280,464),(280,594),(280,595),(280,821),(280,822),(280,823),(280,824),(287,105),(287,106),(287,107),(287,108),(287,109),(287,110),(287,111),(287,112),(287,113),(287,114),(287,115),(287,116),(287,117),(287,122),(288,289),(288,290),(288,291),(288,292),(288,293),(294,67),(294,295),(294,296),(294,310),(297,298),(297,299),(300,301),(300,302),(303,79),(303,80),(303,81),(303,82),(303,83),(303,84),(303,85),(303,86),(303,87),(303,88),(303,89),(303,94),(303,249),(304,105),(304,106),(304,107),(304,108),(304,109),(304,110),(304,111),(304,112),(304,113),(304,114),(304,115),(304,116),(304,117),(304,118),(304,119),(304,122),(304,356),(305,79),(305,80),(305,81),(305,82),(305,83),(305,84),(305,85),(305,86),(305,87),(305,88),(305,89),(305,90),(305,91),(305,94),(305,249),(305,354),(306,307),(308,309),(311,312),(311,313),(311,314),(315,316),(315,317),(315,318),(315,319),(315,320),(315,321),(315,1003),(315,1004),(315,1005),(322,323),(322,324),(322,325),(322,326),(322,327),(322,328),(322,329),(322,331),(322,332),(322,333),(322,334),(322,335),(322,336),(322,337),(322,338),(322,339),(322,340),(322,341),(322,352),(322,353),(342,323),(342,324),(342,325),(342,326),(342,327),(342,328),(342,329),(342,331),(342,332),(342,333),(342,335),(342,336),(342,337),(342,341),(343,323),(343,324),(343,325),(343,326),(343,327),(343,328),(343,329),(343,331),(343,332),(343,333),(343,334),(343,335),(343,336),(343,338),(343,341),(343,352),(344,345),(344,346),(344,347),(344,348),(344,349),(344,350),(344,351),(358,359),(360,361),(362,363),(362,364),(362,365),(362,1015),(362,1016),(366,367),(368,369),(368,370),(368,371),(368,372),(368,373),(368,374),(368,375),(368,376),(368,377),(368,378),(368,379),(368,380),(368,381),(368,382),(389,369),(389,370),(389,371),(389,372),(389,373),(389,374),(389,375),(389,376),(389,377),(389,378),(389,379),(389,380),(389,381),(389,382),(389,383),(389,384),(389,385),(390,369),(390,370),(390,371),(390,372),(390,373),(390,374),(390,375),(390,376),(390,377),(390,378),(390,379),(390,380),(390,381),(390,382),(390,383),(390,384),(390,385),(390,386),(390,387),(390,388),(391,392),(391,435),(400,401),(400,402),(400,403),(400,404),(400,405),(400,406),(400,407),(400,408),(400,409),(400,410),(400,411),(400,412),(400,413),(400,414),(400,415),(400,416),(400,417),(400,418),(400,419),(400,420),(400,421),(422,401),(422,402),(422,403),(422,404),(422,405),(422,406),(422,407),(422,408),(422,409),(422,410),(422,411),(422,412),(422,413),(422,414),(422,415),(423,401),(423,402),(423,403),(423,404),(423,405),(423,406),(423,407),(423,408),(423,409),(423,410),(423,411),(423,412),(423,413),(423,414),(423,415),(423,416),(423,417),(423,418),(433,434),(433,635),(438,439),(440,444),(440,445),(441,444),(441,445),(441,446),(441,447),(442,444),(442,445),(442,448),(442,449),(442,450),(442,451),(442,452),(442,453),(443,444),(443,445),(443,454),(443,455),(456,457),(456,458),(465,466),(465,467),(465,468),(465,469),(470,471),(472,473),(472,474),(475,476),(477,478),(477,479),(477,480),(477,481),(477,482),(477,483),(477,484),(477,485),(477,486),(477,487),(477,488),(477,489),(477,490),(477,491),(477,492),(477,493),(477,494),(477,495),(477,496),(497,498),(497,499),(497,500),(497,501),(497,502),(497,503),(497,504),(497,505),(497,506),(497,507),(497,508),(497,509),(497,510),(497,511),(497,512),(497,513),(497,514),(497,515),(497,516),(497,541),(497,542),(517,518),(517,519),(517,520),(521,522),(521,523),(521,524),(521,525),(521,526),(521,527),(521,528),(521,529),(521,530),(521,531),(521,532),(521,533),(521,534),(521,535),(521,536),(521,537),(521,538),(521,539),(521,540),(543,544),(543,545),(543,546),(543,547),(543,548),(543,549),(543,550),(543,551),(543,552),(543,553),(543,554),(543,555),(543,556),(543,557),(543,558),(543,559),(543,560),(543,561),(562,478),(562,479),(562,480),(562,481),(562,482),(562,483),(562,484),(562,485),(562,486),(562,487),(562,488),(562,495),(562,496),(563,478),(563,479),(563,480),(563,481),(563,482),(563,483),(563,484),(563,485),(563,486),(563,487),(563,488),(563,489),(563,490),(563,491),(563,495),(564,498),(564,499),(564,500),(564,501),(564,502),(564,503),(564,504),(564,505),(564,506),(564,507),(564,508),(564,515),(564,516),(565,498),(565,499),(565,500),(565,501),(565,502),(565,503),(565,504),(565,505),(565,506),(565,507),(565,508),(565,509),(565,510),(565,511),(565,515),(565,541),(566,522),(566,523),(566,524),(566,525),(566,526),(566,527),(566,528),(566,529),(566,530),(566,531),(566,532),(566,537),(566,538),(567,522),(567,523),(567,524),(567,525),(567,526),(567,527),(567,528),(567,529),(567,530),(567,531),(567,532),(567,533),(567,534),(567,537),(567,539),(568,544),(568,545),(568,546),(568,547),(568,548),(568,549),(568,550),(568,551),(568,552),(568,553),(568,558),(568,559),(569,544),(569,545),(569,546),(569,547),(569,548),(569,549),(569,550),(569,551),(569,552),(569,553),(569,554),(569,555),(569,558),(569,560),(572,232),(572,233),(572,236),(572,237),(572,238),(572,239),(572,240),(572,241),(572,242),(572,243),(572,248),(573,232),(573,233),(573,234),(573,236),(573,237),(573,238),(573,239),(573,240),(573,241),(573,242),(573,243),(573,244),(573,245),(573,570),(584,144),(584,145),(584,146),(584,147),(584,148),(584,149),(584,150),(584,151),(584,152),(584,157),(584,158),(584,574),(584,575),(584,576),(584,577),(584,578),(585,142),(585,144),(585,145),(585,146),(585,147),(585,148),(585,149),(585,150),(585,151),(585,152),(585,153),(585,154),(585,157),(585,574),(585,575),(585,576),(585,577),(585,578),(585,579),(585,581),(585,583),(588,124),(588,126),(588,127),(588,128),(588,129),(588,130),(588,131),(588,132),(588,133),(588,134),(588,135),(588,136),(588,139),(588,586),(589,126),(589,127),(589,128),(589,129),(589,130),(589,131),(589,132),(589,133),(589,134),(589,139),(589,140),(592,593),(596,597),(596,598),(596,599),(600,601),(602,603),(604,605),(606,607),(610,611),(613,614),(613,615),(613,616),(613,617),(613,618),(613,619),(613,620),(613,621),(613,622),(613,623),(613,624),(613,625),(613,626),(613,627),(613,628),(613,629),(613,630),(613,631),(613,632),(633,614),(633,615),(633,616),(633,617),(633,618),(633,619),(633,620),(633,621),(633,622),(633,623),(633,624),(633,625),(633,626),(633,627),(633,629),(633,630),(633,632),(634,614),(634,615),(634,616),(634,617),(634,618),(634,619),(634,620),(634,621),(634,622),(634,623),(634,624),(634,625),(634,626),(634,627),(634,628),(634,629),(634,630),(637,638),(639,62),(639,63),(639,64),(639,278),(639,399),(640,62),(640,63),(640,65),(640,278),(640,399),(640,643),(641,642),(646,647),(648,649),(648,650),(648,651),(648,652),(648,653),(648,654),(648,655),(648,656),(648,657),(648,658),(648,659),(648,660),(648,661),(648,662),(648,663),(648,664),(648,665),(648,666),(648,667),(668,649),(668,650),(668,651),(668,652),(668,653),(668,654),(668,655),(668,656),(668,657),(668,658),(668,659),(668,660),(668,661),(668,662),(668,664),(668,665),(668,667),(669,649),(669,650),(669,651),(669,652),(669,653),(669,654),(669,655),(669,656),(669,657),(669,658),(669,659),(669,660),(669,661),(669,662),(669,663),(669,664),(669,665),(670,67),(670,75),(670,77),(670,459),(671,672),(674,675),(676,677),(678,679),(678,680),(678,681),(678,682),(678,683),(678,684),(678,685),(678,730),(678,734),(678,735),(678,754),(678,755),(678,756),(678,771),(678,772),(678,1068),(678,1069),(678,1070),(678,1071),(678,1072),(678,1073),(686,687),(686,688),(686,689),(686,690),(686,691),(686,692),(686,693),(686,694),(686,695),(686,696),(686,697),(686,698),(686,699),(686,700),(686,701),(686,702),(686,703),(686,704),(686,705),(706,707),(706,708),(706,709),(706,710),(706,711),(706,712),(706,713),(706,714),(706,715),(706,716),(706,717),(706,718),(706,719),(706,720),(706,721),(706,722),(706,723),(706,724),(706,725),(726,707),(726,708),(726,709),(726,710),(726,711),(726,712),(726,713),(726,714),(726,715),(726,716),(726,717),(726,718),(726,725),(727,707),(727,708),(727,709),(727,710),(727,711),(727,714),(727,719),(727,720),(727,721),(728,687),(728,688),(728,689),(728,690),(728,691),(728,692),(728,693),(728,694),(728,695),(728,696),(728,697),(728,698),(728,705),(729,687),(729,688),(729,689),(729,690),(729,691),(729,694),(729,699),(729,700),(729,701),(731,67),(731,310),(731,732),(731,733),(736,737),(738,739),(740,741),(742,743),(744,745),(746,747),(748,749),(750,751),(752,753),(757,758),(759,760),(761,762),(763,764),(765,766),(767,768),(769,770),(773,774),(773,775),(773,776),(773,777),(778,780),(778,781),(779,780),(779,781),(782,783),(782,1038),(784,785),(784,789),(786,787),(786,788),(790,791),(792,793),(795,796),(797,798),(799,800),(803,804),(806,807),(808,809),(808,810),(811,812),(813,814),(815,816),(817,818),(819,820),(825,826),(827,828),(827,829),(827,830),(827,831),(827,832),(827,833),(827,834),(827,835),(827,836),(827,837),(827,838),(827,839),(827,840),(827,841),(827,842),(827,843),(827,844),(827,845),(827,846),(827,5553),(847,828),(847,830),(847,831),(847,832),(847,833),(847,834),(847,835),(847,836),(847,837),(847,838),(847,846),(847,848),(848,828),(848,829),(848,835),(848,839),(848,840),(848,841),(848,842),(857,858),(857,869),(873,874),(873,875),(873,876),(873,877),(873,878),(873,879),(937,938),(939,940),(941,942),(943,944),(945,946),(947,948),(947,959),(949,950),(949,951),(949,952),(949,953),(949,954),(949,955),(949,956),(949,957),(949,958),(963,964),(963,965),(963,966),(963,967),(963,968),(963,969),(970,971),(972,973),(972,974),(972,975),(972,976),(972,977),(972,978),(972,979),(972,980),(972,981),(972,984),(982,983),(1006,856),(1007,1008),(1009,1010),(1017,1018),(1017,1019),(1020,1021),(1020,1022),(1023,50),(1024,52),(1025,54),(1026,361),(1027,39),(1028,41),(1029,1030),(1031,1032),(1031,1033),(1031,1034),(1031,1064),(1031,1065),(1031,1066),(1031,1067),(1031,1080),(1031,1081),(1031,1082),(1031,1083),(1031,1084),(1031,1085),(1031,1086),(1031,1087),(1031,1088),(1036,1036),(1039,1040),(1041,1042),(1043,1044),(1043,1045),(1043,1046),(1043,1047),(1043,1048),(1043,1049),(1043,1050),(1043,1051),(1043,1052),(1043,1053),(1043,1054),(1043,1055),(1043,1056),(1043,1057),(1043,1058),(1043,1059),(1043,1060),(1043,1061),(1062,1044),(1062,1045),(1062,1046),(1062,1047),(1062,1048),(1062,1049),(1062,1050),(1062,1051),(1062,1052),(1062,1055),(1062,1056),(1062,1057),(1062,1058),(1062,1059),(1063,1044),(1063,1045),(1063,1046),(1063,1047),(1063,1048),(1063,1049),(1063,1050),(1063,1051),(1063,1052),(1063,1053),(1063,1055),(1063,1056),(1063,1057),(1063,1058),(1063,1059),(1063,1060),(1074,1075),(1074,1076),(1078,679),(1078,680),(1078,681),(1078,682),(1078,683),(1078,684),(1078,685),(1078,730),(1078,734),(1078,735),(1078,754),(1078,755),(1078,756),(1078,771),(1078,772),(1078,1068),(1078,1069),(1078,1070),(1078,1071),(1078,1072),(1078,1073),(1089,59),(1090,56),(1091,770),(1091,1092),(1093,1094),(1093,1095),(1093,1096),(1093,1097),(1093,1098),(1093,1103),(1099,1100),(1101,1102),(1101,1104),(1105,1106),(1107,1108),(1150,1151),(1152,1153),(1198,1199);
/*!40000 ALTER TABLE `sys_res_relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_resources`
--

DROP TABLE IF EXISTS `sys_resources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_resources` (
  `RES_ID` int(6) NOT NULL COMMENT '资源id，如果表中无记录，id=1，否则id=max(id) + 1',
  `RES_NAME` varchar(64) NOT NULL COMMENT '资源名称',
  `RES_DESC` varchar(256) DEFAULT NULL COMMENT '资源描述',
  `RES_URL` varchar(1024) DEFAULT NULL COMMENT '资源链接',
  `RES_PID` int(6) NOT NULL DEFAULT '0' COMMENT '父资源id，没有为0',
  `RES_TYPE` int(2) NOT NULL COMMENT '资源类型，0=菜单，1=系统资源\n            2=sree资源, 3=后台资源',
  `RES_ORDER_NO` int(3) NOT NULL COMMENT '同级排序编号',
  `RES_UPDATE_TIME` datetime DEFAULT NULL COMMENT '更新时间',
  `RES_VISIT_TIME` datetime DEFAULT NULL COMMENT '访问时间',
  PRIMARY KEY (`RES_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_resources`
--

LOCK TABLES `sys_resources` WRITE;
/*!40000 ALTER TABLE `sys_resources` DISABLE KEYS */;
INSERT INTO `sys_resources` VALUES (1,'menu.name.1','menu.desc.1',NULL,0,0,1,'2011-05-30 00:00:00',NULL),(2,'menu.name.2','menu.desc.2','showUserAdd.do',1,1,1,'2011-05-30 00:00:00',NULL),(3,'menu.name.3','menu.desc.3','addUser.do',2,2,2,'2011-05-30 00:00:00',NULL),(4,'menu.name.4','menu.desc.4','showUserManage.do',1,1,0,'2011-05-30 00:00:00',NULL),(5,'menu.name.5','menu.desc.5','showUser2Role.do',1,2,2,'2011-05-30 00:00:00',NULL),(6,'menu.name.6','menu.desc.6','modifyRoleResource.do',5,2,5,'2011-05-30 00:00:00',NULL),(7,'menu.name.7','menu.desc.7',NULL,0,0,2,'2011-05-30 00:00:00',NULL),(8,'menu.name.8','menu.desc.8','showRoleAdd.do',7,1,3,'2011-05-30 00:00:00',NULL),(9,'menu.name.9','menu.desc.9','addRole.do',8,2,4,'2011-05-30 00:00:00',NULL),(10,'menu.name.10','menu.desc.10','showRoleManage.do',7,1,5,'2011-05-30 00:00:00',NULL),(11,'menu.name.11','menu.desc.11','showRole2Resource.do',7,2,6,'2011-05-30 00:00:00',NULL),(12,'menu.name.12','menu.desc.12','modifyRoleResource.do',11,2,7,'2011-05-30 00:00:00',NULL),(13,'menu.name.13','menu.desc.13',NULL,0,0,0,'2011-05-30 00:00:00',NULL),(14,'menu.name.14','menu.desc.14','showResourceAdd.do',13,1,1,'2011-05-30 00:00:00',NULL),(15,'menu.name.15','menu.desc.15','addResource.do',14,2,2,'2011-05-30 00:00:00',NULL),(16,'menu.name.16','menu.desc.16','showResource2Game.do',13,1,1,'2011-05-30 00:00:00',NULL),(17,'menu.name.17','menu.desc.17','resource2Game.do',16,2,3,'2011-05-30 00:00:00',NULL),(18,'menu.name.18','menu.desc.18','showResourceManage.do',13,1,4,'2011-05-30 00:00:00',NULL),(19,'menu.name.19','menu.desc.19','showResourceModify.do',13,2,4,'2011-05-30 00:00:00',NULL),(20,'menu.name.20','menu.desc.20','showResourceTree.do',13,2,5,'2011-05-30 00:00:00',NULL),(21,'menu.name.21','menu.desc.21','modifyResource.do',19,2,6,'2011-05-30 00:00:00',NULL),(22,'menu.name.22','menu.desc.22',NULL,0,0,4,'2011-05-30 00:00:00',NULL),(23,'menu.name.23','menu.desc.23','showQueryPlayerInfo.do',22,1,0,'2011-05-30 00:00:00',NULL),(24,'menu.name.24','menu.desc.24','showUserModify.do',1,2,3,'2011-05-30 00:00:00',NULL),(25,'menu.name.25','menu.desc.25','modifyUser.do',24,2,7,'2011-05-30 00:00:00',NULL),(26,'menu.name.26','menu.desc.26','delUser.do',1,2,4,'2011-05-30 00:00:00',NULL),(27,'menu.name.27','menu.desc.27','showRoleModify.do',7,2,8,'2011-05-30 00:00:00',NULL),(28,'menu.name.28','menu.desc.28','modifyRole.do',27,2,9,'2011-05-30 00:00:00',NULL),(29,'menu.name.29','menu.desc.29','delRole.do',7,2,10,'2011-05-30 00:00:00',NULL),(30,'menu.name.30','menu.desc.30','showMultiRoleAddResource.do',7,2,11,'2011-05-30 00:00:00',NULL),(31,'menu.name.31','menu.desc.31','multiRoleAddResource.do',30,2,12,'2011-05-30 00:00:00',NULL),(32,'menu.name.32','menu.desc.32','showResourceSort.do',13,1,7,'2011-05-30 00:00:00',NULL),(33,'menu.name.33','menu.desc.33','sortResource.do',32,2,8,'2011-05-30 00:00:00',NULL),(34,'menu.name.34','menu.desc.34',NULL,0,0,3,'2011-05-30 00:00:00',NULL),(35,'menu.name.35','menu.desc.35','logManage.do?method=showLog',34,1,1,'2011-05-30 00:00:00',NULL),(36,'menu.name.36','menu.desc.36','showValidatePlayerInfo.do',22,1,2,'2011-05-30 00:00:00',NULL),(37,'menu.name.37','menu.desc.37','validatePlayerInfo.do',36,2,3,'2011-05-30 00:00:00',NULL),(38,'menu.name.38','menu.desc.38','showPlayerItems.do',22,1,4,'2011-05-30 00:00:00',NULL),(39,'menu.name.39','menu.desc.39','getPlayerItems.do',38,2,5,'2011-05-30 00:00:00',NULL),(40,'menu.name.40','menu.desc.40','showLogPlayerItems.do',22,1,6,'2011-05-30 00:00:00',NULL),(41,'menu.name.41','menu.desc.41','getLogPlayerItems.do',40,2,7,'2011-05-30 00:00:00',NULL),(42,'menu.name.42','menu.desc.42','modifyItemName.do',22,2,24,'2011-05-30 00:00:00',NULL),(43,'menu.name.43','menu.desc.43','showQueryPlayerLoginOutDetail.do',22,1,8,'2011-05-30 00:00:00',NULL),(44,'menu.name.44','menu.desc.44','getPlayerLoginOutDetail.do',43,2,9,'2011-05-30 00:00:00',NULL),(45,'menu.name.45','menu.desc.45','showQueryRoleInfo.do',22,1,10,'2011-05-30 00:00:00',NULL),(46,'menu.name.46','menu.desc.46','getRoleDetailInfo.do',45,2,11,'2011-05-30 00:00:00',NULL),(47,'menu.name.47','menu.desc.47','showQueryPlayerPurchaseDetail.do',22,1,12,'2011-05-30 00:00:00',NULL),(48,'menu.name.48','menu.desc.48','getPlayerPurchaseDetail.do',47,2,13,'2011-05-30 00:00:00',NULL),(49,'menu.name.49','menu.desc.49','showQueryPlayerChargeDetail.do',22,1,14,'2011-05-30 00:00:00',NULL),(50,'menu.name.50','menu.desc.50','getPlayerChargeDetail.do',49,2,15,'2011-05-30 00:00:00',NULL),(51,'menu.name.51','menu.desc.51','showQueryPlayerAccountDetail.do',22,1,16,'2011-05-30 00:00:00',NULL),(52,'menu.name.52','menu.desc.52','getPlayerAccountDetail.do',51,2,17,'2011-05-30 00:00:00',NULL),(53,'menu.name.53','menu.desc.53','showQueryOrderStatus.do',22,1,18,'2011-05-30 00:00:00',NULL),(54,'menu.name.54','menu.desc.54','getOrderStatus.do',53,2,19,'2011-05-30 00:00:00',NULL),(55,'menu.name.55','menu.desc.55','showSearchRole.do',22,1,20,'2011-05-30 00:00:00',NULL),(56,'menu.name.56','menu.desc.56','searchRole.do',55,2,21,'2011-05-30 00:00:00',NULL),(57,'menu.name.57','menu.desc.57','showPlayerNames2Ids.do',22,1,22,'2011-05-30 00:00:00',NULL),(58,'menu.name.58','menu.desc.58','playerNames2Ids.do',57,2,23,'2011-05-30 00:00:00',NULL),(59,'menu.name.59','menu.desc.59','getPlayerInfo.do',23,2,1,'2011-05-30 00:00:00',NULL),(60,'menu.name.60','menu.desc.60',NULL,0,0,5,'2011-05-30 00:00:00',NULL),(61,'menu.name.61','menu.desc.61','showQueryFreezePlayer.do',60,1,0,'2011-05-30 00:00:00',NULL),(62,'menu.name.62','menu.desc.62','getFreezePlayerInfo.do',61,2,1,'2011-05-30 00:00:00',NULL),(63,'menu.name.63','menu.desc.63','showFreezePlayer.do',60,2,2,'2011-05-30 00:00:00',NULL),(64,'menu.name.64','menu.desc.64','freezePlayer.do',61,2,3,'2011-05-30 00:00:00',NULL),(65,'menu.name.65','menu.desc.65','unFreezePlayer.do',60,2,4,'2011-05-30 00:00:00',NULL),(66,'menu.name.66','menu.desc.66','showQueryKickRole.do',60,1,1,'2011-05-30 00:00:00',NULL),(67,'menu.name.67','menu.desc.67','getRole2Oper.do',60,2,6,'2011-05-30 00:00:00',NULL),(68,'menu.name.68','menu.desc.68','showKickRole.do',60,2,7,'2011-05-30 00:00:00',NULL),(69,'menu.name.69','menu.desc.69','kickRole.do',66,2,8,'2011-05-30 00:00:00',NULL),(70,'menu.name.70','menu.desc.70','unKickRole.do',60,2,9,'2011-05-30 00:00:00',NULL),(71,'menu.name.71','menu.desc.71','showQueryMoveRole.do',60,1,3,'2011-05-30 00:00:00',NULL),(72,'menu.name.72','menu.desc.72','showMoveRole.do',60,2,11,'2011-05-30 00:00:00',NULL),(73,'menu.name.73','menu.desc.73','moveRole.do',71,2,12,'2011-05-30 00:00:00',NULL),(74,'menu.name.74','menu.desc.74','showQueryShutUpRole.do',60,1,4,'2011-05-30 00:00:00',NULL),(75,'menu.name.75','menu.desc.75','showShutUpRole.do',60,2,14,'2011-05-30 00:00:00',NULL),(76,'menu.name.76','menu.desc.76','shutUpRole.do',74,2,15,'2011-05-30 00:00:00',NULL),(77,'menu.name.77','menu.desc.77','unShutUpRole.do',60,2,16,'2011-05-30 00:00:00',NULL),(78,'menu.name.78','menu.desc.78','showModifyBindEmail.do',60,1,5,'2011-05-30 00:00:00',NULL),(79,'menu.name.79','menu.desc.79','showFirstApprModifyBindEmail.do',60,2,18,'2011-05-30 00:00:00',NULL),(80,'menu.name.80','menu.desc.80','showSecondApprModifyBindEmail.do',60,2,19,'2011-05-30 00:00:00',NULL),(81,'menu.name.81','menu.desc.81','showAppredModifyBindEmail.do',60,2,20,'2011-05-30 00:00:00',NULL),(82,'menu.name.82','menu.desc.82','showExedModifyBindEmail.do',60,2,21,'2011-05-30 00:00:00',NULL),(83,'menu.name.83','menu.desc.83','showDeledModifyBindEmail.do',60,2,22,'2011-05-30 00:00:00',NULL),(84,'menu.name.84','menu.desc.84','showCreateModifyBindEmail.do',60,2,23,'2011-05-30 00:00:00',NULL),(85,'menu.name.85','menu.desc.85','operModifyBindEmail.do',60,2,24,'2011-05-30 00:00:00',NULL),(86,'menu.name.86','menu.desc.86','showEditModifyBindEmail.do',60,2,25,'2011-05-30 00:00:00',NULL),(87,'menu.name.87','menu.desc.87','submitModifyBindEmail.do',60,2,26,'2011-05-30 00:00:00',NULL),(88,'menu.name.88','menu.desc.88','delModifyBindEmail.do',60,2,27,'2011-05-30 00:00:00',NULL),(89,'menu.name.89','menu.desc.89','cancelModifyBindEmail.do',60,2,28,'2011-05-30 00:00:00',NULL),(90,'menu.name.90','menu.desc.90','show2FirstApprModifyBindEmail.do',60,2,29,'2011-05-30 00:00:00',NULL),(91,'menu.name.91','menu.desc.91','firstApprModifyBindEmail.do',60,2,30,'2011-05-30 00:00:00',NULL),(92,'menu.name.92','menu.desc.92','show2SecondApprModifyBindEmail.do',60,2,31,'2011-05-30 00:00:00',NULL),(93,'menu.name.93','menu.desc.93','secondApprModifyBindEmail.do',60,2,32,'2011-05-30 00:00:00',NULL),(94,'menu.name.94','menu.desc.94','exeModifyBindEmail.do',60,2,33,'2011-05-30 00:00:00',NULL),(95,'menu.name.95','menu.desc.95','showQueryTrusteePlayer.do',60,1,8,'2011-05-30 00:00:00',NULL),(96,'menu.name.96','menu.desc.96','getTrusteePlayerInfo.do',60,2,35,'2011-05-30 00:00:00',NULL),(97,'menu.name.97','menu.desc.97','showTrusteePlayer.do',60,2,36,'2011-05-30 00:00:00',NULL),(98,'menu.name.98','menu.desc.98','trusteePlayer.do',60,2,37,'2011-05-30 00:00:00',NULL),(99,'menu.name.99','menu.desc.99','unTrusteePlayer.do',60,2,38,'2011-05-30 00:00:00',NULL),(100,'menu.name.100','menu.desc.100','showQueryEndTask.do',60,1,9,'2011-05-30 00:00:00',NULL),(101,'menu.name.101','menu.desc.101','showEndTask.do',60,2,40,'2011-05-30 00:00:00',NULL),(102,'menu.name.102','menu.desc.102','endTask.do',60,2,41,'2011-05-30 00:00:00',NULL),(103,'menu.name.103','menu.desc.103',NULL,0,0,6,'2011-05-30 00:00:00',NULL),(104,'menu.name.104','menu.desc.104','showAwardCompensate.do',103,1,0,'2011-05-30 00:00:00',NULL),(105,'menu.name.105','menu.desc.105','showFirstApprAwardCompensate.do',103,2,1,'2011-05-30 00:00:00',NULL),(106,'menu.name.106','menu.desc.106','showSecondApprAwardCompensate.do',103,2,1,'2011-05-30 00:00:00',NULL),(107,'menu.name.107','menu.desc.107','showAppredAwardCompensate.do',103,2,1,'2011-05-30 00:00:00',NULL),(108,'menu.name.108','menu.desc.108','showExedAwardCompensate.do',103,2,1,'2011-05-30 00:00:00',NULL),(109,'menu.name.109','menu.desc.109','showDeledAwardCompensate.do',103,2,1,'2011-05-30 00:00:00',NULL),(110,'menu.name.110','menu.desc.110','showCreateAwardCompensate.do',103,2,1,'2011-05-30 00:00:00',NULL),(111,'menu.name.111','menu.desc.111','validateCreate.do',103,2,1,'2011-05-30 00:00:00',NULL),(112,'menu.name.112','menu.desc.112','saveAwardCompensate.do',103,2,1,'2011-05-30 00:00:00',NULL),(113,'menu.name.113','menu.desc.113','operAwardCompensate.do',103,2,1,'2011-05-30 00:00:00',NULL),(114,'menu.name.114','menu.desc.114','showEditAwardCompensate.do',103,2,1,'2011-05-30 00:00:00',NULL),(115,'menu.name.115','menu.desc.115','submitAwardCompensate.do',103,2,1,'2011-05-30 00:00:00',NULL),(116,'menu.name.116','menu.desc.116','delAwardCompensate.do',103,2,1,'2011-05-30 00:00:00',NULL),(117,'menu.name.117','menu.desc.117','cancelAwardCompensate.do',103,2,1,'2011-05-30 00:00:00',NULL),(118,'menu.name.118','menu.desc.118','show2FirstApprAwardCompensate.do',103,2,1,'2011-05-30 00:00:00',NULL),(119,'menu.name.119','menu.desc.119','firstApprAwardCompensate.do',103,2,1,'2011-05-30 00:00:00',NULL),(120,'menu.name.120','menu.desc.120','show2SecondApprAwardCompensate.do',103,2,1,'2011-05-30 00:00:00',NULL),(121,'menu.name.121','menu.desc.121','secondApprAwardCompensate.do',103,2,1,'2011-05-30 00:00:00',NULL),(122,'menu.name.122','menu.desc.122','exeAwardCompensate.do',103,2,1,'2011-05-30 00:00:00',NULL),(123,'menu.name.123','menu.desc.123','showPointCompensate.do?changeType=1',103,1,3,'2011-05-30 00:00:00',NULL),(124,'menu.name.124','menu.desc.124','showFirstApprPointCompensate.do?changeType=1',103,2,1,'2011-05-30 00:00:00',NULL),(125,'menu.name.125','menu.desc.125','showSecondApprPointCompensate.do?changeType=1',103,2,1,'2011-05-30 00:00:00',NULL),(126,'menu.name.126','menu.desc.126','showAppredPointCompensate.do?changeType=1',103,2,1,'2011-05-30 00:00:00',NULL),(127,'menu.name.127','menu.desc.127','showExedPointCompensate.do?changeType=1',103,2,1,'2011-05-30 00:00:00',NULL),(128,'menu.name.128','menu.desc.128','showDeledPointCompensate.do?changeType=1',103,2,1,'2011-05-30 00:00:00',NULL),(129,'menu.name.129','menu.desc.129','showCreatePointCompensate.do?changeType=1',103,2,1,'2011-05-30 00:00:00',NULL),(130,'menu.name.130','menu.desc.130','savePointCompensate.do?changeType=1',103,2,1,'2011-05-30 00:00:00',NULL),(131,'menu.name.131','menu.desc.131','operPointCompensate.do?changeType=1',103,2,1,'2011-05-30 00:00:00',NULL),(132,'menu.name.132','menu.desc.132','showEditPointCompensate.do?changeType=1',103,2,1,'2011-05-30 00:00:00',NULL),(133,'menu.name.133','menu.desc.133','cancelPointCompensate.do?changeType=1',103,2,1,'2011-05-30 00:00:00',NULL),(134,'menu.name.134','menu.desc.134','delPointCompensate.do?changeType=1',103,2,1,'2011-05-30 00:00:00',NULL),(135,'menu.name.135','menu.desc.135','show2FirstApprPointCompensate.do?changeType=1',103,2,1,'2011-05-30 00:00:00',NULL),(136,'menu.name.136','menu.desc.136','firstApprPointCompensate.do?changeType=1',103,2,1,'2011-05-30 00:00:00',NULL),(137,'menu.name.137','menu.desc.137','show2SecondApprPointCompensate.do?changeType=1',103,2,1,'2011-05-30 00:00:00',NULL),(138,'menu.name.138','menu.desc.138','secondApprPointCompensate.do?changeType=1',103,2,1,'2011-05-30 00:00:00',NULL),(139,'menu.name.139','menu.desc.139','submitPointCompensate.do?changeType=1',103,2,1,'2011-05-30 00:00:00',NULL),(140,'menu.name.140','menu.desc.140','exePointCompensate.do?changeType=1',103,2,1,'2011-05-30 00:00:00',NULL),(141,'menu.name.141','menu.desc.141','showPointCompensate.do?changeType=2',103,1,4,'2011-05-30 00:00:00',NULL),(142,'menu.name.142','menu.desc.142','showFirstApprPointCompensate.do?changeType=2',103,2,1,'2011-05-30 00:00:00',NULL),(143,'menu.name.143','menu.desc.143','showSecondApprPointCompensate.do?changeType=2',103,2,1,'2011-05-30 00:00:00',NULL),(144,'menu.name.144','menu.desc.144','showAppredPointCompensate.do?changeType=2',103,2,1,'2011-05-30 00:00:00',NULL),(145,'menu.name.145','menu.desc.145','showExedPointCompensate.do?changeType=2',103,2,1,'2011-05-30 00:00:00',NULL),(146,'menu.name.146','menu.desc.146','showDeledPointCompensate.do?changeType=2',103,2,1,'2011-05-30 00:00:00',NULL),(147,'menu.name.147','menu.desc.147','showCreatePointCompensate.do?changeType=2',103,2,1,'2011-05-30 00:00:00',NULL),(148,'menu.name.148','menu.desc.148','savePointCompensate.do?changeType=2',103,2,1,'2011-05-30 00:00:00',NULL),(149,'menu.name.149','menu.desc.149','operPointCompensate.do?changeType=2',103,2,1,'2011-05-30 00:00:00',NULL),(150,'menu.name.150','menu.desc.150','showEditPointCompensate.do?changeType=2',103,2,1,'2011-05-30 00:00:00',NULL),(151,'menu.name.151','menu.desc.151','cancelPointCompensate.do?changeType=2',103,2,1,'2011-05-30 00:00:00',NULL),(152,'menu.name.152','menu.desc.152','delPointCompensate.do?changeType=2',103,2,1,'2011-05-30 00:00:00',NULL),(153,'menu.name.153','menu.desc.153','show2FirstApprPointCompensate.do?changeType=2',103,2,1,'2011-05-30 00:00:00',NULL),(154,'menu.name.154','menu.desc.154','firstApprPointCompensate.do?changeType=2',103,2,1,'2011-05-30 00:00:00',NULL),(155,'menu.name.155','menu.desc.155','show2SecondApprPointCompensate.do?changeType=2',103,2,1,'2011-05-30 00:00:00',NULL),(156,'menu.name.156','menu.desc.156','secondApprPointCompensate.do?changeType=2',103,2,1,'2011-05-30 00:00:00',NULL),(157,'menu.name.157','menu.desc.157','submitPointCompensate.do?changeType=2',103,2,1,'2011-05-30 00:00:00',NULL),(158,'menu.name.158','menu.desc.158','exePointCompensate.do?changeType=2',103,2,1,'2011-05-30 00:00:00',NULL),(159,'menu.name.159','menu.desc.159',NULL,0,0,7,'2011-05-30 00:00:00',NULL),(160,'menu.name.160','menu.desc.160','showIssueBulletin.do',159,1,1,'2011-05-30 00:00:00',NULL),(161,'menu.name.161','menu.desc.161','showHistoryBulletin.do',159,2,1,'2011-05-30 00:00:00',NULL),(162,'menu.name.162','menu.desc.162','showAddBulletin.do',159,2,1,'2011-05-30 00:00:00',NULL),(163,'menu.name.163','menu.desc.163','addBulletin.do',162,2,1,'2011-05-30 00:00:00',NULL),(164,'menu.name.164','menu.desc.164','operBulletin.do',159,2,1,'2011-05-30 00:00:00',NULL),(165,'menu.name.165','menu.desc.165','cancelBulletin.do',159,2,1,'2011-05-30 00:00:00',NULL),(166,'menu.name.166','menu.desc.166','showIssueSettingExp.do',159,1,1,'2011-05-30 00:00:00',NULL),(167,'menu.name.167','menu.desc.167','showHistorySettingExp.do',159,2,1,'2011-05-30 00:00:00',NULL),(168,'menu.name.168','menu.desc.168','showAddSettingExp.do',159,2,1,'2011-05-30 00:00:00',NULL),(169,'menu.name.169','menu.desc.169','addSettingExp.do',168,2,1,'2011-05-30 00:00:00',NULL),(170,'menu.name.170','menu.desc.170','stopSettingExp.do',159,2,1,'2011-05-30 00:00:00',NULL),(171,'menu.name.171','menu.desc.171','showIssueActivity.do',159,1,1,'2011-05-30 00:00:00',NULL),(172,'menu.name.172','menu.desc.172','showHistoryActivity.do',159,2,1,'2011-05-30 00:00:00',NULL),(173,'menu.name.173','menu.desc.173','showActivityDetail.do',159,2,1,'2011-05-30 00:00:00',NULL),(174,'menu.name.174','menu.desc.174','delActivity.do',159,2,1,'2011-05-30 00:00:00',NULL),(175,'menu.name.175','menu.desc.175','showAddActivity.do',159,2,1,'2011-05-30 00:00:00',NULL),(176,'menu.name.176','menu.desc.176','addActivity.do',175,2,1,'2011-05-30 00:00:00',NULL),(177,'menu.name.177','menu.desc.177','showModifyActivity.do',159,2,1,'2011-05-30 00:00:00',NULL),(178,'menu.name.178','menu.desc.178','modifyActivity.do',177,2,1,'2011-05-30 00:00:00',NULL),(179,'menu.name.179','menu.desc.179','showAddActivityPoint.do',159,2,1,'2011-05-30 00:00:00',NULL),(180,'menu.name.180','menu.desc.180','validateActivityPoint.do',159,2,1,'2011-05-30 00:00:00',NULL),(181,'menu.name.181','menu.desc.181','addActivityPoint.do',179,2,1,'2011-05-30 00:00:00',NULL),(182,'menu.name.182','menu.desc.182','showAddActivityPackage.do',159,2,1,'2011-05-30 00:00:00',NULL),(183,'menu.name.183','menu.desc.183','validateActivityPackage.do',159,2,1,'2011-05-30 00:00:00',NULL),(184,'menu.name.184','menu.desc.184','addActivityPackage.do',182,2,1,'2011-05-30 00:00:00',NULL),(185,'menu.name.185','menu.desc.185','showActivityPackageDetail.do',159,2,1,'2011-05-30 00:00:00',NULL),(186,'menu.name.186','menu.desc.186','validateActivityPackageItem.do',159,2,1,'2011-05-30 00:00:00',NULL),(187,'menu.name.187','menu.desc.187','addActivityPackageItem.do',159,2,1,'2011-05-30 00:00:00',NULL),(188,'menu.name.188','menu.desc.188',NULL,0,0,8,'2011-05-30 00:00:00',NULL),(189,'menu.name.189','menu.desc.189','showLeagueInfo.do',188,1,0,'2011-05-30 00:00:00',NULL),(190,'menu.name.190','menu.desc.190','showChannelInfo.do',188,1,1,'2011-05-30 00:00:00',NULL),(191,'menu.name.191','menu.desc.191','showOccupationInfo.do',188,1,2,'2011-05-30 00:00:00',NULL),(192,'menu.name.192','menu.desc.192','showSceneInfo.do',188,1,3,'2011-05-30 00:00:00',NULL),(193,'menu.name.193','menu.desc.193','showExperienceType.do',188,1,4,'2011-05-30 00:00:00',NULL),(194,'menu.name.194','menu.desc.194','showAddLeague.do',188,2,5,'2011-05-30 00:00:00',NULL),(195,'menu.name.195','menu.desc.195','showAddChannel.do',188,2,6,'2011-05-30 00:00:00',NULL),(196,'menu.name.196','menu.desc.196','showAddOccupation.do',188,2,7,'2011-05-30 00:00:00',NULL),(197,'menu.name.197','menu.desc.197','showAddScene.do',188,2,8,'2011-05-30 00:00:00',NULL),(198,'menu.name.198','menu.desc.198','showAddExperienceType.do',188,2,9,'2011-05-30 00:00:00',NULL),(199,'menu.name.199','menu.desc.199','addLeague.do',194,2,1,'2011-05-30 00:00:00',NULL),(200,'menu.name.200','menu.desc.200','addChannel.do',195,2,1,'2011-05-30 00:00:00',NULL),(201,'menu.name.201','menu.desc.201','addScene.do',197,2,1,'2011-05-30 00:00:00',NULL),(202,'menu.name.202','menu.desc.202','addOccupation.do',196,2,1,'2011-05-30 00:00:00',NULL),(203,'menu.name.203','menu.desc.203','addExperienceType.do',198,2,10,'2011-05-30 00:00:00',NULL),(204,'menu.name.204','menu.desc.204','modifyLeague.do',188,2,11,'2011-05-30 00:00:00',NULL),(205,'menu.name.205','menu.desc.205','modifyOccupation.do',188,2,12,'2011-05-30 00:00:00',NULL),(206,'menu.name.206','menu.desc.206','modifyScene.do',188,2,13,'2011-05-30 00:00:00',NULL),(207,'menu.name.207','menu.desc.207','modifyChannel.do',188,2,14,'2011-05-30 00:00:00',NULL),(208,'menu.name.208','menu.desc.208','modifyExperienceType.do',188,2,15,'2011-05-30 00:00:00',NULL),(209,'menu.name.209','menu.desc.209','delLeague.do',188,2,16,'2011-05-30 00:00:00',NULL),(210,'menu.name.210','menu.desc.210','delScene.do',188,2,17,'2011-05-30 00:00:00',NULL),(211,'menu.name.211','menu.desc.211','delOccupation.do',188,2,18,'2011-05-30 00:00:00',NULL),(212,'menu.name.212','menu.desc.212','delExperienceType.do',188,2,19,'2011-05-30 00:00:00',NULL),(213,'menu.name.213','menu.desc.213','delChannel.do',188,2,20,'2011-05-30 00:00:00',NULL),(214,'menu.name.214','menu.desc.214','showGateway.do',188,1,21,'2011-05-30 00:00:00',NULL),(215,'menu.name.215','menu.desc.215','showAddGateway.do',188,2,22,'2011-05-30 00:00:00',NULL),(216,'menu.name.216','menu.desc.216','addGateway.do',215,2,23,'2011-05-30 00:00:00',NULL),(217,'menu.name.217','menu.desc.217','showModifyGateway.do',188,2,24,'2011-05-30 00:00:00',NULL),(218,'menu.name.218','menu.desc.218','modifyGateway.do',217,2,25,'2011-05-30 00:00:00',NULL),(219,'menu.name.219','menu.desc.219','delGateway.do',188,2,26,'2011-05-30 00:00:00',NULL),(220,'menu.name.220','menu.desc.220','showGameServer.do',188,1,27,'2011-05-30 00:00:00',NULL),(221,'menu.name.221','menu.desc.221','showAddGameServer.do',188,2,28,'2011-05-30 00:00:00',NULL),(222,'menu.name.222','menu.desc.222','addGameServer.do',221,2,29,'2011-05-30 00:00:00',NULL),(223,'menu.name.223','menu.desc.223','showModifyGameServer.do',188,2,30,'2011-05-30 00:00:00',NULL),(224,'menu.name.224','menu.desc.224','modifyGameServer.do',223,2,31,'2011-05-30 00:00:00',NULL),(225,'menu.name.225','menu.desc.225','delGameServer.do',188,2,32,'2011-05-30 00:00:00',NULL),(226,'menu.name.226','menu.desc.226','showGame.do',13,1,33,'2011-05-30 00:00:00',NULL),(227,'menu.name.227','menu.desc.227','showAddGame.do',188,2,34,'2011-05-30 00:00:00',NULL),(228,'menu.name.228','menu.desc.228','addGame.do',227,2,1,'2011-05-30 00:00:00',NULL),(229,'menu.name.229','menu.desc.229','modifyGame.do',188,2,35,'2011-05-30 00:00:00',NULL),(230,'menu.name.230','menu.desc.230','delGame.do',188,2,36,'2011-05-30 00:00:00',NULL),(231,'menu.name.231','menu.desc.231','showPetCompensate.do',103,1,5,'2011-05-30 00:00:00',NULL),(232,'menu.name.232','menu.desc.232','showCreatePetCompensate.do',103,2,3,'2011-05-30 00:00:00',NULL),(233,'menu.name.233','menu.desc.233','savePetCompensate.do',103,2,4,'2011-05-30 00:00:00',NULL),(234,'menu.name.234','menu.desc.234','showFirstApprPetCompensate.do',103,2,1,'2011-05-30 00:00:00',NULL),(235,'menu.name.235','menu.desc.235','showSecondApprPetCompensate.do',103,2,1,'2011-05-30 00:00:00',NULL),(236,'menu.name.236','menu.desc.236','showAppredPetCompensate.do',103,2,1,'2011-05-30 00:00:00',NULL),(237,'menu.name.237','menu.desc.237','showExedPetCompensate.do',103,2,1,'2011-05-30 00:00:00',NULL),(238,'menu.name.238','menu.desc.238','showDeledPetCompensate.do',103,2,1,'2011-05-30 00:00:00',NULL),(239,'menu.name.239','menu.desc.239','operPetCompensate.do',103,2,1,'2011-05-30 00:00:00',NULL),(240,'menu.name.240','menu.desc.240','showEditPetCompensate.do',103,2,1,'2011-05-30 00:00:00',NULL),(241,'menu.name.241','menu.desc.241','submitPetCompensate.do',103,2,1,'2011-05-30 00:00:00',NULL),(242,'menu.name.242','menu.desc.242','delPetCompensate.do',103,2,1,'2011-05-30 00:00:00',NULL),(243,'menu.name.243','menu.desc.243','cancelPetCompensate.do',103,2,1,'2011-05-30 00:00:00',NULL),(244,'menu.name.244','menu.desc.244','show2FirstApprPetCompensate.do',103,2,1,'2011-05-30 00:00:00',NULL),(245,'menu.name.245','menu.desc.245','firstApprPetCompensate.do',103,2,1,'2011-05-30 00:00:00',NULL),(246,'menu.name.246','menu.desc.246','show2SecondApprPetCompensate.do',103,2,1,'2011-05-30 00:00:00',NULL),(247,'menu.name.247','menu.desc.247','secondApprPetCompensate.do',103,2,1,'2011-05-30 00:00:00',NULL),(248,'menu.name.248','menu.desc.248','exePetCompensate.do',103,2,1,'2011-05-30 00:00:00',NULL),(249,'menu.name.249','menu.desc.249','saveModifyBindEmail.do',60,2,42,'2011-05-30 00:00:00',NULL),(251,'menu.name.251','menu.desc.251','delResource.do',13,2,8,'2011-05-30 00:00:00',NULL),(252,'menu.name.252','menu.desc.252','operSettingExp.do',159,2,2,'2011-05-30 00:00:00',NULL),(253,'menu.name.253','menu.desc.253','showFreezePlayers.do',60,1,10,'2011-05-30 00:00:00',NULL),(254,'menu.name.254','menu.desc.254','validateFreezePlayers.do',253,2,44,'2011-05-30 00:00:00',NULL),(255,'menu.name.255','menu.desc.255','freezePlayers.do',253,2,1,'2011-05-30 00:00:00',NULL),(256,'menu.name.256','menu.desc.256','validateRestorePlayers.do',60,2,45,'2011-05-30 00:00:00',NULL),(257,'menu.name.257','menu.desc.257','unFreezePlayers.do',258,2,46,'2011-05-30 00:00:00',NULL),(258,'menu.name.258','menu.desc.258','showUnFreezePlayers.do',60,1,11,'2011-05-30 00:00:00',NULL),(259,'menu.name.259','menu.desc.259','showTrusteePlayers.do',60,1,12,'2011-05-30 00:00:00',NULL),(260,'menu.name.260','menu.desc.260','trusteePlayers.do',259,2,1,'2011-05-30 00:00:00',NULL),(261,'menu.name.261','menu.desc.261','validateTrusteePlayers.do',259,2,2,'2011-05-30 00:00:00',NULL),(262,'menu.name.262','menu.desc.262','showUnTrusteePlayers.do',60,1,13,'2011-05-30 00:00:00',NULL),(263,'menu.name.263','menu.desc.263','unTrusteePlayers.do',262,2,1,'2011-05-30 00:00:00',NULL),(264,'menu.name.264','menu.desc.264','showQueryEndPlayerFightState.do',60,1,14,'2011-05-30 00:00:00',NULL),(265,'menu.name.265','menu.desc.265','showEndPlayerFightState.do',264,2,1,'2011-05-30 00:00:00',NULL),(266,'menu.name.266','menu.desc.266','endPlayerFightState.do',264,2,2,'2011-05-30 00:00:00',NULL),(267,'menu.name.267','menu.desc.267','showQueryNpc.do',22,1,25,'2011-05-30 00:00:00',NULL),(268,'menu.name.268','menu.desc.268','queryNpc.do',267,2,1,'2011-05-30 00:00:00',NULL),(269,'menu.name.269','menu.desc.269','showQueryRoleStoreGood.do',22,1,26,'2011-05-30 00:00:00',NULL),(270,'menu.name.270','menu.desc.270','getRoleStoreGood.do',269,2,1,'2011-05-30 00:00:00',NULL),(271,'menu.name.271','menu.desc.271','showQueryRoleLocation.do',22,1,27,'2011-05-30 00:00:00',NULL),(272,'menu.name.272','menu.desc.272','getRoleLocation.do',271,2,1,'2011-05-30 00:00:00',NULL),(274,'menu.name.274','menu.desc.274','showResourceRelation.do',13,1,3,'2011-05-30 00:00:00',NULL),(275,'menu.name.275','menu.desc.275','resourceRelation.do',274,2,1,'2011-05-30 00:00:00',NULL),(276,'menu.name.276','menu.desc.276','showQueryVipCard.do',22,2,28,'2011-05-30 00:00:00',NULL),(277,'menu.name.277','menu.desc.277','queryVipCard.do',276,2,1,'2011-05-30 00:00:00',NULL),(278,'menu.name.278','menu.desc.278','getFreezePlayerDetail.do',61,2,51,'2011-05-30 00:00:00',NULL),(279,'menu.name.279','menu.desc.279','getTrusteePlayerDetail.do',95,2,1,'2011-05-30 00:00:00',NULL),(280,'menu.name.280','menu.desc.280','showProduct.do',159,1,3,'2011-05-30 00:00:00',NULL),(281,'menu.name.281','menu.desc.281','showAddProduct.do',159,2,4,'2011-05-30 00:00:00',NULL),(282,'menu.name.282','menu.desc.282','addProduct.do',159,2,5,'2011-05-30 00:00:00',NULL),(283,'menu.name.283','menu.desc.283','showStartProduct.do',159,2,6,'2011-05-30 00:00:00',NULL),(284,'menu.name.284','menu.desc.284','startProduct.do',159,2,7,'2011-05-30 00:00:00',NULL),(285,'menu.name.285','menu.desc.285','showEndProduct.do',159,2,8,'2011-05-30 00:00:00',NULL),(286,'menu.name.286','menu.desc.286','endProduct.do',159,2,9,'2011-05-30 00:00:00',NULL),(287,'menu.name.287','menu.desc.287','showAwardCompensate.do',103,1,2,'2011-05-30 00:00:00',NULL),(288,'menu.name.288','menu.desc.288','showTrusteeIp.do',188,1,37,'2011-05-30 00:00:00',NULL),(289,'menu.name.289','menu.desc.289','showAddTrusteeIp.do',288,2,1,'2011-05-30 00:00:00',NULL),(290,'menu.name.290','menu.desc.290','showModifyTrusteeIp.do',288,2,2,'2011-05-30 00:00:00',NULL),(291,'menu.name.291','menu.desc.291','delTrusteeIp.do',288,2,3,'2011-05-30 00:00:00',NULL),(292,'menu.name.292','menu.desc.292','addTrusteeIp.do',288,2,4,'2011-05-30 00:00:00',NULL),(293,'menu.name.293','menu.desc.293','modifyTrusteeIp.do',288,2,5,'2011-05-30 00:00:00',NULL),(294,'menu.name.294','menu.desc.294','showQueryKickRole2.do',60,1,2,'2011-05-30 00:00:00',NULL),(295,'menu.name.295','menu.desc.295','showKickRole2.do',294,2,1,'2011-05-30 00:00:00',NULL),(296,'menu.name.296','menu.desc.296','kickRole2.do',294,2,2,'2011-05-30 00:00:00',NULL),(297,'menu.name.297','menu.desc.297','showQueryDelRole.do',60,1,15,'2011-05-30 00:00:00',NULL),(298,'menu.name.298','menu.desc.298','showDelRole.do',297,2,1,'2011-05-30 00:00:00',NULL),(299,'menu.name.299','menu.desc.299','delRole.do',297,2,2,'2011-05-30 00:00:00',NULL),(300,'menu.name.300','menu.desc.300','showQueryResumeRole.do',60,1,16,'2011-05-30 00:00:00',NULL),(301,'menu.name.301','menu.desc.301','showResumeRole.do',300,2,1,'2011-05-30 00:00:00',NULL),(302,'menu.name.302','menu.desc.302','resumeRole.do',300,2,2,'2011-05-30 00:00:00',NULL),(303,'menu.name.303','menu.desc.303','showModifyBindEmail.do',60,1,6,'2011-05-30 00:00:00',NULL),(304,'menu.name.304','menu.desc.304','showAwardCompensate.do',103,1,1,'2011-05-30 00:00:00',NULL),(305,'menu.name.305','menu.desc.305','showModifyBindEmail.do',60,1,7,'2011-05-30 00:00:00',NULL),(306,'menu.name.306','menu.desc.306','showQueryRoleSocial.do',22,1,29,'2011-05-30 00:00:00',NULL),(307,'menu.name.307','menu.desc.307','queryRoleSocial.do',306,2,1,'2011-05-30 00:00:00',NULL),(308,'menu.name.308','menu.desc.308','showQueryRoleTopN.do',22,1,30,'2011-05-30 00:00:00',NULL),(309,'menu.name.309','menu.desc.309','queryRoleTopN.do',308,2,1,'2011-05-30 00:00:00',NULL),(310,'menu.name.310','menu.desc.310','operOfflineRole.do',60,2,46,'2011-05-30 00:00:00',NULL),(311,'menu.name.311','menu.desc.311','showActivityCode.do',159,1,10,'2011-05-30 00:00:00',NULL),(312,'menu.name.312','menu.desc.312','showActivityCodeGenerate.do',311,2,1,'2011-05-30 00:00:00',NULL),(313,'menu.name.313','menu.desc.313','generateActivityCode.do',311,2,2,'2011-05-30 00:00:00',NULL),(314,'menu.name.314','menu.desc.314','downloadCodeFile.do',311,2,3,'2011-05-30 00:00:00',NULL),(315,'menu.name.315','menu.desc.315','showChargingGiveItem.do',159,1,11,'2011-05-30 00:00:00',NULL),(316,'menu.name.316','menu.desc.316','showChargingGiveItemDetail.do',315,2,1,'2011-05-30 00:00:00',NULL),(317,'menu.name.317','menu.desc.317','showAddChargingGiveItem.do',315,2,2,'2011-05-30 00:00:00',NULL),(318,'menu.name.318','menu.desc.318','addChargingGiveItem.do',315,2,3,'2011-05-30 00:00:00',NULL),(319,'menu.name.319','menu.desc.319','delChargingGiveItem.do',315,2,4,'2011-05-30 00:00:00',NULL),(320,'menu.name.320','menu.desc.320','showModifyChargingGiveItem.do',315,2,5,'2011-05-30 00:00:00',NULL),(321,'menu.name.321','menu.desc.321','modifyChargingGiveItem.do',315,2,6,'2011-05-30 00:00:00',NULL),(322,'menu.name.322','menu.desc.322','showGoldCompensate.do',103,1,6,'2011-05-30 00:00:00',NULL),(323,'menu.name.323','menu.desc.323','showFirstApprGoldCompensate.do',322,2,1,'2011-05-30 00:00:00',NULL),(324,'menu.name.324','menu.desc.324','showSecondApprGoldCompensate.do',322,2,2,'2011-05-30 00:00:00',NULL),(325,'menu.name.325','menu.desc.325','showAppredGoldCompensate.do',322,2,3,'2011-05-30 00:00:00',NULL),(326,'menu.name.326','menu.desc.326','showExedGoldCompensate.do',322,2,4,'2011-05-30 00:00:00',NULL),(327,'menu.name.327','menu.desc.327','showDeledGoldCompensate.do',322,2,5,'2011-05-30 00:00:00',NULL),(328,'menu.name.328','menu.desc.328','showCreateGoldCompensate.do',322,2,6,'2011-05-30 00:00:00',NULL),(329,'menu.name.329','menu.desc.329','validateGoldCompensate.do',322,2,7,'2011-05-30 00:00:00',NULL),(331,'menu.name.331','menu.desc.331','saveGoldCompensate.do',322,2,9,'2011-05-30 00:00:00',NULL),(332,'menu.name.332','menu.desc.332','operGoldCompensate.do',322,2,10,'2011-05-30 00:00:00',NULL),(333,'menu.name.333','menu.desc.333','showEditGoldCompensate.do',322,2,11,'2011-05-30 00:00:00',NULL),(334,'menu.name.334','menu.desc.334','show2FirstApprGoldCompensate.do',322,2,12,'2011-05-30 00:00:00',NULL),(335,'menu.name.335','menu.desc.335','submitGoldCompensate.do',322,2,13,'2011-05-30 00:00:00',NULL),(336,'menu.name.336','menu.desc.336','delGoldCompensate.do',322,2,14,'2011-05-30 00:00:00',NULL),(337,'menu.name.337','menu.desc.337','cancelGoldCompensate.do',322,2,15,'2011-05-30 00:00:00',NULL),(338,'menu.name.338','menu.desc.338','firstApprGoldCompensate.do',322,2,16,'2011-05-30 00:00:00',NULL),(339,'menu.name.339','menu.desc.339','show2SecondApprGoldCompensate.do',322,2,17,'2011-05-30 00:00:00',NULL),(340,'menu.name.340','menu.desc.340','secondApprGoldCompensate.do',322,2,18,'2011-05-30 00:00:00',NULL),(341,'menu.name.341','menu.desc.341','exeGoldCompensate.do',322,2,19,'2011-05-30 00:00:00',NULL),(342,'menu.name.342','menu.desc.342','showGoldCompensate.do',103,1,7,'2011-05-30 00:00:00',NULL),(343,'menu.name.343','menu.desc.343','showGoldCompensate.do',103,1,8,'2011-05-30 00:00:00',NULL),(344,'menu.name.344','menu.desc.344','showOnlineGm.do',159,1,12,'2011-05-30 00:00:00',NULL),(345,'menu.name.345','menu.desc.345','showOnlineGmAdd.do',344,2,1,'2011-05-30 00:00:00',NULL),(346,'menu.name.346','menu.desc.346','addOnlineGm.do',344,2,2,'2011-05-30 00:00:00',NULL),(347,'menu.name.347','menu.desc.347','showOnlineGmModify.do',344,2,3,'2011-05-30 00:00:00',NULL),(348,'menu.name.348','menu.desc.348','delOnlineGm.do',344,2,4,'2011-05-30 00:00:00',NULL),(349,'menu.name.349','menu.desc.349','modifyOnlineGm.do',344,2,5,'2011-05-30 00:00:00',NULL),(350,'menu.name.350','menu.desc.350','showModifyOnlineGmIp.do',344,2,6,'2011-05-30 00:00:00',NULL),(351,'menu.name.351','menu.desc.351','modifyOnlineGmIp.do',344,2,7,'2011-05-30 00:00:00',NULL),(352,'menu.name.352','menu.desc.352','batchFirstApprGoldCompensate.do',322,2,20,'2011-05-30 00:00:00',NULL),(353,'menu.name.353','menu.desc.353','batchSecondApprGoldCompensate.do',322,2,21,'2011-05-30 00:00:00',NULL),(354,'menu.name.354','menu.desc.354','batchFirstApprModifyBindEmail.do',78,2,1,'2011-05-30 00:00:00',NULL),(355,'menu.name.355','menu.desc.355','batchSecondApprModifyBindEmail.do',78,2,2,'2011-05-30 00:00:00',NULL),(356,'menu.name.356','menu.desc.356','batchFirstApprAwardCompensate.do',104,2,1,'2011-05-30 00:00:00',NULL),(357,'menu.name.357','menu.desc.357','batchSecondApprAwardCompensate.do',104,2,2,'2011-05-30 00:00:00',NULL),(358,'menu.name.358','menu.desc.358','showModifyOrderStatus.do',159,1,13,'2011-05-30 00:00:00',NULL),(359,'menu.name.359','menu.desc.359','modifyOrderStatus.do',358,2,1,'2011-05-30 00:00:00',NULL),(360,'menu.name.360','menu.desc.360','showQueryOrderDetail.do',22,1,31,'2011-05-30 00:00:00',NULL),(361,'menu.name.361','menu.desc.361','getOrderDetail.do',360,2,1,'2011-05-30 00:00:00',NULL),(362,'menu.name.362','menu.desc.362','showPassportGateway.do',159,1,14,'2011-05-30 00:00:00',NULL),(363,'menu.name.363','menu.desc.363','showAddPassportGateway.do',362,2,1,'2011-05-30 00:00:00',NULL),(364,'menu.name.364','menu.desc.364','showModifyPassportGateway.do',362,2,2,'2011-05-30 00:00:00',NULL),(365,'menu.name.365','menu.desc.365','opPassportGateway.do',362,2,3,'2011-05-30 00:00:00',NULL),(366,'menu.name.366','menu.desc.366','showSetIbLocation.do',159,1,15,'2011-05-30 00:00:00',NULL),(367,'menu.name.367','menu.desc.367','setIbLocation.do',366,2,1,'2011-05-30 00:00:00',NULL),(368,'menu.name.368','menu.desc.368','showTransfer.do',60,1,47,'2011-05-30 00:00:00',NULL),(369,'menu.name.369','menu.desc.369','submitTransfer.do',368,2,1,'2011-05-30 00:00:00',NULL),(370,'menu.name.370','menu.desc.370','showAppredTransfer.do',368,2,2,'2011-05-30 00:00:00',NULL),(371,'menu.name.371','menu.desc.371','showExedTransfer.do',368,2,3,'2011-05-30 00:00:00',NULL),(372,'menu.name.372','menu.desc.372','showDeledTransfer.do',368,2,4,'2011-05-30 00:00:00',NULL),(373,'menu.name.373','menu.desc.373','showCreateTransfer.do',368,2,5,'2011-05-30 00:00:00',NULL),(374,'menu.name.374','menu.desc.374','operTransfer.do',368,2,6,'2011-05-30 00:00:00',NULL),(375,'menu.name.375','menu.desc.375','showEditTransfer.do',368,2,7,'2011-05-30 00:00:00',NULL),(376,'menu.name.376','menu.desc.376','delTransfer.do',368,2,8,'2011-05-30 00:00:00',NULL),(377,'menu.name.377','menu.desc.377','cancelTransfer.do',368,2,9,'2011-05-30 00:00:00',NULL),(378,'menu.name.378','menu.desc.378','showFirstApprTransfer.do',368,2,10,'2011-05-30 00:00:00',NULL),(379,'menu.name.379','menu.desc.379','showSecondApprTransfer.do',368,2,11,'2011-05-30 00:00:00',NULL),(380,'menu.name.380','menu.desc.380','exeTransfer.do',368,2,12,'2011-05-30 00:00:00',NULL),(381,'menu.name.381','menu.desc.381','saveTransfer.do',368,2,13,'2011-05-30 00:00:00',NULL),(382,'menu.name.382','menu.desc.382','getTransferState.do',368,2,14,'2011-05-30 00:00:00',NULL),(383,'menu.name.383','menu.desc.383','show2FirstApprTransfer.do',368,2,15,'2011-05-30 00:00:00',NULL),(384,'menu.name.384','menu.desc.384','batchFirstApprTransfer.do',368,2,16,'2011-05-30 00:00:00',NULL),(385,'menu.name.385','menu.desc.385','firstApprTransfer.do',368,2,17,'2011-05-30 00:00:00',NULL),(386,'menu.name.386','menu.desc.386','show2SecondApprTransfer.do',368,2,18,'2011-05-30 00:00:00',NULL),(387,'menu.name.387','menu.desc.387','batchSecondApprTransfer.do',368,2,19,'2011-05-30 00:00:00',NULL),(388,'menu.name.388','menu.desc.388','secondApprTransfer.do',368,2,20,'2011-05-30 00:00:00',NULL),(389,'menu.name.389','menu.desc.389','showTransfer.do',60,1,48,'2011-05-30 00:00:00',NULL),(390,'menu.name.390','menu.desc.390','showTransfer.do',60,1,49,'2011-05-30 00:00:00',NULL),(391,'menu.name.391','menu.desc.391','showQueryRolePackage.do',22,1,32,'2011-05-30 00:00:00',NULL),(392,'menu.name.392','menu.desc.392','getRolePackage.do',391,2,1,'2011-05-30 00:00:00',NULL),(399,'menu.name.399','menu.desc.399','getHistoryInfo.do',60,2,50,'2011-05-30 00:00:00',NULL),(400,'menu.name.400','menu.desc.400','showClosePassCard.do',60,1,51,'2011-05-30 00:00:00',NULL),(401,'menu.name.401','menu.desc.401','showCreateModifyBindEmail.do',400,2,1,'2011-05-30 00:00:00',NULL),(402,'menu.name.402','menu.desc.402','showFirstApprClosePassCard.do',400,2,2,'2011-05-30 00:00:00',NULL),(403,'menu.name.403','menu.desc.403','showSecondApprClosePassCard.do',400,2,3,'2011-05-30 00:00:00',NULL),(404,'menu.name.404','menu.desc.404','showAppredClosePassCard.do',400,2,4,'2011-05-30 00:00:00',NULL),(405,'menu.name.405','menu.desc.405','showExedClosePassCard.do',400,2,5,'2011-05-30 00:00:00',NULL),(406,'menu.name.406','menu.desc.406','showDeledClosePassCar.do',400,2,6,'2011-05-30 00:00:00',NULL),(407,'menu.name.407','menu.desc.407','showDeledClosePassCard.do',400,2,7,'2011-05-30 00:00:00',NULL),(408,'menu.name.408','menu.desc.408','showCreateClosePassCard.do',400,2,8,'2011-05-30 00:00:00',NULL),(409,'menu.name.409','menu.desc.409','operClosePassCard.do',400,2,9,'2011-05-30 00:00:00',NULL),(410,'menu.name.410','menu.desc.410','showEditClosePassCard.do',400,2,10,'2011-05-30 00:00:00',NULL),(411,'menu.name.411','menu.desc.411','submitClosePassCard.do',400,2,11,'2011-05-30 00:00:00',NULL),(412,'menu.name.412','menu.desc.412','delClosePassCard.do',400,2,12,'2011-05-30 00:00:00',NULL),(413,'menu.name.413','menu.desc.413','cancelClosePassCard.do',400,2,13,'2011-05-30 00:00:00',NULL),(414,'menu.name.414','menu.desc.414','exeClosePassCard.do',400,2,14,'2011-05-30 00:00:00',NULL),(415,'menu.name.415','menu.desc.415','saveClosePassCard.do',400,2,15,'2011-05-30 00:00:00',NULL),(416,'menu.name.416','menu.desc.416','show2FirstApprClosePassCard.do',400,2,16,'2011-05-30 00:00:00',NULL),(417,'menu.name.417','menu.desc.417','firstApprClosePassCard.do',400,2,17,'2011-05-30 00:00:00',NULL),(418,'menu.name.418','menu.desc.418','batchFirstApprClosePassCard.do',400,2,18,'2011-05-30 00:00:00',NULL),(419,'menu.name.419','menu.desc.419','show2SecondApprClosePassCard.do',400,2,19,'2011-05-30 00:00:00',NULL),(420,'menu.name.420','menu.desc.420','secondApprClosePassCard.do',400,2,20,'2011-05-30 00:00:00',NULL),(421,'menu.name.421','menu.desc.421','batchSecondApprClosePassCard.do',400,2,21,'2011-05-30 00:00:00',NULL),(422,'menu.name.422','menu.desc.422','showClosePassCard.do',60,1,52,'2011-05-30 00:00:00',NULL),(423,'menu.name.423','menu.desc.423','showClosePassCard.do',60,1,53,'2011-05-30 00:00:00',NULL),(433,'menu.name.433','menu.desc.433','showUserItemOnBody.do',22,1,33,'2011-05-30 00:00:00',NULL),(434,'menu.name.434','menu.desc.434','userItemOnBody.do',433,2,1,'2011-05-30 00:00:00',NULL),(435,'menu.name.435','menu.desc.435','getRoleItemInfo.do',391,2,2,'2011-05-30 00:00:00',NULL),(436,'menu.name.436','menu.desc.436','showSynchronizationProduct.do',280,2,1,'2011-05-30 00:00:00',NULL),(437,'menu.name.437','menu.desc.437','synchronizationProduct.do',280,2,2,'2011-05-30 00:00:00',NULL),(438,'menu.name.438','menu.desc.438','showUserLevelInfo.do',22,1,34,'2011-05-30 00:00:00',NULL),(439,'menu.name.439','menu.desc.439','userLevelInfo.do',438,2,1,'2011-05-30 00:00:00',NULL),(440,'menu.name.440','menu.desc.440','showActivityInfo.do',159,1,17,'2011-05-30 00:00:00',NULL),(441,'menu.name.441','menu.desc.441','showActivityInfo.do',159,1,18,'2011-05-30 00:00:00',NULL),(442,'menu.name.442','menu.desc.442','showActivityInfo.do',159,1,19,'2011-05-30 00:00:00',NULL),(443,'menu.name.443','menu.desc.443','showActivityInfo.do',159,1,20,'2011-05-30 00:00:00',NULL),(444,'menu.name.444','menu.desc.444','showOpActivityInfo.do?opFlag=plan',159,2,1,'2011-05-30 00:00:00',NULL),(445,'menu.name.445','menu.desc.445','planActivityInfo.do',159,2,2,'2011-05-30 00:00:00',NULL),(446,'menu.name.446','menu.desc.446','opActivityInfoServer.do?opType=tmpStart',159,2,21,'2011-05-30 00:00:00',NULL),(447,'menu.name.447','menu.desc.447','opActivityInfoServer.do?opType=tmpStop',159,2,22,'2011-05-30 00:00:00',NULL),(448,'menu.name.448','menu.desc.448','showOpActivityInfo.do?opFlag=add',159,2,23,'2011-05-30 00:00:00',NULL),(449,'menu.name.449','menu.desc.449','addActivityInfo.do',159,2,24,'2011-05-30 00:00:00',NULL),(450,'menu.name.450','menu.desc.450','showOpActivityInfo.do?opFlag=synchronization',159,2,25,'2011-05-30 00:00:00',NULL),(451,'menu.name.451','menu.desc.451','synchronizationActivityInfo.do',159,2,26,'2011-05-30 00:00:00',NULL),(452,'menu.name.452','menu.desc.452','delActivityInfo.do',159,2,27,'2011-05-30 00:00:00',NULL),(453,'menu.name.453','menu.desc.453','opActivityInfoServer.do?opType=del',159,2,28,'2011-05-30 00:00:00',NULL),(454,'menu.name.454','menu.desc.454','opActivityInfoServer.do?opType=start',159,2,29,'2011-05-30 00:00:00',NULL),(455,'menu.name.455','menu.desc.455','opActivityInfoServer.do?opType=stop',159,2,30,'2011-05-30 00:00:00',NULL),(456,'menu.name.456','menu.desc.456','showUserSkillInfo.do',22,1,35,'2011-05-30 00:00:00',NULL),(457,'menu.name.457','menu.desc.457','userSkillInfo.do',456,2,1,'2011-05-30 00:00:00',NULL),(458,'menu.name.458','menu.desc.458','userSkillDetail.do',456,2,2,'2011-05-30 00:00:00',NULL),(459,'menu.name.459','menu.desc.459','showUnShutUpRole.do',74,2,16,'2011-05-30 00:00:00',NULL),(460,'menu.name.460','menu.desc.460','showProductPrice.do',280,2,3,'2011-05-30 00:00:00',NULL),(461,'menu.name.461','menu.desc.461','showAddProductPrice.do',280,2,4,'2011-05-30 00:00:00',NULL),(462,'menu.name.462','menu.desc.462','addProductPrice.do',280,2,9,'2011-05-30 00:00:00',NULL),(463,'menu.name.463','menu.desc.463','showSendProductPrice.do',280,2,5,'2011-05-30 00:00:00',NULL),(464,'menu.name.464','menu.desc.464','sendProductPrice.do',280,2,6,'2011-05-30 00:00:00',NULL),(465,'menu.name.465','menu.desc.465','queryActivitySetting.do',159,1,31,'2011-05-30 00:00:00',NULL),(466,'menu.name.466','menu.desc.466','showOperActivitySetting.do',465,2,1,'2011-05-30 00:00:00',NULL),(467,'menu.name.467','menu.desc.467','operActivitySetting.do',465,2,2,'2011-05-30 00:00:00',NULL),(468,'menu.name.468','menu.desc.468','showSetActivitySetting.do',465,2,3,'2011-05-30 00:00:00',NULL),(469,'menu.name.469','menu.desc.469','setActivitySetting.do',465,2,4,'2011-05-30 00:00:00',NULL),(470,'menu.name.470','menu.desc.470','showSetIbMark.do',159,1,32,'2011-05-30 00:00:00',NULL),(471,'menu.name.471','menu.desc.471','setIbMark.do',470,2,1,'2011-05-30 00:00:00',NULL),(472,'menu.name.472','menu.desc.472','showChargeCompensate.do',60,1,54,'2011-05-30 00:00:00',NULL),(473,'menu.name.473','menu.desc.473','insertChargeCompensate.do',472,2,1,'2011-05-30 00:00:00',NULL),(474,'menu.name.474','menu.desc.474','delChargeCompensate.do',472,2,2,'2011-05-30 00:00:00',NULL),(475,'menu.name.475','menu.desc.475','showRealCardInfo.do',22,1,36,'2011-05-30 00:00:00',NULL),(476,'menu.name.476','menu.desc.476','realCardInfo.do',475,2,1,'2011-05-30 00:00:00',NULL),(477,'menu.name.477','menu.desc.477','showSkillCompensate.do',103,1,9,'2011-05-30 00:00:00',NULL),(478,'menu.name.478','menu.desc.478','showFirstApprSkillCompensate.do',477,2,1,'2011-05-30 00:00:00',NULL),(479,'menu.name.479','menu.desc.479','showSecondApprSkillCompensate.do',477,2,2,'2011-05-30 00:00:00',NULL),(480,'menu.name.480','menu.desc.480','showAppredSkillCompensate.do',477,2,3,'2011-05-30 00:00:00',NULL),(481,'menu.name.481','menu.desc.481','showExedSkillCompensate.do',477,2,4,'2011-05-30 00:00:00',NULL),(482,'menu.name.482','menu.desc.482','showDeledSkillCompensate.do',477,2,5,'2011-05-30 00:00:00',NULL),(483,'menu.name.483','menu.desc.483','showCreateSkillCompensate.do',477,2,6,'2011-05-30 00:00:00',NULL),(484,'menu.name.484','menu.desc.484','saveSkillCompensate.do',477,2,7,'2011-05-30 00:00:00',NULL),(485,'menu.name.485','menu.desc.485','operSkillCompensate.do',477,2,8,'2011-05-30 00:00:00',NULL),(486,'menu.name.486','menu.desc.486','showEditSkillCompensate.do',477,2,9,'2011-05-30 00:00:00',NULL),(487,'menu.name.487','menu.desc.487','cancelSkillCompensate.do',477,2,10,'2011-05-30 00:00:00',NULL),(488,'menu.name.488','menu.desc.488','delSkillCompensate.do',477,2,11,'2011-05-30 00:00:00',NULL),(489,'menu.name.489','menu.desc.489','show2FirstApprSkillCompensate.do',477,2,12,'2011-05-30 00:00:00',NULL),(490,'menu.name.490','menu.desc.490','batchFirstApprSkillCompensate.do',477,2,13,'2011-05-30 00:00:00',NULL),(491,'menu.name.491','menu.desc.491','firstApprSkillCompensate.do',477,2,14,'2011-05-30 00:00:00',NULL),(492,'menu.name.492','menu.desc.492','show2SecondApprSkillCompensate.do',477,2,15,'2011-05-30 00:00:00',NULL),(493,'menu.name.493','menu.desc.493','batchSecondApprSkillCompensate.do',477,2,16,'2011-05-30 00:00:00',NULL),(494,'menu.name.494','menu.desc.494','secondApprSkillCompensate.do',477,2,17,'2011-05-30 00:00:00',NULL),(495,'menu.name.495','menu.desc.495','submitSkillCompensate.do',477,2,18,'2011-05-30 00:00:00',NULL),(496,'menu.name.496','menu.desc.496','exeSkillCompensate.do',477,2,19,'2011-05-30 00:00:00',NULL),(497,'menu.name.497','menu.desc.497','showPointCompensate.do?changeType=6',103,1,10,'2011-05-30 00:00:00',NULL),(498,'menu.name.498','menu.desc.498','showFirstApprPointCompensate.do?changeType=6',497,2,1,'2011-05-30 00:00:00',NULL),(499,'menu.name.499','menu.desc.499','showSecondApprPointCompensate.do?changeType=6',497,2,2,'2011-05-30 00:00:00',NULL),(500,'menu.name.500','menu.desc.500','showAppredPointCompensate.do?changeType=6',497,2,3,'2011-05-30 00:00:00',NULL),(501,'menu.name.501','menu.desc.501','showExedPointCompensate.do?changeType=6',497,2,4,'2011-05-30 00:00:00',NULL),(502,'menu.name.502','menu.desc.502','showDeledPointCompensate.do?changeType=6',497,2,5,'2011-05-30 00:00:00',NULL),(503,'menu.name.503','menu.desc.503','showCreatePointCompensate.do?changeType=6',497,2,6,'2011-05-30 00:00:00',NULL),(504,'menu.name.504','menu.desc.504','savePointCompensate.do',497,2,9,'2011-05-30 00:00:00',NULL),(505,'menu.name.505','menu.desc.505','operPointCompensate.do',497,2,10,'2011-05-30 00:00:00',NULL),(506,'menu.name.506','menu.desc.506','showEditPointCompensate.do',497,2,11,'2011-05-30 00:00:00',NULL),(507,'menu.name.507','menu.desc.507','cancelPointCompensate.do',497,2,12,'2011-05-30 00:00:00',NULL),(509,'menu.name.509','menu.desc.509','show2FirstApprPointCompensate.do',497,2,14,'2011-05-30 00:00:00',NULL),(510,'menu.name.510','menu.desc.510','batchFirstApprPointCompensate.do',497,2,15,'2011-05-30 00:00:00',NULL),(511,'menu.name.511','menu.desc.511','firstApprPointCompensate.do',497,2,16,'2011-05-30 00:00:00',NULL),(512,'menu.name.512','menu.desc.512','show2SecondApprPointCompensate.do',497,2,17,'2011-05-30 00:00:00',NULL),(513,'menu.name.513','menu.desc.513','batchSecondApprPointCompensate.do',497,2,18,'2011-05-30 00:00:00',NULL),(514,'menu.name.514','menu.desc.514','secondApprPointCompensate.do',497,2,19,'2011-05-30 00:00:00',NULL),(515,'menu.name.515','menu.desc.515','submitPointCompensate.do',497,2,20,'2011-05-30 00:00:00',NULL),(516,'menu.name.516','menu.desc.516','exePointCompensate.do',497,2,21,'2011-05-30 00:00:00',NULL),(517,'menu.name.517','menu.desc.517','showCorpsTotal.do',22,1,37,'2011-05-30 00:00:00',NULL),(518,'menu.name.518','menu.desc.518','corpsTotal.do',517,2,1,'2011-05-30 00:00:00',NULL),(519,'menu.name.519','menu.desc.519','corpsDetail.do',517,2,2,'2011-05-30 00:00:00',NULL),(520,'menu.name.520','menu.desc.520','corpsMember.do',517,2,3,'2011-05-30 00:00:00',NULL),(521,'menu.name.521','menu.desc.521','showPointCompensate.do?changeType=4',103,1,11,'2011-05-30 00:00:00',NULL),(522,'menu.name.522','menu.desc.522','showFirstApprPointCompensate.do?changeType=4',521,2,1,'2011-05-30 00:00:00',NULL),(523,'menu.name.523','menu.desc.523','showSecondApprPointCompensate.do?changeType=4',521,2,2,'2011-05-30 00:00:00',NULL),(524,'menu.name.524','menu.desc.524','showAppredPointCompensate.do?changeType=4',521,2,3,'2011-05-30 00:00:00',NULL),(525,'menu.name.525','menu.desc.525','showExedPointCompensate.do?changeType=4',521,2,4,'2011-05-30 00:00:00',NULL),(526,'menu.name.526','menu.desc.526','showDeledPointCompensate.do?changeType=4',521,2,5,'2011-05-30 00:00:00',NULL),(527,'menu.name.527','menu.desc.527','showCreatePointCompensate.do?changeType=4',521,2,6,'2011-05-30 00:00:00',NULL),(528,'menu.name.528','menu.desc.528','savePointCompensate.do?changeType=4',521,2,9,'2011-05-30 00:00:00',NULL),(529,'menu.name.529','menu.desc.529','operPointCompensate.do?changeType=4',521,2,10,'2011-05-30 00:00:00',NULL),(530,'menu.name.530','menu.desc.530','showEditPointCompensate.do?changeType=4',521,2,11,'2011-05-30 00:00:00',NULL),(531,'menu.name.531','menu.desc.531','cancelPointCompensate.do?changeType=4',521,2,12,'2011-05-30 00:00:00',NULL),(532,'menu.name.532','menu.desc.532','delPointCompensate.do?changeType=4',521,2,13,'2011-05-30 00:00:00',NULL),(533,'menu.name.533','menu.desc.533','show4FirstApprPointCompensate.do?changeType=4',521,2,14,'2011-05-30 00:00:00',NULL),(534,'menu.name.534','menu.desc.534','firstApprPointCompensate.do?changeType=4',521,2,15,'2011-05-30 00:00:00',NULL),(535,'menu.name.535','menu.desc.535','show4SecondApprPointCompensate.do?changeType=4',521,2,16,'2011-05-30 00:00:00',NULL),(536,'menu.name.536','menu.desc.536','secondApprPointCompensate.do?changeType=4',521,2,17,'2011-05-30 00:00:00',NULL),(537,'menu.name.537','menu.desc.537','submitPointCompensate.do?changeType=4',521,2,18,'2011-05-30 00:00:00',NULL),(538,'menu.name.538','menu.desc.538','exePointCompensate.do?changeType=4',521,2,19,'2011-05-30 00:00:00',NULL),(539,'menu.name.539','menu.desc.539','batchFirstApprPointCompensate.do?changeType=4',521,2,20,'2011-05-30 00:00:00',NULL),(540,'menu.name.540','menu.desc.540','batchSecondApprPointCompensate.do?changeType=4',521,2,21,'2011-05-30 00:00:00',NULL),(541,'menu.name.541','menu.desc.541','batchFirstApprPointCompensate.do?changeType=6',497,2,22,'2011-05-30 00:00:00',NULL),(542,'menu.name.542','menu.desc.542','batchSecondApprPointCompensate.do?changeType=6',497,2,23,'2011-05-30 00:00:00',NULL),(543,'menu.name.543','menu.desc.543','showPointCompensate.do?changeType=5',103,1,12,'2011-05-30 00:00:00',NULL),(544,'menu.name.544','menu.desc.544','showFirstApprPointCompensate.do?changeType=5',543,2,1,'2011-05-30 00:00:00',NULL),(545,'menu.name.545','menu.desc.545','showAppredPointCompensate.do?changeType=5',543,2,2,'2011-05-30 00:00:00',NULL),(546,'menu.name.546','menu.desc.546','showExedPointCompensate.do?changeType=5',543,2,3,'2011-05-30 00:00:00',NULL),(547,'menu.name.547','menu.desc.547','showDeledPointCompensate.do?changeType=5',543,2,4,'2011-05-30 00:00:00',NULL),(548,'menu.name.548','menu.desc.548','showCreatePointCompensate.do?changeType=5',543,2,5,'2011-05-30 00:00:00',NULL),(549,'menu.name.549','menu.desc.549','savePointCompensate.do?changeType=5',543,2,6,'2011-05-30 00:00:00',NULL),(550,'menu.name.550','menu.desc.550','operPointCompensate.do?changeType=5',543,2,7,'2011-05-30 00:00:00',NULL),(551,'menu.name.551','menu.desc.551','showEditPointCompensate.do?changeType=5',543,2,8,'2011-05-30 00:00:00',NULL),(552,'menu.name.552','menu.desc.552','cancelPointCompensate.do?changeType=5',543,2,9,'2011-05-30 00:00:00',NULL),(553,'menu.name.553','menu.desc.553','delPointCompensate.do?changeType=5',543,2,10,'2011-05-30 00:00:00',NULL),(554,'menu.name.554','menu.desc.554','show5FirstApprPointCompensate.do?changeType=5',543,2,11,'2011-05-30 00:00:00',NULL),(555,'menu.name.555','menu.desc.555','firstApprPointCompensate.do?changeType=5',543,2,12,'2011-05-30 00:00:00',NULL),(556,'menu.name.556','menu.desc.556','showSecondApprPointCompensate.do?changeType=5',543,2,13,'2011-05-30 00:00:00',NULL),(557,'menu.name.557','menu.desc.557','secondApprPointCompensate.do?changeType=5',543,2,14,'2011-05-30 00:00:00',NULL),(558,'menu.name.558','menu.desc.558','submitPointCompensate.do?changeType=5',543,2,15,'2011-05-30 00:00:00',NULL),(559,'menu.name.559','menu.desc.559','exePointCompensate.do?changeType=5',543,2,16,'2011-05-30 00:00:00',NULL),(560,'menu.name.560','menu.desc.560','batchFirstApprPointCompensate.do?changeType=5',543,2,17,'2011-05-30 00:00:00',NULL),(561,'menu.name.561','menu.desc.561','batchSecondApprPointCompensate.do?changeType=5',543,2,18,'2011-05-30 00:00:00',NULL),(562,'menu.name.562','menu.desc.562','showSkillCompensate.do',103,1,13,'2011-05-30 00:00:00',NULL),(563,'menu.name.563','menu.desc.563','showSkillCompensate.do',103,1,14,'2011-05-30 00:00:00',NULL),(564,'menu.name.564','menu.desc.564','showPointCompensate.do?changeType=6',103,1,15,'2011-05-30 00:00:00',NULL),(565,'menu.name.565','menu.desc.565','showPointCompensate.do?changeType=6',103,1,16,'2011-05-30 00:00:00',NULL),(566,'menu.name.566','menu.desc.566','showPointCompensate.do?changeType=4',103,1,17,'2011-05-30 00:00:00',NULL),(567,'menu.name.567','menu.desc.567','showPointCompensate.do?changeType=4',103,1,18,'2011-05-30 00:00:00',NULL),(568,'menu.name.568','menu.desc.568','showPointCompensate.do?changeType=5',103,1,19,'2011-05-30 00:00:00',NULL),(569,'menu.name.569','menu.desc.569','showPointCompensate.do?changeType=5',103,1,20,'2011-05-30 00:00:00',NULL),(570,'menu.name.570','menu.desc.570','batchFirstApprPetCompensate.do',231,2,1,'2011-05-30 00:00:00',NULL),(571,'menu.name.571','menu.desc.571','batchSecondApprPetCompensate.do',231,2,2,'2011-05-30 00:00:00',NULL),(572,'menu.name.572','menu.desc.572','showPetCompensate.do',103,1,21,'2011-05-30 00:00:00',NULL),(573,'menu.name.573','menu.desc.573','showPetCompensate.do',103,1,22,'2011-05-30 00:00:00',NULL),(574,'menu.name.574','menu.desc.574','operPointCompensate.do',141,2,1,'2011-05-30 00:00:00',NULL),(575,'menu.name.575','menu.desc.575','submitPointCompensate.do',141,2,2,'2011-05-30 00:00:00',NULL),(576,'menu.name.576','menu.desc.576','showEditPointCompensate.do',141,2,3,'2011-05-30 00:00:00',NULL),(577,'menu.name.577','menu.desc.577','delPointCompensate.do',141,2,4,'2011-05-30 00:00:00',NULL),(578,'menu.name.578','menu.desc.578','cancelPointCompensate.do',141,2,5,'2011-05-30 00:00:00',NULL),(580,'menu.name.580','menu.desc.580','show2SecondApprPointCompensate.do',141,2,7,'2011-05-30 00:00:00',NULL),(581,'menu.name.581','menu.desc.581','exePointCompensate.do',141,2,8,'2011-05-30 00:00:00',NULL),(583,'menu.name.583','menu.desc.583','batchFirstApprPointCompensate.do?changeType=2',141,2,10,'2011-05-30 00:00:00',NULL),(584,'menu.name.584','menu.desc.584','showPointCompensate.do?changeType=2',103,1,23,'2011-05-30 00:00:00',NULL),(585,'menu.name.585','menu.desc.585','showPointCompensate.do?changeType=2',103,1,11,'2011-05-30 00:00:00',NULL),(586,'menu.name.586','menu.desc.586','batchFirstApprPointCompensate.do?changeType=1',123,2,1,'2011-05-30 00:00:00',NULL),(587,'menu.name.587','menu.desc.587','batchSecondApprPointCompensate.do?changeType=1',123,2,2,'2011-05-30 00:00:00',NULL),(588,'menu.name.588','menu.desc.588','showPointCompensate.do?changeType=1',103,1,24,'2011-05-30 00:00:00',NULL),(589,'menu.name.589','menu.desc.589','showPointCompensate.do?changeType=1',103,1,25,'2011-05-30 00:00:00',NULL),(592,'menu.name.592','menu.desc.592','showSetShopNotice.do',159,1,33,'2011-05-30 00:00:00',NULL),(593,'menu.name.593','menu.desc.593','setShopNotice.do',592,2,1,'2011-05-30 00:00:00',NULL),(594,'menu.name.594','menu.desc.594','showProductSort.do',280,2,10,'2011-05-30 00:00:00',NULL),(595,'menu.name.595','menu.desc.595','sortProduct.do',280,2,11,'2011-05-30 00:00:00',NULL),(596,'menu.name.596','menu.desc.596','showQueryRoleTitle.do',22,1,38,'2011-05-30 00:00:00',NULL),(597,'menu.name.597','menu.desc.597','queryRoleTitle.do',596,2,1,'2011-05-30 00:00:00',NULL),(598,'menu.name.598','menu.desc.598','showChangeRoleTitle.do',596,2,2,'2011-05-30 00:00:00',NULL),(599,'menu.name.599','menu.desc.599','changeRoleTitle.do',596,2,3,'2011-05-30 00:00:00',NULL),(600,'menu.name.600','menu.desc.600','showGoodsHistoryToNPC.do',22,1,39,'2011-05-30 00:00:00',NULL),(601,'menu.name.601','menu.desc.601','GoodsHistoryToNPC.do',600,2,1,'2011-05-30 00:00:00',NULL),(602,'menu.name.602','menu.desc.602','showGoodsHistoryFromNPC.do',22,1,40,'2011-05-30 00:00:00',NULL),(603,'menu.name.603','menu.desc.603','GoodsHistoryFromNPC.do',602,2,1,'2011-05-30 00:00:00',NULL),(604,'menu.name.604','menu.desc.604','showGoodsHistory.do',22,1,41,'2011-05-30 00:00:00',NULL),(605,'menu.name.605','menu.desc.605','goodsHistory.do',604,2,1,'2011-05-30 00:00:00',NULL),(606,'menu.name.606','menu.desc.606','showOperationDetail.do',22,1,42,'2011-05-30 00:00:00',NULL),(607,'menu.name.607','menu.desc.607','OperationDetail.do',606,2,1,'2011-05-30 00:00:00',NULL),(610,'menu.name.610','menu.desc.610','showGoodsHistoryBetweenUsers.do',22,1,44,'2011-05-30 00:00:00',NULL),(611,'menu.name.611','menu.desc.611','goodsHistoryBetweenUsers.do',610,2,1,'2011-05-30 00:00:00',NULL),(612,'menu.name.612','menu.desc.612','modifyUserRole.do',4,2,1,'2011-05-30 00:00:00',NULL),(613,'menu.name.613','menu.desc.613','showPayMoneyAllCompensate.do',103,1,26,'2011-05-30 00:00:00',NULL),(614,'menu.name.614','menu.desc.614','showFirstApprPayMoneyAllCompensate.do',613,2,1,'2011-05-30 00:00:00',NULL),(615,'menu.name.615','menu.desc.615','showSecondApprPayMoneyAllCompensate.do',613,2,2,'2011-05-30 00:00:00',NULL),(616,'menu.name.616','menu.desc.616','showAppredPayMoneyAllCompensate.do',613,2,3,'2011-05-30 00:00:00',NULL),(617,'menu.name.617','menu.desc.617','showExedPayMoneyAllCompensate.do',613,2,4,'2011-05-30 00:00:00',NULL),(618,'menu.name.618','menu.desc.618','showDeledPayMoneyAllCompensate.do',613,2,5,'2011-05-30 00:00:00',NULL),(619,'menu.name.619','menu.desc.619','showCreatePayMoneyAllCompensate.do',613,2,6,'2011-05-30 00:00:00',NULL),(620,'menu.name.620','menu.desc.620','savePayMoneyAllCompensate.do',613,2,7,'2011-05-30 00:00:00',NULL),(621,'menu.name.621','menu.desc.621','operPayMoneyAllCompensate.do',613,2,8,'2011-05-30 00:00:00',NULL),(622,'menu.name.622','menu.desc.622','showEditPayMoneyAllCompensate.do',613,2,9,'2011-05-30 00:00:00',NULL),(623,'menu.name.623','menu.desc.623','submitPayMoneyAllCompensate.do',613,2,10,'2011-05-30 00:00:00',NULL),(624,'menu.name.624','menu.desc.624','delPayMoneyAllCompensate.do',613,2,11,'2011-05-30 00:00:00',NULL),(625,'menu.name.625','menu.desc.625','cancelPayMoneyAllCompensate.do',613,2,12,'2011-05-30 00:00:00',NULL),(626,'menu.name.626','menu.desc.626','show2FirstApprPayMoneyAllCompensate.do',613,2,13,'2011-05-30 00:00:00',NULL),(627,'menu.name.627','menu.desc.627','batchFirstApprPayMoneyAllCompensate.do',613,2,14,'2011-05-30 00:00:00',NULL),(628,'menu.name.628','menu.desc.628','firstApprPayMoneyAllCompensate.do',613,2,15,'2011-05-30 00:00:00',NULL),(629,'menu.name.629','menu.desc.629','show2SecondApprPayMoneyAllCompensate.do',613,2,16,'2011-05-30 00:00:00',NULL),(630,'menu.name.630','menu.desc.630','batchSecondApprPayMoneyAllCompensate.do',613,2,17,'2011-05-30 00:00:00',NULL),(631,'menu.name.631','menu.desc.631','secondApprPayMoneyAllCompensate.do',613,2,18,'2011-05-30 00:00:00',NULL),(632,'menu.name.632','menu.desc.632','exePayMoneyAllCompensate.do',613,2,19,'2011-05-30 00:00:00',NULL),(633,'menu.name.633','menu.desc.633','showPayMoneyAllCompensate.do',103,1,27,'2011-05-30 00:00:00',NULL),(634,'menu.name.634','menu.desc.634','showPayMoneyAllCompensate.do',103,1,28,'2011-05-30 00:00:00',NULL),(635,'menu.name.635','menu.desc.635','userItemOnBodyDetail.do',433,2,2,'2011-05-30 00:00:00',NULL),(636,'menu.name.636','menu.desc.636','userItemInStorage.do',269,2,2,'2011-05-30 00:00:00',NULL),(637,'menu.name.637','menu.desc.637','showOccuptationTotal.do',22,1,45,'2011-05-30 00:00:00',NULL),(638,'menu.name.638','menu.desc.638','occuptationTotal.do',637,2,1,'2011-05-30 00:00:00',NULL),(639,'menu.name.639','menu.desc.639','showQueryFreezePlayer.do',60,1,55,'2011-05-30 00:00:00',NULL),(640,'menu.name.640','menu.desc.640','showQueryFreezePlayer.do',60,1,56,'2011-05-30 00:00:00',NULL),(641,'menu.name.641','menu.desc.641','showQueryCurActivity.do',159,1,34,'2011-05-30 00:00:00',NULL),(642,'menu.name.642','menu.desc.642','queryCurActivity.do',641,2,1,'2011-05-30 00:00:00',NULL),(643,'menu.name.643','menu.desc.643','showUnFreezePlayer.do',61,2,52,'2011-05-30 00:00:00',NULL),(644,'menu.name.644','menu.desc.644','showUnTrusteePlayer.do',95,2,2,'2011-05-30 00:00:00',NULL),(645,'menu.name.645','menu.desc.645','delGMRole.do',10,2,1,'2011-05-30 00:00:00',NULL),(646,'menu.name.646','menu.desc.646','showAddTask.do',60,1,57,'2011-05-30 00:00:00',NULL),(647,'menu.name.647','menu.desc.647','addTask.do',646,2,1,'2011-05-30 00:00:00',NULL),(648,'menu.name.648','menu.desc.648','showAddItemCompensate.do',103,1,29,'2011-05-30 00:00:00',NULL),(649,'menu.name.649','menu.desc.649','showFirstApprAddItemCompensate.do',648,2,1,'2011-05-30 00:00:00',NULL),(650,'menu.name.650','menu.desc.650','showSecondApprAddItemCompensate.do',648,2,2,'2011-05-30 00:00:00',NULL),(651,'menu.name.651','menu.desc.651','showAppredAddItemCompensate.do',648,2,3,'2011-05-30 00:00:00',NULL),(652,'menu.name.652','menu.desc.652','showExedAddItemCompensate.do',648,2,4,'2011-05-30 00:00:00',NULL),(653,'menu.name.653','menu.desc.653','showDeledAddItemCompensate.do',648,2,5,'2011-05-30 00:00:00',NULL),(654,'menu.name.654','menu.desc.654','showCreateAddItemCompensate.do',648,2,6,'2011-05-30 00:00:00',NULL),(655,'menu.name.655','menu.desc.655','saveAddItemCompensate.do',648,2,7,'2011-05-30 00:00:00',NULL),(656,'menu.name.656','menu.desc.656','operAddItemCompensate.do',648,2,8,'2011-05-30 00:00:00',NULL),(657,'menu.name.657','menu.desc.657','showEditAddItemCompensate.do',648,2,9,'2011-05-30 00:00:00',NULL),(658,'menu.name.658','menu.desc.658','submitAddItemCompensate.do',648,2,10,'2011-05-30 00:00:00',NULL),(659,'menu.name.659','menu.desc.659','delAddItemCompensate.do',648,2,11,'2011-05-30 00:00:00',NULL),(660,'menu.name.660','menu.desc.660','cancelAddItemCompensate.do',648,2,12,'2011-05-30 00:00:00',NULL),(661,'menu.name.661','menu.desc.661','show2FirstApprAddItemCompensate.do',648,2,13,'2011-05-30 00:00:00',NULL),(662,'menu.name.662','menu.desc.662','batchFirstApprAddItemCompensate.do',648,2,14,'2011-05-30 00:00:00',NULL),(663,'menu.name.663','menu.desc.663','firstApprAddItemCompensate.do',648,2,15,'2011-05-30 00:00:00',NULL),(664,'menu.name.664','menu.desc.664','show2SecondApprAddItemCompensate.do',648,2,16,'2011-05-30 00:00:00',NULL),(665,'menu.name.665','menu.desc.665','batchSecondApprAddItemCompensate.do',648,2,17,'2011-05-30 00:00:00',NULL),(666,'menu.name.666','menu.desc.666','secondApprAddItemCompensate.do',648,2,18,'2011-05-30 00:00:00',NULL),(667,'menu.name.667','menu.desc.667','exeAddItemCompensate.do',648,2,19,'2011-05-30 00:00:00',NULL),(668,'menu.name.668','menu.desc.668','showAddItemCompensate.do',103,1,30,'2011-05-30 00:00:00',NULL),(669,'menu.name.669','menu.desc.669','showAddItemCompensate.do',103,1,31,'2011-05-30 00:00:00',NULL),(670,'menu.name.670','menu.desc.670','showQueryShutUpRole.do',60,1,58,'2011-05-30 00:00:00',NULL),(671,'menu.name.671','menu.desc.671','showModifyUnionGatewayId.do',159,1,35,'2011-05-30 00:00:00',NULL),(672,'menu.name.672','menu.desc.672','modifyUnionGatewayId.do',671,2,1,'2011-05-30 00:00:00',NULL),(673,'menu.name.673','menu.desc.673','exchangeUser.do',4,2,2,'2011-05-30 00:00:00',NULL),(674,'menu.name.674','menu.desc.674','showSendGoldByLevelStage.do',159,1,36,'2011-05-30 00:00:00',NULL),(675,'menu.name.675','menu.desc.675','sendGoldByLevelStage.do',674,2,1,'2011-05-30 00:00:00',NULL),(676,'menu.name.676','menu.desc.676','showItemAddByLevelStage.do',159,1,37,'2011-05-30 00:00:00',NULL),(677,'menu.name.677','menu.desc.677','itemAddByLevelStage.do',676,2,1,'2011-05-30 00:00:00',NULL),(678,'menu.name.678','menu.desc.678','showActivityModel.do',159,1,38,'2011-05-30 00:00:00',NULL),(679,'menu.name.679','menu.desc.679','showAddActivityModel.do',678,2,1,'2011-05-30 00:00:00',NULL),(680,'menu.name.680','menu.desc.680','addActivityModel.do',678,2,2,'2011-05-30 00:00:00',NULL),(681,'menu.name.681','menu.desc.681','showSetPackage.do',678,2,3,'2011-05-30 00:00:00',NULL),(682,'menu.name.682','menu.desc.682','setPackage.do',678,2,4,'2011-05-30 00:00:00',NULL),(683,'menu.name.683','menu.desc.683','showGenerateSerialCode.do',678,2,5,'2011-05-30 00:00:00',NULL),(684,'menu.name.684','menu.desc.684','generateSerialCode.do',678,2,6,'2011-05-30 00:00:00',NULL),(685,'menu.name.685','menu.desc.685','downloadCodeFile.do',678,2,7,'2011-05-30 00:00:00',NULL),(686,'menu.name.686','menu.desc.686','showIssueBulletinCompensate.do',159,1,39,'2011-05-30 00:00:00',NULL),(687,'menu.name.687','menu.desc.687','showFirstApprIssueBulletinCompensate.do',686,2,1,'2011-05-30 00:00:00',NULL),(688,'menu.name.688','menu.desc.688','showSecondApprIssueBulletinCompensate.do',686,2,2,'2011-05-30 00:00:00',NULL),(689,'menu.name.689','menu.desc.689','showAppredIssueBulletinCompensate.do',686,2,3,'2011-05-30 00:00:00',NULL),(690,'menu.name.690','menu.desc.690','showExedIssueBulletinCompensate.do',686,2,4,'2011-05-30 00:00:00',NULL),(691,'menu.name.691','menu.desc.691','showDeledIssueBulletinCompensate.do',686,2,5,'2011-05-30 00:00:00',NULL),(692,'menu.name.692','menu.desc.692','showCreateIssueBulletinCompensate.do',686,2,6,'2011-05-30 00:00:00',NULL),(693,'menu.name.693','menu.desc.693','saveIssueBulletinCompensate.do',686,2,7,'2011-05-30 00:00:00',NULL),(694,'menu.name.694','menu.desc.694','operIssueBulletinCompensate.do',686,2,8,'2011-05-30 00:00:00',NULL),(695,'menu.name.695','menu.desc.695','showEditIssueBulletinCompensate.do',686,2,9,'2011-05-30 00:00:00',NULL),(696,'menu.name.696','menu.desc.696','submitIssueBulletinCompensate.do',686,2,10,'2011-05-30 00:00:00',NULL),(697,'menu.name.697','menu.desc.697','delIssueBulletinCompensate.do',686,2,11,'2011-05-30 00:00:00',NULL),(698,'menu.name.698','menu.desc.698','cancelIssueBulletinCompensate.do',686,2,12,'2011-05-30 00:00:00',NULL),(699,'menu.name.699','menu.desc.699','show2FirstApprIssueBulletinCompensate.do',686,2,13,'2011-05-30 00:00:00',NULL),(700,'menu.name.700','menu.desc.700','batchFirstApprIssueBulletinCompensate.do',686,2,14,'2011-05-30 00:00:00',NULL),(701,'menu.name.701','menu.desc.701','firstApprIssueBulletinCompensate.do',686,2,15,'2011-05-30 00:00:00',NULL),(702,'menu.name.702','menu.desc.702','show2SecondApprIssueBulletinCompensate.do',686,2,16,'2011-05-30 00:00:00',NULL),(703,'menu.name.703','menu.desc.703','batchSecondApprIssueBulletinCompensate.do',686,2,17,'2011-05-30 00:00:00',NULL),(704,'menu.name.704','menu.desc.704','secondApprIssueBulletinCompensate.do',686,2,18,'2011-05-30 00:00:00',NULL),(705,'menu.name.705','menu.desc.705','exeIssueBulletinCompensate.do',686,2,19,'2011-05-30 00:00:00',NULL),(706,'menu.name.706','menu.desc.706','showIssueSettingExpCompensate.do',159,1,40,'2011-05-30 00:00:00',NULL),(707,'menu.name.707','menu.desc.707','showFirstApprIssueSettingExpCompensate.do',706,2,1,'2011-05-30 00:00:00',NULL),(708,'menu.name.708','menu.desc.708','showSecondApprIssueSettingExpCompensate.do',706,2,2,'2011-05-30 00:00:00',NULL),(709,'menu.name.709','menu.desc.709','showAppredIssueSettingExpCompensate.do',706,2,3,'2011-05-30 00:00:00',NULL),(710,'menu.name.710','menu.desc.710','showExedIssueSettingExpCompensate.do',706,2,4,'2011-05-30 00:00:00',NULL),(711,'menu.name.711','menu.desc.711','showDeledIssueSettingExpCompensate.do',706,2,5,'2011-05-30 00:00:00',NULL),(712,'menu.name.712','menu.desc.712','showCreateIssueSettingExpCompensate.do',706,2,6,'2011-05-30 00:00:00',NULL),(713,'menu.name.713','menu.desc.713','saveIssueSettingExpCompensate.do',706,2,7,'2011-05-30 00:00:00',NULL),(714,'menu.name.714','menu.desc.714','operIssueSettingExpCompensate.do',706,2,8,'2011-05-30 00:00:00',NULL),(715,'menu.name.715','menu.desc.715','showEditIssueSettingExpCompensate.do',706,2,9,'2011-05-30 00:00:00',NULL),(716,'menu.name.716','menu.desc.716','submitIssueSettingExpCompensate.do',706,2,10,'2011-05-30 00:00:00',NULL),(717,'menu.name.717','menu.desc.717','delIssueSettingExpCompensate.do',706,2,11,'2011-05-30 00:00:00',NULL),(718,'menu.name.718','menu.desc.718','cancelIssueSettingExpCompensate.do',706,2,12,'2011-05-30 00:00:00',NULL),(719,'menu.name.719','menu.desc.719','show2FirstApprIssueSettingExpCompensate.do',706,2,13,'2011-05-30 00:00:00',NULL),(720,'menu.name.720','menu.desc.720','batchFirstApprIssueSettingExpCompensate.do',706,2,14,'2011-05-30 00:00:00',NULL),(721,'menu.name.721','menu.desc.721','firstApprIssueSettingExpCompensate.do',706,2,15,'2011-05-30 00:00:00',NULL),(722,'menu.name.722','menu.desc.722','show2SecondApprIssueSettingExpCompensate.do',706,2,16,'2011-05-30 00:00:00',NULL),(723,'menu.name.723','menu.desc.723','batchSecondApprIssueSettingExpCompensate.do',706,2,17,'2011-05-30 00:00:00',NULL),(724,'menu.name.724','menu.desc.724','secondApprIssueSettingExpCompensate.do',706,2,18,'2011-05-30 00:00:00',NULL),(725,'menu.name.725','menu.desc.725','exeIssueSettingExpCompensate.do',706,2,19,'2011-05-30 00:00:00',NULL),(726,'menu.name.726','menu.desc.726','showIssueSettingExpCompensate.do',159,1,41,'2011-05-30 00:00:00',NULL),(727,'menu.name.727','menu.desc.727','showIssueSettingExpCompensate.do',159,1,42,'2011-05-30 00:00:00',NULL),(728,'menu.name.728','menu.desc.728','showIssueBulletinCompensate.do',159,1,43,'2011-05-30 00:00:00',NULL),(729,'menu.name.729','menu.desc.729','showIssueBulletinCompensate.do',159,1,44,'2011-05-30 00:00:00',NULL),(730,'menu.name.730','menu.desc.730','operActivity.do',678,2,8,'2011-05-30 00:00:00',NULL),(731,'menu.name.731','menu.desc.731','showQueryCleanPackage.do',60,1,59,'2011-05-30 00:00:00',NULL),(732,'menu.name.732','menu.desc.732','showCleanPackage.do',731,2,1,'2011-05-30 00:00:00',NULL),(733,'menu.name.733','menu.desc.733','cleanPackage.do',731,2,2,'2011-05-30 00:00:00',NULL),(734,'menu.name.734','menu.desc.734','showSetPackageItem.do',678,2,9,'2011-05-30 00:00:00',NULL),(735,'menu.name.735','menu.desc.735','setPackageItem.do',678,2,10,'2011-05-30 00:00:00',NULL),(736,'menu.name.736','menu.desc.736','showResetRoleAttr.do',60,1,60,'2011-05-30 00:00:00',NULL),(737,'menu.name.737','menu.desc.737','resetRoleAttr.do',736,2,1,'2011-05-30 00:00:00',NULL),(738,'menu.name.738','menu.desc.738','showSimuLogin.do',60,1,61,'2011-05-30 00:00:00',NULL),(739,'menu.name.739','menu.desc.739','simuLogin.do',738,2,1,'2011-05-30 00:00:00',NULL),(740,'menu.name.740','menu.desc.740','showRenameRole.do',60,1,62,'2011-05-30 00:00:00',NULL),(741,'menu.name.741','menu.desc.741','renameRole.do',740,2,1,'2011-05-30 00:00:00',NULL),(742,'menu.name.742','menu.desc.742','showKickOutUser.do',60,1,63,'2011-05-30 00:00:00',NULL),(743,'menu.name.743','menu.desc.743','kickOutUser.do',742,2,1,'2011-05-30 00:00:00',NULL),(744,'menu.name.744','menu.desc.744','showRole2Passport.do',22,1,46,'2011-05-30 00:00:00',NULL),(745,'menu.name.745','menu.desc.745','role2Passport.do',744,2,1,'2011-05-30 00:00:00',NULL),(746,'menu.name.746','menu.desc.746','showRoleItemLog.do',22,1,47,'2011-05-30 00:00:00',NULL),(747,'menu.name.747','menu.desc.747','roleItemLog.do',746,2,1,'2011-05-30 00:00:00',NULL),(748,'menu.name.748','menu.desc.748','showRoleMoneyLog.do',22,1,48,'2011-05-30 00:00:00',NULL),(749,'menu.name.749','menu.desc.749','roleMoneyLog.do',748,2,1,'2011-05-30 00:00:00',NULL),(750,'menu.name.750','menu.desc.750','showRoleExpLog.do',22,1,49,'2011-05-30 00:00:00',NULL),(751,'menu.name.751','menu.desc.751','roleExpLog.do',750,2,1,'2011-05-30 00:00:00',NULL),(752,'menu.name.752','menu.desc.752','showRoleItemLevLog.do',22,1,50,'2011-05-30 00:00:00',NULL),(753,'menu.name.753','menu.desc.753','roleItemLevLog.do',752,2,1,'2011-05-30 00:00:00',NULL),(754,'menu.name.754','menu.desc.754','delActivityModel.do',678,2,11,'2011-05-30 00:00:00',NULL),(755,'menu.name.755','menu.desc.755','delActivityModelPackage.do',678,2,12,'2011-05-30 00:00:00',NULL),(756,'menu.name.756','menu.desc.756','delActivityModelPackageItem.do',678,2,13,'2011-05-30 00:00:00',NULL),(757,'menu.name.757','menu.desc.757','showLoginInfo.do',22,1,51,'2011-05-30 00:00:00',NULL),(758,'menu.name.758','menu.desc.758','loginInfo.do',757,2,1,'2011-05-30 00:00:00',NULL),(759,'menu.name.759','menu.desc.759','showRoleItem.do',22,1,52,'2011-05-30 00:00:00',NULL),(760,'menu.name.760','menu.desc.760','roleItem.do',759,2,1,'2011-05-30 00:00:00',NULL),(761,'menu.name.761','menu.desc.761','showFinishedTaskInfo.do',22,1,53,'2011-05-30 00:00:00',NULL),(762,'menu.name.762','menu.desc.762','finishedTaskInfo.do',761,2,1,'2011-05-30 00:00:00',NULL),(763,'menu.name.763','menu.desc.763','showClearItem.do',60,1,64,'2011-05-30 00:00:00',NULL),(764,'menu.name.764','menu.desc.764','clearItem.do',763,2,1,'2011-05-30 00:00:00',NULL),(765,'menu.name.765','menu.desc.765','showClearStorage.do',60,1,65,'2011-05-30 00:00:00',NULL),(766,'menu.name.766','menu.desc.766','clearStorage.do',765,2,1,'2011-05-30 00:00:00',NULL),(767,'menu.name.767','menu.desc.767','showClearCorpsItem.do',60,1,66,'2011-05-30 00:00:00',NULL),(768,'menu.name.768','menu.desc.768','clearCorpsItem.do',767,2,1,'2011-05-30 00:00:00',NULL),(769,'menu.name.769','menu.desc.769','showActivationLog.do',22,1,54,'2011-05-30 00:00:00',NULL),(770,'menu.name.770','menu.desc.770','activationLog.do',769,2,1,'2011-05-30 00:00:00',NULL),(771,'menu.name.771','menu.desc.771','showModifyActivityModelTime.do',678,2,14,'2011-05-30 00:00:00',NULL),(772,'menu.name.772','menu.desc.772','modifyActivityModelTime.do',678,2,15,'2011-05-30 00:00:00',NULL),(773,'menu.name.773','menu.desc.773','showFreezeMac.do',60,1,67,'2011-05-30 00:00:00',NULL),(774,'menu.name.774','menu.desc.774','showFreezeMacLog.do',773,2,1,'2011-05-30 00:00:00',NULL),(775,'menu.name.775','menu.desc.775','showOperFreezeMac.do',773,2,2,'2011-05-30 00:00:00',NULL),(776,'menu.name.776','menu.desc.776','freezeMac.do',773,2,3,'2011-05-30 00:00:00',NULL),(777,'menu.name.777','menu.desc.777','unfreezeMac.do',773,2,4,'2011-05-30 00:00:00',NULL),(778,'menu.name.778','menu.desc.778','showFastFreezeAccount.do',60,1,68,'2011-05-30 00:00:00',NULL),(779,'menu.name.779','menu.desc.779','showFastUnfreezeAccount.do',60,1,69,'2011-05-30 00:00:00',NULL),(780,'menu.name.780','menu.desc.780','validateFastfreezeAccount.do',778,2,1,'2011-05-30 00:00:00',NULL),(781,'menu.name.781','menu.desc.781','fastFreezeAccount.do',778,2,2,'2011-05-30 00:00:00',NULL),(782,'menu.name.784','menu.desc.784','showQueryBatchSerialInfo.do',22,1,55,'2011-05-30 00:00:00',NULL),(783,'menu.name.785','menu.desc.785','queryBatchSerialInfo.do',782,2,1,'2011-05-30 00:00:00',NULL),(784,'menu.name.789','menu.desc.789','showCorpsDetailNew.do',22,1,56,'2011-05-30 00:00:00',NULL),(785,'menu.name.790','menu.desc.790','corpsDetailNew.do',784,2,1,'2011-05-30 00:00:00',NULL),(786,'menu.name.791','menu.desc.791','showCorpsStorage.do',22,1,57,'2011-05-30 00:00:00',NULL),(787,'menu.name.792','menu.desc.792','corpsStorage.do',786,2,1,'2011-05-30 00:00:00',NULL),(788,'menu.name.793','menu.desc.793','corpsItem.do',786,2,2,'2011-05-30 00:00:00',NULL),(789,'menu.name.794','menu.desc.794','clearCorpsStorage.do',805,2,2,'2011-05-30 00:00:00',NULL),(790,'menu.name.795','menu.desc.795','showRoleIntegration.do',22,1,58,'2011-05-30 00:00:00',NULL),(791,'menu.name.795','menu.desc.795','roleIntegration.do',790,2,1,'2011-05-30 00:00:00',NULL),(792,'menu.name.796','menu.desc.796','showRoleConsume.do',22,1,59,'2011-05-30 00:00:00',NULL),(793,'menu.name.796','menu.desc.796','roleConsume.do',792,2,1,'2011-05-30 00:00:00',NULL),(794,'menu.name.788','menu.desc.788','petItemDetail.do',45,2,12,'2011-05-30 00:00:00',NULL),(795,'menu.name.782','menu.desc.782','showUserPwdModify.do',1,1,5,'2011-05-30 00:00:00',NULL),(796,'menu.name.783','menu.desc.783','modifyUserPwd.do',795,2,1,'2011-05-30 00:00:00',NULL),(797,'menu.name.797','menu.desc.797','showCorpsMember.do',22,1,60,'2011-05-30 00:00:00',NULL),(798,'menu.name.798','menu.desc.798','getCorpsMember.do',797,2,1,'2011-05-30 00:00:00',NULL),(799,'menu.name.799','menu.desc.799','showQuerySummarySerialInfo.do',22,1,61,'2011-05-30 00:00:00',NULL),(800,'menu.name.800','menu.desc.800','querySummarySerialInfo.do',22,2,62,'2011-05-30 00:00:00',NULL),(801,'menu.name.801','menu.desc.801','showUpdateSerialMedia.do',159,1,45,'2011-05-30 00:00:00',NULL),(802,'menu.name.802','menu.desc.802','updateSerialMedia.do',159,2,46,'2011-05-30 00:00:00',NULL),(803,'menu.name.803','menu.desc.80','showGetPlayerInfoByIdCode.do',22,1,63,'2011-05-30 00:00:00',NULL),(804,'menu.name.804','menu.desc.804','getPlayerInfoByIdCode.do',22,2,64,'2011-05-30 00:00:00',NULL),(805,'menu.name.805','menu.desc.805','showClearCorpsStorage.do',60,1,70,'2011-05-30 00:00:00',NULL),(806,'menu.name.806','menu.desc.806','showCorpsTotalNew.do',22,1,65,'2011-05-30 00:00:00',NULL),(807,'menu.name.807','menu.desc.807','getCorpsTotalNew.do',806,2,1,'2011-05-30 00:00:00',NULL),(808,'menu.name.808','menu.desc.808','showQueryCheatAccountInfo.do',22,1,66,'2011-05-30 00:00:00',NULL),(809,'menu.name.809','menu.desc.809','queryCheatAccountInfo.do',808,2,1,'2011-05-30 00:00:00',NULL),(810,'menu.name.810','menu.desc.810','exportCheatAccountInfo.do',808,2,2,'2011-05-30 00:00:00',NULL),(811,'menu.name.786','menu.desc.786','showQueryPlayerResInfo.do',22,1,67,'2011-05-30 00:00:00',NULL),(812,'menu.name.787','menu.desc.787','queryPlayerResInfo.do',811,2,1,'2011-05-30 00:00:00',NULL),(813,'menu.name.811','menu.desc.811','showRoleEmail.do',22,1,66,'2011-05-30 00:00:00',NULL),(814,'menu.name.812','menu.desc.812','getRoleEmail.do',813,2,3,'2011-05-30 00:00:00',NULL),(815,'menu.name.813','menu.desc.813','showCorpsLog.do',22,1,67,'2011-05-30 00:00:00',NULL),(816,'menu.name.814','menu.desc.814','getCorpsLog.do',815,2,1,'2011-05-30 00:00:00',NULL),(817,'menu.name.815','menu.desc.815','showRoleLog.do',22,1,68,'2011-05-30 00:00:00',NULL),(818,'menu.name.816','menu.desc.816','getRoleLog.do',817,2,1,'2011-05-30 00:00:00',NULL),(819,'menu.name.817','menu.desc.817','showSetIbBag.do',159,1,46,'2011-05-30 00:00:00',NULL),(820,'menu.name.818','menu.desc.818','setIbBag.do',819,2,1,'2011-05-30 00:00:00',NULL),(821,'menu.name.819','menu.desc.819','showProductInfo.do',280,2,12,'2011-05-30 00:00:00',NULL),(822,'menu.name.821','menu.desc.821','productInfo.do',280,2,13,'2011-05-30 00:00:00',NULL),(823,'menu.name.820','menu.desc.820','showModifyProduct.do',280,2,14,'2011-05-30 00:00:00',NULL),(824,'menu.name.822','menu.desc.822','modifyProduct.do',280,2,15,'2011-05-30 00:00:00',NULL),(825,'menu.name.823','menu.desc.823','showRoleAuction.do',22,1,69,'2011-05-30 00:00:00',NULL),(826,'menu.name.824','menu.desc.824','getRoleAuction.do',825,2,1,'2011-05-30 00:00:00',NULL),(827,'menu.name.825','menu.desc.825','showClearPointsCompensate.do',103,1,32,'2011-05-30 00:00:00',NULL),(828,'menu.name.826','menu.desc.826','showFirstApprClearPointsCompensate.do',827,2,1,'2011-05-30 00:00:00',NULL),(829,'menu.name.827','menu.desc.827','showSecondApprClearPointsCompensate.do',827,2,2,'2011-05-30 00:00:00',NULL),(830,'menu.name.828','menu.desc.828','showAppredClearPointsCompensate.do',827,2,3,'2011-05-30 00:00:00',NULL),(831,'menu.name.829','menu.desc.829','showExedClearPointsCompensate.do',827,2,4,'2011-05-30 00:00:00',NULL),(832,'menu.name.830','menu.desc.830','showDeledClearPointsCompensate.do',827,2,5,'2011-05-30 00:00:00',NULL),(833,'menu.name.831','menu.desc.831','showCreateClearPointsCompensate.do',827,2,6,'2011-05-30 00:00:00',NULL),(834,'menu.name.832','menu.desc.832','saveClearPointsCompensate.do',827,2,7,'2011-05-30 00:00:00',NULL),(835,'menu.name.833','menu.desc.833','operClearPointsCompensate.do',827,2,8,'2011-05-30 00:00:00',NULL),(836,'menu.name.834','menu.desc.834','showEditClearPointsCompensate.do',827,2,9,'2011-05-30 00:00:00',NULL),(837,'menu.name.835','menu.desc.835','submitClearPointsCompensate.do',827,2,10,'2011-05-30 00:00:00',NULL),(838,'menu.name.836','menu.desc.836','delClearPointsCompensate.do',827,2,11,'2011-05-30 00:00:00',NULL),(839,'menu.name.837','menu.desc.837','cancelClearPointsCompensate.do',827,2,12,'2011-05-30 00:00:00',NULL),(840,'menu.name.838','menu.desc.838','show2FirstApprClearPointsCompensate.do',827,2,13,'2011-05-30 00:00:00',NULL),(841,'menu.name.839','menu.desc.839','batchFirstApprClearPointsCompensate.do',827,2,14,'2011-05-30 00:00:00',NULL),(842,'menu.name.840','menu.desc.840','firstApprClearPointsCompensate.do',827,2,15,'2011-05-30 00:00:00',NULL),(843,'menu.name.841','menu.desc.841','show2SecondApprClearPointsCompensate.do',827,2,16,'2011-05-30 00:00:00',NULL),(844,'menu.name.842','menu.desc.842','batchSecondApprClearPointsCompensate.do',827,2,17,'2011-05-30 00:00:00',NULL),(845,'menu.name.843','menu.desc.843','secondApprClearPointsCompensate',827,2,18,'2011-05-30 00:00:00',NULL),(846,'menu.name.844','menu.desc.844','exeClearPointsCompensate.do',827,2,19,'2011-05-30 00:00:00',NULL),(847,'menu.name.845','menu.desc.845','showClearPointsCompensate.do',103,1,33,'2011-05-30 00:00:00',NULL),(848,'menu.name.846','menu.desc.846','showClearPointsCompensate.do',103,1,34,'2011-05-30 00:00:00',NULL),(850,'menu.name.826','menu.desc.826','showFirstApprClearPointsCompensate.do',822,2,1,'2011-05-30 00:00:00',NULL),(851,'menu.name.827','menu.desc.827','showSecondApprClearPointsCompensate.do',822,2,2,'2011-05-30 00:00:00',NULL),(852,'menu.name.828','menu.desc.828','showAppredClearPointsCompensate.do',822,2,3,'2011-05-30 00:00:00',NULL),(853,'menu.name.829','menu.desc.829','showExedClearPointsCompensate.do',822,2,4,'2011-05-30 00:00:00',NULL),(854,'menu.name.830','menu.desc.830','showDeledClearPointsCompensate.do',822,2,5,'2011-05-30 00:00:00',NULL),(855,'menu.name.831','menu.desc.831','showCreateClearPointsCompensate.do',822,2,6,'2011-05-30 00:00:00',NULL),(856,'menu.name.832','menu.desc.832','saveClearPointsCompensate.do',822,2,7,'2011-05-30 00:00:00',NULL),(857,'menu.name.833','menu.desc.833','operClearPointsCompensate.do',822,2,8,'2011-05-30 00:00:00',NULL),(858,'menu.name.834','menu.desc.834','showEditClearPointsCompensate.do',822,2,9,'2011-05-30 00:00:00',NULL),(859,'menu.name.835','menu.desc.835','submitClearPointsCompensate.do',822,2,10,'2011-05-30 00:00:00',NULL),(860,'menu.name.836','menu.desc.836','delClearPointsCompensate.do',822,2,11,'2011-05-30 00:00:00',NULL),(861,'menu.name.837','menu.desc.837','cancelClearPointsCompensate.do',822,2,12,'2011-05-30 00:00:00',NULL),(862,'menu.name.838','menu.desc.838','show2FirstApprClearPointsCompensate.do',822,2,13,'2011-05-30 00:00:00',NULL),(863,'menu.name.839','menu.desc.839','batchFirstApprClearPointsCompensate.do',822,2,14,'2011-05-30 00:00:00',NULL),(864,'menu.name.840','menu.desc.840','firstApprClearPointsCompensate.do',822,2,15,'2011-05-30 00:00:00',NULL),(865,'menu.name.841','menu.desc.841','show2SecondApprClearPointsCompensate.do',822,2,16,'2011-05-30 00:00:00',NULL),(866,'menu.name.842','menu.desc.842','batchSecondApprClearPointsCompensate.do',822,2,17,'2011-05-30 00:00:00',NULL),(867,'menu.name.843','menu.desc.843','secondApprClearPointsCompensate',822,2,18,'2011-05-30 00:00:00',NULL),(868,'menu.name.844','menu.desc.844','exeClearPointsCompensate.do',822,2,19,'2011-05-30 00:00:00',NULL),(872,'menu.name.826','menu.desc.826','showFirstApprClearPointsCompensate.do',822,2,1,'2011-05-30 00:00:00',NULL),(873,'menu.name.827','menu.desc.827','showSecondApprClearPointsCompensate.do',822,2,2,'2011-05-30 00:00:00',NULL),(874,'menu.name.828','menu.desc.828','showAppredClearPointsCompensate.do',822,2,3,'2011-05-30 00:00:00',NULL),(875,'menu.name.829','menu.desc.829','showExedClearPointsCompensate.do',822,2,4,'2011-05-30 00:00:00',NULL),(876,'menu.name.830','menu.desc.830','showDeledClearPointsCompensate.do',822,2,5,'2011-05-30 00:00:00',NULL),(877,'menu.name.831','menu.desc.831','showCreateClearPointsCompensate.do',822,2,6,'2011-05-30 00:00:00',NULL),(878,'menu.name.832','menu.desc.832','saveClearPointsCompensate.do',822,2,7,'2011-05-30 00:00:00',NULL),(879,'menu.name.833','menu.desc.833','operClearPointsCompensate.do',822,2,8,'2011-05-30 00:00:00',NULL),(880,'menu.name.834','menu.desc.834','showEditClearPointsCompensate.do',822,2,9,'2011-05-30 00:00:00',NULL),(881,'menu.name.835','menu.desc.835','submitClearPointsCompensate.do',822,2,10,'2011-05-30 00:00:00',NULL),(882,'menu.name.836','menu.desc.836','delClearPointsCompensate.do',822,2,11,'2011-05-30 00:00:00',NULL),(883,'menu.name.837','menu.desc.837','cancelClearPointsCompensate.do',822,2,12,'2011-05-30 00:00:00',NULL),(884,'menu.name.838','menu.desc.838','show2FirstApprClearPointsCompensate.do',822,2,13,'2011-05-30 00:00:00',NULL),(885,'menu.name.839','menu.desc.839','batchFirstApprClearPointsCompensate.do',822,2,14,'2011-05-30 00:00:00',NULL),(886,'menu.name.840','menu.desc.840','firstApprClearPointsCompensate.do',822,2,15,'2011-05-30 00:00:00',NULL),(887,'menu.name.841','menu.desc.841','show2SecondApprClearPointsCompensate.do',822,2,16,'2011-05-30 00:00:00',NULL),(888,'menu.name.842','menu.desc.842','batchSecondApprClearPointsCompensate.do',822,2,17,'2011-05-30 00:00:00',NULL),(889,'menu.name.843','menu.desc.843','secondApprClearPointsCompensate',822,2,18,'2011-05-30 00:00:00',NULL),(890,'menu.name.844','menu.desc.844','exeClearPointsCompensate.do',822,2,19,'2011-05-30 00:00:00',NULL),(894,'menu.name.826','menu.desc.826','showFirstApprClearPointsCompensate.do',822,2,1,'2011-05-30 00:00:00',NULL),(895,'menu.name.827','menu.desc.827','showSecondApprClearPointsCompensate.do',822,2,2,'2011-05-30 00:00:00',NULL),(896,'menu.name.828','menu.desc.828','showAppredClearPointsCompensate.do',822,2,3,'2011-05-30 00:00:00',NULL),(897,'menu.name.829','menu.desc.829','showExedClearPointsCompensate.do',822,2,4,'2011-05-30 00:00:00',NULL),(898,'menu.name.830','menu.desc.830','showDeledClearPointsCompensate.do',822,2,5,'2011-05-30 00:00:00',NULL),(899,'menu.name.831','menu.desc.831','showCreateClearPointsCompensate.do',822,2,6,'2011-05-30 00:00:00',NULL),(900,'menu.name.832','menu.desc.832','saveClearPointsCompensate.do',822,2,7,'2011-05-30 00:00:00',NULL),(901,'menu.name.833','menu.desc.833','operClearPointsCompensate.do',822,2,8,'2011-05-30 00:00:00',NULL),(902,'menu.name.834','menu.desc.834','showEditClearPointsCompensate.do',822,2,9,'2011-05-30 00:00:00',NULL),(903,'menu.name.835','menu.desc.835','submitClearPointsCompensate.do',822,2,10,'2011-05-30 00:00:00',NULL),(904,'menu.name.836','menu.desc.836','delClearPointsCompensate.do',822,2,11,'2011-05-30 00:00:00',NULL),(905,'menu.name.837','menu.desc.837','cancelClearPointsCompensate.do',822,2,12,'2011-05-30 00:00:00',NULL),(906,'menu.name.838','menu.desc.838','show2FirstApprClearPointsCompensate.do',822,2,13,'2011-05-30 00:00:00',NULL),(907,'menu.name.839','menu.desc.839','batchFirstApprClearPointsCompensate.do',822,2,14,'2011-05-30 00:00:00',NULL),(908,'menu.name.840','menu.desc.840','firstApprClearPointsCompensate.do',822,2,15,'2011-05-30 00:00:00',NULL),(909,'menu.name.841','menu.desc.841','show2SecondApprClearPointsCompensate.do',822,2,16,'2011-05-30 00:00:00',NULL),(910,'menu.name.842','menu.desc.842','batchSecondApprClearPointsCompensate.do',822,2,17,'2011-05-30 00:00:00',NULL),(911,'menu.name.843','menu.desc.843','secondApprClearPointsCompensate',822,2,18,'2011-05-30 00:00:00',NULL),(912,'menu.name.844','menu.desc.844','exeClearPointsCompensate.do',822,2,19,'2011-05-30 00:00:00',NULL),(916,'menu.name.826','menu.desc.826','showFirstApprClearPointsCompensate.do',822,2,1,'2011-05-30 00:00:00',NULL),(917,'menu.name.827','menu.desc.827','showSecondApprClearPointsCompensate.do',822,2,2,'2011-05-30 00:00:00',NULL),(918,'menu.name.828','menu.desc.828','showAppredClearPointsCompensate.do',822,2,3,'2011-05-30 00:00:00',NULL),(919,'menu.name.829','menu.desc.829','showExedClearPointsCompensate.do',822,2,4,'2011-05-30 00:00:00',NULL),(920,'menu.name.830','menu.desc.830','showDeledClearPointsCompensate.do',822,2,5,'2011-05-30 00:00:00',NULL),(921,'menu.name.831','menu.desc.831','showCreateClearPointsCompensate.do',822,2,6,'2011-05-30 00:00:00',NULL),(922,'menu.name.832','menu.desc.832','saveClearPointsCompensate.do',822,2,7,'2011-05-30 00:00:00',NULL),(923,'menu.name.833','menu.desc.833','operClearPointsCompensate.do',822,2,8,'2011-05-30 00:00:00',NULL),(924,'menu.name.834','menu.desc.834','showEditClearPointsCompensate.do',822,2,9,'2011-05-30 00:00:00',NULL),(925,'menu.name.835','menu.desc.835','submitClearPointsCompensate.do',822,2,10,'2011-05-30 00:00:00',NULL),(926,'menu.name.836','menu.desc.836','delClearPointsCompensate.do',822,2,11,'2011-05-30 00:00:00',NULL),(927,'menu.name.837','menu.desc.837','cancelClearPointsCompensate.do',822,2,12,'2011-05-30 00:00:00',NULL),(928,'menu.name.838','menu.desc.838','show2FirstApprClearPointsCompensate.do',822,2,13,'2011-05-30 00:00:00',NULL),(929,'menu.name.839','menu.desc.839','batchFirstApprClearPointsCompensate.do',822,2,14,'2011-05-30 00:00:00',NULL),(930,'menu.name.840','menu.desc.840','firstApprClearPointsCompensate.do',822,2,15,'2011-05-30 00:00:00',NULL),(931,'menu.name.841','menu.desc.841','show2SecondApprClearPointsCompensate.do',822,2,16,'2011-05-30 00:00:00',NULL),(932,'menu.name.842','menu.desc.842','batchSecondApprClearPointsCompensate.do',822,2,17,'2011-05-30 00:00:00',NULL),(933,'menu.name.843','menu.desc.843','secondApprClearPointsCompensate',822,2,18,'2011-05-30 00:00:00',NULL),(934,'menu.name.844','menu.desc.844','exeClearPointsCompensate.do',822,2,19,'2011-05-30 00:00:00',NULL),(937,'menu.name.848','menu.desc.848','showInvokeCard.do',22,1,71,'2011-05-30 00:00:00',NULL),(938,'menu.name.849','menu.desc.849','getInvokeCard.do',937,2,72,'2011-05-30 00:00:00',NULL),(939,'menu.name.847','menu.desc.847','showQueryHardwareSNFreeze.do',22,1,72,'2011-05-30 00:00:00',NULL),(940,'menu.name.852','menu.desc.852','queryHardwareSNFreeze.do',939,2,1,'2011-05-30 00:00:00',NULL),(941,'menu.name.850','menu.desc.850','showFreezeHardwareSN.do',60,1,71,'2011-05-30 00:00:00',NULL),(942,'menu.name.853','menu.desc.853','freezeHardwareSN.do',941,2,1,'2011-05-30 00:00:00',NULL),(943,'menu.name.851','menu.desc.851','showUnfreezeHardwareSN.do',60,1,72,'2011-05-30 00:00:00',NULL),(944,'menu.name.854','menu.desc.854','unfreezeHardwareSN.do',943,2,1,'2011-05-30 00:00:00',NULL),(945,'menu.name.855','menu.desc.855','showQueryPlayerInfoOfBaidu.do',22,1,73,'2011-05-30 00:00:00',NULL),(946,'menu.name.856','menu.desc.856','queryPlayerInfoOfBaidu.do',945,2,1,'2011-05-30 00:00:00',NULL),(947,'menu.name.857','menu.desc.857','showRoleItemRecover.do',60,1,73,'2011-05-30 00:00:00',NULL),(948,'menu.name.858','menu.desc.858','recoverRoleItem.do',947,2,1,'2011-05-30 00:00:00',NULL),(949,'menu.name.859','menu.desc.859','showQueryGroupMsg.do',159,1,47,'2011-05-30 00:00:00',NULL),(950,'menu.name.860','menu.desc.860','queryAllGroupMsg.do',949,2,1,'2011-05-30 00:00:00',NULL),(951,'menu.name.861','menu.desc.861','querySpecificGroupMsg.do',949,2,2,'2011-05-30 00:00:00',NULL),(952,'menu.name.862','menu.desc.862','showAddGroupMsg.do',949,2,3,'2011-05-30 00:00:00',NULL),(953,'menu.name.863','menu.desc.863','addGroupMsg.do',949,2,4,'2011-05-30 00:00:00',NULL),(954,'menu.name.864','menu.desc.864','delAllGroupMsg.do',949,2,5,'2011-05-30 00:00:00',NULL),(955,'menu.name.865','menu.desc.865','delOneGroupMsg.do',949,2,6,'2011-05-30 00:00:00',NULL),(956,'menu.name.866','menu.desc.866','openGroupMsg.do',949,2,7,'2011-05-30 00:00:00',NULL),(957,'menu.name.867','menu.desc.867','showUpdateGroupMsg.do',949,2,8,'2011-05-30 00:00:00',NULL),(958,'menu.name.868','menu.desc.868','updateGroupMsg.do',949,2,9,'2011-05-30 00:00:00',NULL),(959,'menu.name.869','menu.desc.869','logManage.do?method=showRoleOperLog',947,2,2,'2011-05-30 00:00:00',NULL),(960,'menu.name.870','menu.desc.870','showRoleGame.do',10,2,2,'2011-05-30 00:00:00',NULL),(961,'menu.name.871','menu.desc.871','insertRoleGame.do',10,2,3,'2011-05-30 00:00:00',NULL),(962,'menu.name.872','menu.desc.872','deleteRoleGame.do',10,2,4,'2011-05-30 00:00:00',NULL),(963,'menu.name.873','menu.desc.873','showDynamicToken.do?operateType=0',159,1,47,'2011-05-30 00:00:00',NULL),(964,'menu.name.875','menu.desc.875','operateDynamicToken.do',871,2,1,'2011-05-30 00:00:00',NULL),(965,'menu.name.874','menu.desc.874','queryDynamicToken.do',871,2,2,'2011-05-30 00:00:00',NULL),(966,'menu.name.876','menu.desc.876','showDynamicToken.do?operateType=1',871,2,3,'2011-05-30 00:00:00',NULL),(967,'menu.name.878','menu.desc.878','showDynamicToken.do?operateType=2',871,2,4,'2011-05-30 00:00:00',NULL),(968,'menu.name.879','menu.desc.879','showDynamicToken.do?operateType=3',871,2,5,'2011-05-30 00:00:00',NULL),(969,'menu.name.877','menu.desc.877','showDynamicToken.do?operateType=4',871,2,6,'2011-05-30 00:00:00',NULL),(970,'menu.name.880','menu.desc.880','showDirtyWord.do',159,1,48,'2011-05-30 00:00:00',NULL),(971,'menu.name.881','menu.desc.881','operateDirtyWord.do',970,2,1,'2011-05-30 00:00:00',NULL),(972,'menu.name.882','menu.desc.882','showChargeGatewayList.do',159,1,49,'2011-05-30 00:00:00',NULL),(973,'menu.name.883','menu.desc.883','openChargeGateway.do',972,2,1,'2011-05-30 00:00:00',NULL),(974,'menu.name.884','menu.desc.884','freezeOrUnfreezeChargeGateway.do',972,2,2,'2011-05-30 00:00:00',NULL),(975,'menu.name.885','menu.desc.885','showAddOrUpdateChargeGateway.do',972,2,3,'2011-05-30 00:00:00',NULL),(976,'menu.name.886','menu.desc.886','addOrUpdateChargeGateway.do',972,2,4,'2011-05-30 00:00:00',NULL),(977,'menu.name.887','menu.desc.887','showChargeGatewayConfigList.do',972,2,5,'2011-05-30 00:00:00',NULL),(978,'menu.name.888','menu.desc.888','openChargeGatewayConfig.do',972,2,6,'2011-05-30 00:00:00',NULL),(979,'menu.name.889','menu.desc.889','freezeOrUnfreezeChargeGatewayConfig.do',972,2,7,'2011-05-30 00:00:00',NULL),(980,'menu.name.890','menu.desc.890','showAddOrUpdateChargeGatewayConfig.do',972,2,8,'2011-05-30 00:00:00',NULL),(981,'menu.name.891','menu.desc.891','addOrUpdateChargeGatewayConfig.do',972,2,9,'2011-05-30 00:00:00',NULL),(982,'menu.name.892','menu.desc.892','showFundExchange.do',22,1,74,'2011-05-30 00:00:00',NULL),(983,'menu.name.893','menu.desc.893','getFundExchange.do',982,2,1,'2011-05-30 00:00:00',NULL),(984,'menu.name.894','menu.desc.894','searchChargeGatewayByName.do',972,2,10,'2011-05-30 00:00:00',NULL),(985,'menu.name.895','menu.desc.895','showRoleUsers.do',10,2,5,'2011-05-30 00:00:00',NULL),(1000,'menu.name.1000','menu.desc.1000','showSynchronizationActivityGames.do',171,2,49,'2011-05-30 00:00:00',NULL),(1001,'menu.name.1001','menu.desc.1001','showSynchronizationActivity.do',171,2,49,'2011-05-30 00:00:00',NULL),(1002,'menu.name.1002','menu.desc.1002','synchronizationActivity.do',171,2,49,'2011-05-30 00:00:00',NULL),(1003,'menu.name.1003','menu.desc.1003','showSynChargeGiveItemGames.do',315,2,49,'2011-05-30 00:00:00',NULL),(1004,'menu.name.1004','menu.desc.1004','showSynChargeGiveItem.do',315,2,49,'2011-05-30 00:00:00',NULL),(1005,'menu.name.1005','menu.desc.1005','synChargeGiveItem.do',315,2,49,'2011-05-30 00:00:00',NULL),(1006,'menu.name.1006','menu.desc.1006','showRoleItemRecover.do?oper=query',60,1,74,'2011-05-30 00:00:00',NULL),(1007,'menu.name.1007','menu.desc.1007','showUserInfoByIp.do',22,1,75,'2011-05-30 00:00:00',NULL),(1008,'menu.name.1008','menu.desc.1008','userInfoByIp.do',1007,2,75,'2011-05-30 00:00:00',NULL),(1009,'menu.name.1009','menu.desc.1009','showEmail.do',60,1,75,'2011-05-30 00:00:00',NULL),(1010,'menu.name.1010','menu.desc.1010','sendEmail.do',1009,2,1,'2011-05-30 00:00:00',NULL),(1011,'menu.name.1011','menu.desc.1011','showSynGameServer.do',220,2,1,'2011-05-30 00:00:00',NULL),(1012,'menu.name.1012','menu.desc.1012','synGameServer.do',220,2,2,'2011-05-30 00:00:00',NULL),(1013,'menu.name.1013','menu.desc.1013','showSynGateway.do',214,2,1,'2011-05-30 00:00:00',NULL),(1014,'menu.name.1014','menu.desc.1014','synGateway.do',214,2,2,'2011-05-30 00:00:00',NULL),(1015,'menu.name.1015','menu.desc.1015','showSynPassport.do',362,2,1,'2011-05-30 00:00:00',NULL),(1016,'menu.name.1016','menu.desc.1016','synPassport.do',362,2,2,'2011-05-30 00:00:00',NULL),(1017,'menu.name.1017','menu.desc.1017','showChargeDetail.do',22,1,76,'2011-05-30 00:00:00',NULL),(1018,'menu.name.1018','menu.desc.1018','getChargeDetail.do',1017,2,1,'2011-05-30 00:00:00',NULL),(1019,'menu.name.1019','menu.desc.1019','exportChargeOrderData.do',1017,2,2,'2011-05-30 00:00:00',NULL),(1020,'menu.name.1020','menu.desc.1020','showAddRelationGames.do',188,1,75,'2011-05-30 00:00:00',NULL),(1021,'menu.name.1021','menu.desc.1021','addRelationGame.do',1020,2,1,'2011-05-30 00:00:00',NULL),(1022,'menu.name.1022','menu.desc.1022','delRelationGame.do',1020,2,2,'2011-05-30 00:00:00',NULL),(1023,'menu.name.1023','menu.desc.1023','showQueryPlayerChargeDetail.do?internal=true',34,1,77,'2011-05-30 00:00:00',NULL),(1024,'menu.name.1024','menu.desc.1024','showQueryPlayerAccountDetail.do?internal=true',34,1,78,'2011-05-30 00:00:00',NULL),(1025,'menu.name.1025','menu.desc.1025','showQueryOrderStatus.do?internal=true',34,1,79,'2011-05-30 00:00:00',NULL),(1026,'menu.name.1026','menu.desc.1026','showQueryOrderDetail.do?internal=true',34,1,80,'2011-05-30 00:00:00',NULL),(1027,'menu.name.1027','menu.desc.1027','showPlayerItems.do?internal=true',34,1,81,'2011-05-30 00:00:00',NULL),(1028,'menu.name.1028','menu.desc.1028','showLogPlayerItems.do?internal=true',34,1,82,'2011-05-30 00:00:00',NULL),(1029,'menu.name.1029','menu.desc.1029','showGetGameByRoleNames.do',22,1,77,'2011-05-30 00:00:00',NULL),(1030,'menu.name.1030','menu.desc.1030','getGameByRoleNames.do',1029,2,78,'2011-05-30 00:00:00',NULL),(1031,'menu.name.1080','menu.desc.1080','showUnionGatewayPlanList.do',159,1,50,'2011-05-30 00:00:00',NULL),(1032,'menu.name.1032','menu.desc.1032','showAddUnionGateway.do',1031,2,1,'2011-05-30 00:00:00',NULL),(1033,'menu.name.1033','menu.desc.1033','addUnionGateway.do',1031,2,2,'2011-05-30 00:00:00',NULL),(1034,'menu.name.1034','menu.desc.1034','openUnionGateway.do',1031,2,3,'2011-05-30 00:00:00',NULL),(1035,'menu.name.1035','menu.desc.1035','exportPlayerPurchaseDetail.do',47,2,5,'2011-05-30 00:00:00',NULL),(1037,'menu.name.1037','menu.desc.1037','markPassport.do',60,2,77,'2011-05-30 00:00:00',NULL),(1038,'menu.name.1038','menu.desc.1038','exportAllSerialInfo.do',782,2,2,'2011-05-30 00:00:00',NULL),(1039,'menu.name.1039','menu.desc.1039','showImportFromFile.do',188,1,38,'2011-05-30 00:00:00',NULL),(1040,'menu.name.1040','menu.desc.1040','importFromFile.do',1039,2,2,'2011-05-30 00:00:00',NULL),(1041,'menu.name.1041','menu.desc.1041','showResetStorePwd.do',60,1,77,'2011-05-30 00:00:00',NULL),(1042,'menu.name.1042','menu.desc.1042','resetStorePwd.do',1041,2,2,'2011-05-30 00:00:00',NULL),(1043,'menu.name.1043','menu.desc.1043','showRoleCompensate.do?compensateType=1',103,1,35,'2011-05-30 00:00:00',NULL),(1044,'menu.name.1044','menu.desc.1044','showCreateRoleCompensate.do',1043,2,36,'2011-05-30 00:00:00',NULL),(1045,'menu.name.1045','menu.desc.1045','saveRoleCompensate.do',1043,2,37,'2011-05-30 00:00:00',NULL),(1046,'menu.name.1046','menu.desc.1046','showEditRoleCompensate.do',1043,2,38,'2011-05-30 00:00:00',NULL),(1047,'menu.name.1047','menu.desc.1047','operRoleCompensate.do',1043,2,39,'2011-05-30 00:00:00',NULL),(1048,'menu.name.1048','menu.desc.1048','submitRoleCompensate.do',1043,2,40,'2011-05-30 00:00:00',NULL),(1049,'menu.name.1049','menu.desc.1049','delRoleCompensate.do',1043,2,41,'2011-05-30 00:00:00',NULL),(1050,'menu.name.1050','menu.desc.1050','showDeledRoleCompensate.do',1043,2,42,'2011-05-30 00:00:00',NULL),(1051,'menu.name.1051','menu.desc.1051','cancelRoleCompensate.do',1043,2,43,'2011-05-30 00:00:00',NULL),(1052,'menu.name.1052','menu.desc.1052','show2FirstApprRoleCompensate.do',1043,2,44,'2011-05-30 00:00:00',NULL),(1053,'menu.name.1053','menu.desc.1053','firstApprRoleCompensate.do',1043,2,45,'2011-05-30 00:00:00',NULL),(1054,'menu.name.1054','menu.desc.1054','secondApprRoleCompensate.do',1043,2,46,'2011-05-30 00:00:00',NULL),(1055,'menu.name.1055','menu.desc.1055','showFirstApprRoleCompensate.do',1043,2,47,'2011-05-30 00:00:00',NULL),(1056,'menu.name.1056','menu.desc.1056','showSecondApprRoleCompensate.do',1043,2,48,'2011-05-30 00:00:00',NULL),(1057,'menu.name.1057','menu.desc.1057','showAppredRoleCompensate.do',1043,2,49,'2011-05-30 00:00:00',NULL),(1058,'menu.name.1058','menu.desc.1058','showExedRoleCompensate.do',1043,2,50,'2011-05-30 00:00:00',NULL),(1059,'menu.name.1059','menu.desc.1059','exeRoleCompensate.do',1043,2,51,'2011-05-30 00:00:00',NULL),(1060,'menu.name.1060','menu.desc.1060','batchFirstApprRoleCompensate.do',1043,2,52,'2011-05-30 00:00:00',NULL),(1061,'menu.name.1061','menu.desc.1061','batchSecondApprRoleCompensate.do',1043,2,53,'2011-05-30 00:00:00',NULL),(1062,'menu.name.1062','menu.desc.1062','showRoleCompensate.do?compensateType=1',103,1,54,'2011-05-30 00:00:00',NULL),(1063,'menu.name.1063','menu.desc.1063','showRoleCompensate.do?compensateType=1',103,1,55,'2011-05-30 00:00:00',NULL),(1064,'menu.name.1064','menu.desc.1064','showOperUnionGateway.do',1031,2,4,'2011-05-30 00:00:00',NULL),(1065,'menu.name.1065','menu.desc.1065','delUnionGateway.do',1031,2,5,'2011-05-30 00:00:00',NULL),(1066,'menu.name.1066','menu.desc.1066','shutOldGateway.do',1031,2,6,'2011-05-30 00:00:00',NULL),(1067,'menu.name.1067','menu.desc.1067','exeUnionGateway.do',1031,2,7,'2011-05-30 00:00:00',NULL),(1068,'menu.name.1068','menu.desc.1068','showOperActivityModel.do',678,2,51,'2011-05-30 00:00:00',NULL),(1069,'menu.name.1069','menu.desc.1069','updateActivityModel.do',678,2,52,'2011-05-30 00:00:00',NULL),(1070,'menu.name.1070','menu.desc.1070','showMute1ActivityModel.do',678,2,53,'2011-05-30 00:00:00',NULL),(1071,'menu.name.1071','menu.desc.1071','mute1ActivityModel.do',678,2,54,'2011-05-30 00:00:00',NULL),(1072,'menu.name.1072','menu.desc.1072','showMute2ActivityModel.do',678,2,55,'2011-05-30 00:00:00',NULL),(1073,'menu.name.1073','menu.desc.1073','mute2ActivityModel.do',678,2,56,'2011-05-30 00:00:00',NULL),(1074,'menu.name.1074','menu.desc.1074','showConfigOption.do',188,1,39,'2011-05-30 00:00:00',NULL),(1075,'menu.name.1075','menu.desc.1075','showConfigOptionInfo.do',1074,2,1,'2011-05-30 00:00:00',NULL),(1076,'menu.name.1076','menu.desc.1076','updateConfigOptionInfo.do',1074,2,2,'2011-05-30 00:00:00',NULL),(1078,'menu.name.1078','menu.desc.1078','showActivityModel.do?version=new',159,1,39,'2011-05-30 00:00:00',NULL),(1080,'menu.name.1031','menu.desc.1031','showUnionGatewayList.do',1031,2,8,'2011-05-30 00:00:00',NULL),(1081,'menu.name.1081','menu.desc.1081','showAddUnionGatewayPlan.do',1031,2,9,'2011-05-30 00:00:00',NULL),(1082,'menu.name.1082','menu.name.1082','addUnionGatewayPlan.do',1031,2,10,'2011-05-30 00:00:00',NULL),(1083,'menu.name.1083','menu.name.1083','showOperUnionGatewayPlan.do',1031,2,11,'2011-05-30 00:00:00',NULL),(1084,'menu.name.1084','menu.name.1084','bakeUnionGatewayPlan.do',1031,2,12,'2011-05-30 00:00:00',NULL),(1085,'menu.name.1085','menu.name.1085','exeUnionGatewayPlan.do',1031,2,13,'2011-05-30 00:00:00',NULL),(1086,'menu.name.1086','menu.name.1086','deleteUnionGatewayPlan.do',1031,2,14,'2011-05-30 00:00:00',NULL),(1087,'menu.name.1087','menu.name.1087','showModifyOperUnionGatewayPlan.do',1031,2,15,'2011-05-30 00:00:00',NULL),(1088,'menu.name.1088','menu.name.1088','modifyUnionGatewayPlan.do',1031,2,16,'2011-05-30 00:00:00',NULL),(1089,'menu.name.1089','menu.desc.1089','showQueryPlayerInfo.do',34,1,9,'2011-05-30 00:00:00',NULL),(1090,'menu.name.1090','menu.desc.1090','showSearchRole.do',34,1,10,'2011-05-30 00:00:00',NULL),(1091,'menu.name.1091','menu.desc.1091','showPlayerSerialState.do',22,1,78,'2011-05-30 00:00:00',NULL),(1092,'menu.name.1092','menu.desc.1092','playerSerialState.do',1091,2,1,'2011-05-30 00:00:00',NULL),(1093,'menu.name.1093','menu.desc.1093','showBiActivity.do',188,1,78,'2011-05-30 00:00:00',NULL),(1094,'menu.name.1094','menu.desc.1094','showAddBiActivity.do',1093,2,1,'2011-05-30 00:00:00',NULL),(1095,'menu.name.1095','menu.desc.1095','addBiActivity.do',1093,2,1,'2011-05-30 00:00:00',NULL),(1096,'menu.name.1096','menu.desc.1096','showConfigGateway.do',1093,2,1,'2011-05-30 00:00:00',NULL),(1097,'menu.name.1097','menu.desc.1097','addConfigGateway.do',1093,2,1,'2011-05-30 00:00:00',NULL),(1098,'menu.name.1098','menu.desc.1098','delConfigGateway.do',1093,2,1,'2011-05-30 00:00:00',NULL),(1099,'menu.name.1099','menu.desc.1099','showWorldDropRate.do',159,1,51,'2011-05-30 00:00:00',NULL),(1100,'menu.name.1100','menu.desc.1100','worldDropRate.do',1099,2,1,'2011-05-30 00:00:00',NULL),(1101,'menu.name.1101','menu.desc.1101','showCancelWorldDropRate.do',159,1,52,'2011-05-30 00:00:00',NULL),(1102,'menu.name.1102','menu.desc.1102','cancelWorldDropRate.do',1101,2,1,'2011-05-30 00:00:00',NULL),(1103,'menu.name.1103','menu.desc.1103','idContanis.do',1093,2,1,'2011-05-30 00:00:00',NULL),(1104,'menu.name.1104','menu.desc.1104','showCanCancelRate.do',1101,2,1,'2011-05-30 00:00:00',NULL),(1105,'menu.name.1105','menu.desc.1105','showAddAdmin.do',34,1,1,'2011-05-30 00:00:00',NULL),(1106,'menu.name.1106','menu.desc.1106','addAdmin.do',1105,2,1,'2011-05-30 00:00:00',NULL),(1107,'menu.name.1107','menu.desc.1107','showQueryTotalSerialInfo.do',22,1,1,'2011-05-30 00:00:00',NULL),(1108,'menu.name.1108','menu.desc.1108','queryTotalSerialInfo.do',1107,2,1,'2011-05-30 00:00:00',NULL),(1109,'menu.name.1036','menu.desc.1036','showMarkPassport.do',60,1,76,'2011-05-30 00:00:00',NULL),(1139,'menu.name.1139','menu.desc.1139','deleteActivityAwardComp.do',103,2,56,'2011-05-30 00:00:00',NULL),(1150,'menu.name.1150','menu.desc.1150','showRoleYueli.do',22,1,48,'2013-06-26 00:48:10','2013-06-26 00:48:10'),(1151,'menu.name.1151','menu.desc.1151','getRoleYueli.do',1150,2,49,'2013-06-26 00:48:10','2013-06-26 00:48:10'),(1152,'menu.name.1152','menu.desc.1152','showQueryByIp.do',22,1,50,'2013-06-26 00:48:10','2013-06-26 00:48:10'),(1153,'menu.name.1153','menu.desc.1153','queryByIp.do',1152,2,51,'2013-06-26 00:48:10','2013-06-26 00:48:10'),(1198,'menu.name.1198','menu.desc.1198','showRoleActionOperateLog.do',22,1,79,'2013-06-26 00:48:10',NULL),(1199,'menu.name.1199','menu.desc.1199','getRoleActionOperateLog.do',1198,2,1,'2013-06-26 00:48:10',NULL);
/*!40000 ALTER TABLE `sys_resources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_role_comp_menu`
--

DROP TABLE IF EXISTS `sys_role_comp_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_role_comp_menu` (
  `ITEM_ID` int(6) NOT NULL COMMENT '菜单项id',
  `GAME_ID` int(3) NOT NULL COMMENT '游戏id',
  `COMPENSATE_TYPE` int(3) NOT NULL COMMENT '补偿类型： 1-积分补偿',
  `ITEM_NAME` varchar(16) NOT NULL COMMENT '菜单项名称(在同一个游戏和统一补偿类型下，是不允许有相同的菜单项名称)',
  `ITEM_LABEL` varchar(32) NOT NULL COMMENT '菜单项显示名称',
  `ITEM_TYPE` int(1) NOT NULL COMMENT '菜单类型，1-文本框，2，下拉菜单',
  `ITEM_COMMENT` varchar(128) DEFAULT NULL COMMENT '菜单项注释',
  `OPTION_ID` int(3) DEFAULT NULL COMMENT '对应的下拉菜单id',
  `REQUIRED` int(1) NOT NULL COMMENT '是否必须，1-必须，2-不必须',
  `ORDER_NUMBER` int(2) NOT NULL COMMENT '排序号',
  `DIVIDED_TYPE` int(3) NOT NULL COMMENT '菜单所属的划分类型，0表示所有类型公用的，其他表示该类型特有的菜单',
  PRIMARY KEY (`ITEM_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='角色补偿的动态菜单配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_role_comp_menu`
--

LOCK TABLES `sys_role_comp_menu` WRITE;
/*!40000 ALTER TABLE `sys_role_comp_menu` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_role_comp_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_role_comp_menu_option`
--

DROP TABLE IF EXISTS `sys_role_comp_menu_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_role_comp_menu_option` (
  `OPTION_ID` int(3) NOT NULL COMMENT '下拉菜单id',
  `GAME_ID` int(3) NOT NULL,
  `COMPENSATE_TYPE` int(3) NOT NULL,
  `OPTION_LABEL` varchar(100) NOT NULL COMMENT '下拉菜单显示名称',
  `OPTION_VALUE` varchar(100) NOT NULL COMMENT '下拉菜单值',
  `CHECKED` int(1) NOT NULL COMMENT '是否默认选项,1-默认，2-不默认',
  `ORDER_NUMBER` int(2) NOT NULL COMMENT '排序号',
  PRIMARY KEY (`OPTION_ID`,`OPTION_VALUE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='角色补偿的动态菜单的下拉菜单配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_role_comp_menu_option`
--

LOCK TABLES `sys_role_comp_menu_option` WRITE;
/*!40000 ALTER TABLE `sys_role_comp_menu_option` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_role_comp_menu_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_role_comp_type`
--

DROP TABLE IF EXISTS `sys_role_comp_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_role_comp_type` (
  `GAME_ID` int(3) NOT NULL COMMENT '游戏id(请保证类型在每个游戏下面是一致)',
  `COMPENSATE_TYPE` int(3) NOT NULL COMMENT '补偿类型： 1',
  `COMPENSATE_DESC` varchar(255) DEFAULT NULL COMMENT '补偿类型的描述：比如 1代表-积分补偿',
  `DIVIDED_TYPE` int(3) NOT NULL COMMENT '对该角色补偿菜单项的划分， 0 公共的类型(该类型下所有的菜单都可以公用)；若该菜单项没有分类，则用0；否则直接用分类编号',
  `DIVIDED_NAME` varchar(32) DEFAULT NULL COMMENT '该类型的名称(主要是命令的时候所显示的名称),比如 type=creatPet',
  `DIVIDED_DESC` varchar(32) DEFAULT NULL COMMENT '该类型的名称(主要是前台显示的名称),比如 创建宠物',
  `GATEWAY_NEEDED` int(3) NOT NULL COMMENT '该补偿的的该类型下是否需要网关',
  PRIMARY KEY (`GAME_ID`,`COMPENSATE_TYPE`,`DIVIDED_TYPE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='角色补偿类型表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_role_comp_type`
--

LOCK TABLES `sys_role_comp_type` WRITE;
/*!40000 ALTER TABLE `sys_role_comp_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_role_comp_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_role_game`
--

DROP TABLE IF EXISTS `sys_role_game`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_role_game` (
  `ROLE_ID` int(4) NOT NULL COMMENT '角色ID',
  `GAME_ID` int(4) NOT NULL COMMENT '游戏ID',
  PRIMARY KEY (`ROLE_ID`,`GAME_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='角色和游戏关联表，记录游戏管理员';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_role_game`
--

LOCK TABLES `sys_role_game` WRITE;
/*!40000 ALTER TABLE `sys_role_game` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_role_game` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_role_outer_res`
--

DROP TABLE IF EXISTS `sys_role_outer_res`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_role_outer_res` (
  `ROLE_ID` int(6) NOT NULL,
  `GAME_ID` int(4) NOT NULL,
  `RES_ID` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='角色和外部资源的关联表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_role_outer_res`
--

LOCK TABLES `sys_role_outer_res` WRITE;
/*!40000 ALTER TABLE `sys_role_outer_res` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_role_outer_res` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_role_resources`
--

DROP TABLE IF EXISTS `sys_role_resources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_role_resources` (
  `GAME_RES_ID` int(10) NOT NULL COMMENT '资源id',
  `ROLE_ID` int(6) NOT NULL COMMENT '角色id',
  PRIMARY KEY (`GAME_RES_ID`,`ROLE_ID`),
  CONSTRAINT `FK_GAME_RES_ROLE_RES` FOREIGN KEY (`GAME_RES_ID`) REFERENCES `sys_game_resources` (`GAME_RES_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='角色与资源关系表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_role_resources`
--

LOCK TABLES `sys_role_resources` WRITE;
/*!40000 ALTER TABLE `sys_role_resources` DISABLE KEYS */;
INSERT INTO `sys_role_resources` VALUES (9193,1),(9194,1),(9195,1),(9196,1),(9198,1),(9199,1),(9200,1),(9201,1),(9202,1),(9203,1),(9204,1),(9205,1),(9206,1),(9207,1),(9208,1),(9209,1),(9210,1),(9211,1),(9212,1),(9214,1),(9216,1),(9217,1),(9218,1),(9219,1),(9222,1),(9223,1),(9224,1),(9225,1),(9226,1),(9255,1),(9278,1),(9288,1),(9289,1),(9292,1),(9293,1),(9294,1),(9295,1),(9300,1),(9305,1),(9309,1),(9402,1),(9786,1);
/*!40000 ALTER TABLE `sys_role_resources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_roles`
--

DROP TABLE IF EXISTS `sys_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_roles` (
  `ROLE_ID` int(6) NOT NULL COMMENT '角色id，如果表中无记录，id=1，否则id=max(id) + 1',
  `ROLE_NAME` varchar(32) NOT NULL COMMENT '角色名称',
  `ROLE_DESC` varchar(256) DEFAULT NULL COMMENT '角色描述',
  `SUPERIOR_OPER` int(10) NOT NULL DEFAULT '0' COMMENT '上级用户(此列将被废弃，不在被使用)',
  `ROLE_CREATOR_LEVEL` int(2) NOT NULL DEFAULT '0' COMMENT '角色创建者的级别， 20客服总监 30游戏管理员',
  `ROLE_GAME` int(4) NOT NULL DEFAULT '0' COMMENT '角色所属的游戏 (对应的游戏id)',
  PRIMARY KEY (`ROLE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_roles`
--

LOCK TABLES `sys_roles` WRITE;
/*!40000 ALTER TABLE `sys_roles` DISABLE KEYS */;
INSERT INTO `sys_roles` VALUES (1,'admin','admin',0,30,1204),(2,'Brazil','111',1072508,30,1204),(4,'globalgames','GLOBALgames',1072508,30,1204),(5,'001[GM]','001[GM]',432712658,0,1204),(6,'thiago','Ok',432712652,30,1204);
/*!40000 ALTER TABLE `sys_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_scene`
--

DROP TABLE IF EXISTS `sys_scene`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_scene` (
  `GAME_ID` int(3) NOT NULL COMMENT '游戏编号',
  `SCENE_CODE` varchar(64) NOT NULL COMMENT '场景标识',
  `SCENE_NAME` varchar(64) NOT NULL COMMENT '场景名称',
  PRIMARY KEY (`GAME_ID`,`SCENE_CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='游戏场景信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_scene`
--

LOCK TABLES `sys_scene` WRITE;
/*!40000 ALTER TABLE `sys_scene` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_scene` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_secretkey`
--

DROP TABLE IF EXISTS `sys_secretkey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_secretkey` (
  `SESSION_ID` int(10) NOT NULL,
  `SK_CONTENT` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`SESSION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='SecretKey';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_secretkey`
--

LOCK TABLES `sys_secretkey` WRITE;
/*!40000 ALTER TABLE `sys_secretkey` DISABLE KEYS */;
INSERT INTO `sys_secretkey` VALUES (133876277,'05C020U613JR1KE008Z7'),(241098983,'1IJE1QK820180I5X0T1I'),(346068845,'1HE80WJS02K61XH20V1Q'),(389353409,'1A4B1RB70NVI06LO12JN'),(777561442,'22MW12V71BL7186K00ZH');
/*!40000 ALTER TABLE `sys_secretkey` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_secretkey_bak`
--

DROP TABLE IF EXISTS `sys_secretkey_bak`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_secretkey_bak` (
  `SESSION_ID` int(10) NOT NULL,
  `SK_CONTENT` varchar(256) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_secretkey_bak`
--

LOCK TABLES `sys_secretkey_bak` WRITE;
/*!40000 ALTER TABLE `sys_secretkey_bak` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_secretkey_bak` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_syn_game_relation`
--

DROP TABLE IF EXISTS `sys_syn_game_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_syn_game_relation` (
  `SOURCE_GAME_ID` int(3) NOT NULL,
  `TARGET_GAME_ID` int(3) NOT NULL,
  PRIMARY KEY (`SOURCE_GAME_ID`,`TARGET_GAME_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_syn_game_relation`
--

LOCK TABLES `sys_syn_game_relation` WRITE;
/*!40000 ALTER TABLE `sys_syn_game_relation` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_syn_game_relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_trustee_ip`
--

DROP TABLE IF EXISTS `sys_trustee_ip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_trustee_ip` (
  `GAME_ID` int(3) NOT NULL COMMENT '游戏编号',
  `GATEWAY_TYPE` int(4) NOT NULL COMMENT '区服类型，0-体验区，1-正式区',
  `IP_ID` int(6) NOT NULL,
  `IP_NAME` varchar(32) NOT NULL COMMENT 'ip描述',
  `TRUSTEE_IP` varchar(32) NOT NULL COMMENT 'ip',
  PRIMARY KEY (`IP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='游戏托管ip';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_trustee_ip`
--

LOCK TABLES `sys_trustee_ip` WRITE;
/*!40000 ALTER TABLE `sys_trustee_ip` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_trustee_ip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'egamemaster'
--
/*!50003 DROP PROCEDURE IF EXISTS `createSecretKey` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`localhost`*/ /*!50003 PROCEDURE `createSecretKey`(
OUT n_session_id INTEGER, 
OUT s_sk_content VARCHAR(20)
)
BEGIN
  DECLARE num INT DEFAULT 0;
  
  SET n_session_id = ROUND(ROUND(RAND(),9)*1000000000);	
  
  SET s_sk_content = CONCAT(
	LPAD(CONV(RAND()*100000,10,36),4,'0'),
	LPAD(CONV(RAND()*100000,10,36),4,'0'),
	LPAD(CONV(RAND()*100000,10,36),4,'0'),
	LPAD(CONV(RAND()*100000,10,36),4,'0'),
	LPAD(CONV(RAND()*100000,10,36),4,'0')
	); 
  
  SELECT COUNT(*) INTO num FROM sys_secretkey WHERE session_id = n_session_id;
  IF (num = 0) THEN
	INSERT INTO sys_secretkey(session_id, sk_content) VALUES (n_session_id, s_sk_content);
  END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `deleteSecretkey` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`localhost`*/ /*!50003 PROCEDURE `deleteSecretkey`(n_session_id INTEGER, OUT ret_code INTEGER)
BEGIN
  SET ret_code = 1;
  DELETE FROM sys_secretkey WHERE session_id = n_session_id; 
  IF (ROW_COUNT() = 0) THEN
    SET ret_code = -1821;
  END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getActivityCode` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`localhost`*/ /*!50003 PROCEDURE `getActivityCode`(
						       in     n_gameId   integer,
						       in     n_gatewayType  integer,
						       in     n_pageSize     integer,
                                                       in     n_pageIndex    integer,
                                                       out     n_itemCount    integer,
						       out    n_pageCount    integer,
		                                       out    n_ret          integer
                                                       )
BEGIN
    label_proc:begin
         DECLARE n_pageNum INTEGER;
         DECLARE n_err   INTEGER default -200;
         DECLARE CONTINUE HANDLER for SQLEXCEPTION set n_err = 100;
         set n_pageNum = (n_pageSize*n_pageIndex);
          
         select ifnull(count(*),0)
           into n_itemCount
           from log_activity_code
          where game_id = n_gameId
            and gateway_type = n_gatewayType; 
	
	if(n_pageSize=0)then
	    set n_ret = 0;
	    leave label_proc;
	end if;
	if(n_itemCount%n_pageSize=0) then
	     set n_pageCount=n_itemCount/n_pageSize;
	else
	     set n_pageCount=floor(n_itemCount/n_pageSize)+1;
	end if;	
        
         select *
           from log_activity_code
          where game_id = n_gameId
            and gateway_type = n_gatewayType
            limit n_pageNum,n_pageSize;
         if(n_err=100) then 
             set n_ret = 0;
             leave label_proc;
         end if;
         set n_ret=1;
    end label_proc;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getActivityCodeFilePath` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`localhost`*/ /*!50003 PROCEDURE `getActivityCodeFilePath`(in    n_logId    int,
							       out   s_filePath  varchar(100),
							       out   n_ret      int
							       )
BEGIN
     lable_proc:begin
          DECLARE  n_err  int default -200;
          DECLARE  CONTINUE  HANDLER for not found set n_err = 100;
          
             select file_path
	       into s_filePath
               from log_activity_code
              where log_id = n_logId;
          if(n_err=100)then
              set n_ret = 0;
          end if;
          set n_ret =1;  
               
     end lable_proc;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getSerialCodeLog` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`localhost`*/ /*!50003 PROCEDURE `getSerialCodeLog`(in    n_gameId      INT,
							in    n_activityID  BIGINT,
							OUT   n_ret         int
							)
BEGIN
      lable_proc:begin
           DECLARE n_err int default -200;
           DECLARE CONTINUE HANDLER for SQLEXCEPTION set n_err = 100;
           
           select * from LOG_SERIALCODE t 
             where t.GAME_ID = n_gameId
               and t.ACTIVITY_ID = n_activityID;
           
           if(n_err=100)then
              set n_ret = 0;
              leave lable_proc;
           end if;
           
           set n_ret = 1;       
               
      end lable_proc;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `logActivityCode` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`localhost`*/ /*!50003 PROCEDURE `logActivityCode`(
						in     n_game_id        integer,
                                                in     n_gateway_type   integer,
                                                in     n_plan_gen_no    integer,
                                                in     n_success_gen_no integer,
                                                in     s_file_path      varchar(2048),
                                                in     s_operator_name  varchar(32),					
						out    n_ret            integer
						)
BEGIN
	label_proc:begin
	   DECLARE  n_err int default -200;
	   DECLARE CONTINUE HANDLER for SQLEXCEPTION set n_err = 100;
	   
	   insert into log_activity_code
	      (
		log_id,
		game_id,
                gateway_type,
	       plan_gen_no,
	       success_gen_no,
	       file_path,
	       insert_time,
	       operator_name)	    
	    (
	      select
	        ifnull(max(log_id),0)+1,
	       n_game_id,
               n_gateway_type,
               n_plan_gen_no,
               n_success_gen_no,
               s_file_path,
		sysdate(),
               s_operator_name
	      from log_activity_code
	    );
	  if(n_err = 100) then
	    set n_ret = 0;
	    leave label_proc;
	  end if;
	  set n_ret = 1;  
	end label_proc;
    END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `setSerialCodeLog` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50020 DEFINER=`root`@`localhost`*/ /*!50003 PROCEDURE `setSerialCodeLog`(
						in     n_game_id        integer,
						in     n_activity_id    integer,
						in     s_media_name     varchar(200),
                                                in     n_use_limit      integer,
						in     n_serial_num     integer,
                                                in     s_passport_name  varchar(200),
                                                in     d_oper_time      datetime,
						in     s_file_path      varchar(200),						
						out    n_ret   int
						)
BEGIN
	label_proc:begin
	   DECLARE  n_err int default -200;
	   DECLARE CONTINUE HANDLER for SQLEXCEPTION set n_err = 100;
	   
	   insert into log_serialcode
	      (
		log_id,
		game_id,
                activity_id,
                media_name,
                use_limit,
                serial_num,
                passport_name,
                oper_time,
                file_path)	    
	    (
	      select
	        ifnull(max(log_id),0)+1,
	        n_game_id,
	        n_activity_id,
		s_media_name,
                n_use_limit,
		n_serial_num,
                s_passport_name,
                d_oper_time,
		s_file_path
	      from log_serialcode
	    );
	  if(n_err = 100) then
	    set n_ret = 0;
	    leave label_proc;
	  end if;
	  set n_ret = 1;  
	end label_proc;
    END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-08-26  4:52:20
