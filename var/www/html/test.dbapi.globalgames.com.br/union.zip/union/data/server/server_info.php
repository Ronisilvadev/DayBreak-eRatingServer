<?php 

$f_cache = array (
  's1' => 
  array (
    'gatewayid' => '104001',
  ),
  's2' => 
  array (
    'gatewayid' => '104002',
  ),
  's3' => 
  array (
    'gatewayid' => '104003',
  ),
  's4' => 
  array (
    'gatewayid' => '104004',
  ),
  's5' => 
  array (
    'gatewayid' => '104005',
  ),
  's6' => 
  array (
    'gatewayid' => '104006',
  ),
  's7' => 
  array (
    'gatewayid' => '104007',
  ),
  's8' => 
  array (
    'gatewayid' => '104008',
  ),
  's9' => 
  array (
    'gatewayid' => '104009',
  ),
  's10' => 
  array (
    'gatewayid' => '104010',
  ),
);